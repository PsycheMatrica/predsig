# predsig 0.3.0 (native backend)

- Restores native source generated from the current authoritative MATLAB core,
  compiled by R's standard build and called through registered `.Call` routines.
  No separately precompiled Windows computational DLL is needed or included in
  the R source package. Source installation requires C99 tooling and GNU make;
  end users and R builds require no MATLAB or MATLAB Coder installation.
- Uses the registered C engine for every analysis. The default
  `engine = "auto"` and the aliases `"C"` and `"dll"` all select the compiled
  package library.
- Adds predictor marginal normality diagnostics on the exact retained design
  columns, using the shared C engine. Reports the original skewness and
  unadjusted K-squared tests with separate planned-family Holm adjustments
  across predictors. N <= 20,
  numerical unavailability, and absent predictor data have explicit statuses;
  diagnostics do not alter the model, analysis sample, or inference. Summary
  output includes a compact diagnostic table and its marginal scope caveat.
- Records private developer-generation provenance and a curated native-source inventory,
  handwritten R memory/allocation support, and a portable type shim replacing
  the generated header that depended on installed `tmwtypes.h`. Installed
  MathWorks library/API headers and raw codegen artifacts are excluded.
  The mathematical MATLAB generation sources are maintained separately;
  installation compiles the supplied generated C, without those private sources.
- Retains CC BY-NC-SA 4.0 for rights controlled by Gyeongcheol Cho. Generated
  MathWorks-affected material is not collectively relicensed; its Academic
  banners and the Sun Microsystems/FDLIBM notices in `eml_erfcore.c` and
  `norminv.c` remain in the source and component inventory. Earlier recipient
  rights are not retroactively withdrawn.
- Records unresolved public source/mirror redistribution, Academic-offering,
  and written Application License questions. Repository availability and
  technical checks do not establish MathWorks approval or CRAN readiness.
- Keeps the reviewed statistical formulas, estimators, integration tolerances,
  model interfaces, and data helper unchanged. Existing inference values in
  result summaries are retained alongside the added diagnostics.
- Separates historical full-simulation evidence from new native validation.
  Current reports must identify the checks and platforms actually executed;
  no cross-platform or full-run result is implied by this entry.

## Historical development versions (not distributed in this release)

# predsig 0.2.2

- Adds `prepare_manini()` to download and verify official OSF workbooks,
  prepare the original 21-case illustration in R, and save local analysis data.
- Participant data remain outside the package; Python is not required by the
  new preparation function.
- Makes `predsig::run()` the primary S3 interface, matching MATLAB's `predsig.run()`.
- Retains earlier function names as compatibility wrappers.
- Shortens the public assumptions and updates current help and examples.
- Separates the public R shell, model adapters, shared-DLL dispatcher, and R core.
- Accepts raw y/X and t/sigma2_hat/N/P summaries alongside ordinary lm output.
- Uses the MATLAB-generated core DLL when available, with an R translation
  as the automatic fallback. The portable source archive excludes the DLL.
- Matches MATLAB integration defaults: absolute tolerance 2e-10, relative
  tolerance 2e-8, and omitted-tail probability bound 2e-12. The target and
  reference distribution are unchanged.

# predsig 0.2.0

- Changes `delta` to `delEPE / EPE1`, where `EPE1` is the original full fitted
  model's expected prediction error averaged over training and independent
  test observations under the Gaussian random-design model.
- Returns `EPE1 = (1 + 1/N) * (N - 2)/(df_error - 1) * sigma2` instead of
  the former training-mean `EPE0` denominator. This changes the interpretation
  index and its output field, not `delEPE`, `p_pred`, or `p_coef`.
- Documents finite-sample ratio bias and the asymptotic limit of `delta`:
  incremental population R-squared divided by one minus full-model R-squared.
- Regenerates the 11 aggregate Manini/Trelle reference slopes in native R;
  legacy normalized values are not accepted as current reference values.
- Adds denominator, rescaling, and unchanged-primary-inference checks.

# predsig 0.1.1

- Makes `predsig(fit)` the primary S3 interface for ordinary fitted `lm` models.
- Retains `predictive_test()` and `predictive_pvalue()` as compatibility
  interfaces with the existing formula and ordinary-lm behavior.
- Updates installed examples, Manini reproduction scripts, and documentation.
- Leaves all numerical estimators and predictive-tail calculations unchanged.

# predsig 0.1.0

- Adds an installable R package around the previously validated native-R
  continuous-design linear-regression calculation.
- Adds the extensible `predictive_test()` S3 interface, an ordinary `lm` method,
  a formula interface, and the `predictive_pvalue()` compatibility name.
- Reports `delEPE`, `delta`, `p_pred`, and `p_coef` without changing the fitted
  full equation or its analysis observations.
- Explicitly rejects generalized linear models, analysis-of-variance objects,
  other `lm` subclasses, and designs outside the implemented scope.
- Includes official-source acquisition and native-R Manini reproduction tools.
