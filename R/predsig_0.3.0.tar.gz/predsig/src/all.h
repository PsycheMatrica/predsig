/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * all.h
 *
 * Code generation for function 'all'
 *
 */

#ifndef ALL_H
#define ALL_H

/* Include files */
#include "main_core_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
boolean_T all(const emxArray_boolean_T *x);

boolean_T b_all(const boolean_T x[7]);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (all.h) */
