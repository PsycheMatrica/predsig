/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * vvarstd.h
 *
 * Code generation for function 'vvarstd'
 *
 */

#ifndef VVARSTD_H
#define VVARSTD_H

/* Include files */
#include "main_core_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
double vvarstd(const emxArray_real_T *v, int32_t n);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (vvarstd.h) */
