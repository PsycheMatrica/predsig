/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * sqrt.c
 *
 * Code generation for function 'sqrt'
 *
 */

/* Include files */
#include "sqrt.h"
#include "main_core_types.h"
#include "rt_nonfinite.h"
#include <math.h>

/* Function Definitions */
void b_sqrt(emxArray_real_T *x)
{
  double *x_data;
  int32_t k;
  int32_t nx;
  x_data = x->data;
  nx = x->size[1];
  for (k = 0; k < nx; k++) {
    x_data[k] = sqrt(x_data[k]);
  }
}

void c_sqrt(emxArray_real_T *x)
{
  double *x_data;
  int32_t k;
  int32_t nx;
  x_data = x->data;
  nx = x->size[0];
  for (k = 0; k < nx; k++) {
    x_data[k] = sqrt(x_data[k]);
  }
}

/* End of code generation (sqrt.c) */
