/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * xzlarf.c
 *
 * Code generation for function 'xzlarf'
 *
 */

/* Include files */
#include "xzlarf.h"
#include "main_core_types.h"
#include "rt_nonfinite.h"
#include "xgerc.h"

/* Function Definitions */
void xzlarf(int32_t m, int32_t n, int32_t iv0, double tau, emxArray_real_T *C,
            int32_t ic0, int32_t ldc, emxArray_real_T *work)
{
  double *C_data;
  double *work_data;
  int32_t b_ia;
  int32_t i;
  int32_t ia;
  int32_t iy;
  int32_t lastc;
  int32_t lastv;
  work_data = work->data;
  C_data = C->data;
  if (tau != 0.0) {
    boolean_T exitg2;
    lastv = m;
    i = iv0 + m;
    while ((lastv > 0) && (C_data[i - 2] == 0.0)) {
      lastv--;
      i--;
    }
    lastc = n;
    exitg2 = false;
    while (!exitg2 && (lastc > 0)) {
      int32_t exitg1;
      i = ic0 + (lastc - 1) * ldc;
      ia = i;
      do {
        exitg1 = 0;
        if (ia <= (i + lastv) - 1) {
          if (C_data[ia - 1] != 0.0) {
            exitg1 = 1;
          } else {
            ia++;
          }
        } else {
          lastc--;
          exitg1 = 2;
        }
      } while (exitg1 == 0);
      if (exitg1 == 1) {
        exitg2 = true;
      }
    }
  } else {
    lastv = 0;
    lastc = 0;
  }
  if (lastv > 0) {
    if (lastc != 0) {
      for (iy = 0; iy < lastc; iy++) {
        work_data[iy] = 0.0;
      }
      i = 0;
      ia = ic0 + ldc * (lastc - 1);
      for (iy = ic0; ldc < 0 ? iy >= ia : iy <= ia; iy += ldc) {
        double c;
        int32_t b_i;
        c = 0.0;
        b_i = iy + lastv;
        for (b_ia = iy; b_ia < b_i; b_ia++) {
          c += C_data[b_ia - 1] * C_data[((iv0 + b_ia) - iy) - 1];
        }
        work_data[i] += c;
        i++;
      }
    }
    xgerc(lastv, lastc, -tau, iv0, work, C, ic0, ldc);
  }
}

/* End of code generation (xzlarf.c) */
