/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * main_core.c
 *
 * Code generation for function 'main_core'
 *
 */

/* Include files */
#include "main_core.h"
#include "chi2inv.h"
#include "chi2pdf.h"
#include "integral.h"
#include "main_core_emxutil.h"
#include "main_core_types.h"
#include "nctcdf.h"
#include "rt_nonfinite.h"
#include "sqrt.h"
#include "rt_nonfinite.h"
#include <math.h>

/* Function Declarations */
static void binary_expand_op(emxArray_real_T *in1, const emxArray_real_T *in2,
                             const emxArray_real_T *in3);

/* Function Definitions */
static void binary_expand_op(emxArray_real_T *in1, const emxArray_real_T *in2,
                             const emxArray_real_T *in3)
{
  emxArray_real_T *b_in1;
  const double *in2_data;
  const double *in3_data;
  double *b_in1_data;
  double *in1_data;
  int32_t i;
  int32_t loop_ub;
  int32_t stride_0_1;
  int32_t stride_1_1;
  int32_t stride_2_1;
  in3_data = in3->data;
  in2_data = in2->data;
  in1_data = in1->data;
  emxInit_real_T(&b_in1, 2);
  stride_0_1 = b_in1->size[0] * b_in1->size[1];
  b_in1->size[0] = 1;
  if (in3->size[1] == 1) {
    if (in2->size[1] == 1) {
      loop_ub = in1->size[1];
    } else {
      loop_ub = in2->size[1];
    }
  } else {
    loop_ub = in3->size[1];
  }
  b_in1->size[1] = loop_ub;
  emxEnsureCapacity_real_T(b_in1, stride_0_1);
  b_in1_data = b_in1->data;
  stride_0_1 = (in1->size[1] != 1);
  stride_1_1 = (in2->size[1] != 1);
  stride_2_1 = (in3->size[1] != 1);
  for (i = 0; i < loop_ub; i++) {
    b_in1_data[i] = (in1_data[i * stride_0_1] + in2_data[i * stride_1_1]) *
                    in3_data[i * stride_2_1];
  }
  stride_0_1 = in1->size[0] * in1->size[1];
  in1->size[0] = 1;
  in1->size[1] = loop_ub;
  emxEnsureCapacity_real_T(in1, stride_0_1);
  in1_data = in1->data;
  for (i = 0; i < loop_ub; i++) {
    in1_data[i] = b_in1_data[i];
  }
  emxFree_real_T(&b_in1);
}

void main_core(double t, double sigma2_hat, double N, double P, double abs_tol,
               double rel_tol, double *delEPE_hat, double *delta_hat,
               double *p_pred, double *EPE1_hat)
{
  double df;
  double observed;
  /*  MAIN_CORE  Core calculations for predictive significance in linear
   * regression. */
  /*  */
  /*  INPUTS (from the same full OLS model, including an intercept) */
  /*    t          : Observed t_{p,obs} for each slope; exclude the intercept.
   */
  /*    sigma2_hat : sigma_epsilon^2 with a hat: SSE / df (Equation B8). */
  /*    N          : Number of observations actually used in the fitted model.
   */
  /*    P          : Total number of slopes in that model, excluding the
   * intercept. */
  /*                 P is not necessarily numel(t) if only some slopes are
   * evaluated. */
  /*    abs_tol    : Optional absolute integration tolerance (default = 2e-10).
   */
  /*    rel_tol    : Optional relative integration tolerance (default = 2e-8).
   */
  /*                 Omit either optional input or use [] to select its default.
   */
  /*                 Both must be nonnegative; at least one must be positive. */
  /*                 These control quadrature, not the separate tail truncation.
   */
  /*  */
  /*  OUTPUTS */
  /*    delEPE_hat : Estimated increase in EPE after removing each predictor's
   */
  /*                 unique linear contribution; primary target, in outcome^2
   * units. */
  /*    delta_hat  : delEPE_hat / EPE1_hat; relative increase in full-model EPE.
   */
  /*    p_pred     : Analytic predictive p-value for H0: delEPE_p <= 0. */
  /*    EPE1_hat   : Estimated EPE of the original full fitted prediction model.
   */
  /*                 The first three outputs preserve the shape of t. */
  /*  */
  /*  Assumes a prespecified, correctly specified, full-rank, unweighted OLS
   * model */
  /*  with an intercept, iid jointly normal continuous predictors, and
   * independent */
  /*  Gaussian homoskedastic errors. Predictor removal uses its population
   * linear- */
  /*  projection residual contribution at prediction time; no reduced model is
   * fit. */
  /*  EPE averages over training samples and an independent test observation. */
  /*  delEPE_hat is unbiased under this model; its normalized ratio is generally
   */
  /*  biased but consistent. delta_hat is not a proportion of variance
   * explained. */
  /*  */
  /*  This function receives numeric summaries only. Model fitting, coefficient
   */
  /*  p-values, standardized coefficients, result tables, and model checks
   * belong */
  /*  outside this core. No bootstrap samples or random seed are used here. */
  /*  Requires Statistics and Machine Learning Toolbox for distribution
   * functions. */
  /*  */
  /*  Example using an existing fitlm model: */
  /*    t = mdl.Coefficients.tStat(2:end); */
  /*    P = mdl.NumEstimatedCoefficients - 1; */
  /*    [delEPE, delta, p_pred, EPE1] = ... */
  /*        main_core(t, mdl.MSE, mdl.NumObservations, P); */
  /*    % Or set both tolerances explicitly: */
  /*    [delEPE, delta, p_pred, EPE1] = ... */
  /*        main_core(t, mdl.MSE, mdl.NumObservations, P, 1e-12, 1e-10); */
  /*  */
  /*  Author: Gyeongcheol Cho */
  /*  Paper: Predictive Significance Testing: A Complement to Coefficient */
  /*         Significance in Confirmatory Linear Regression */
  /*  Repository: https://github.com/PsycheMatrica/predsig */
  /*  Preprint: Not yet available */
  /*  Copyright (C) 2026 Gyeongcheol Cho. CC BY-NC-SA 4.0. */
  /*  Equation labels match Manuscript_R0_v4_Full.docx supplied 2026-10-27: */
  /*  (B30) / (10) for the point estimator, (E1) for estimated full-model EPE,
   */
  /*  (14) for the predictive tail, and (19) / (E4) for the normalized estimate.
   */
  /*  The population index is defined in (16), with its effect-size form in
   * (17). */
  /*  Authoritative MATLAB mathematical implementation, also used by MATLAB
   * Coder. */
  /*  ----- Check only the numeric inputs needed by these formulas ----- */
  /*  ----- Degrees of freedom ----- */
  /*  Full outcome regression: P slopes and one intercept. */
  df = (N - P) - 1.0;
  /*  ----- Estimate the primary target: delEPE_p ---- */
  /*  Equation (B30): unbiased point estimator of predictive contribution. */
  *delEPE_hat = sigma2_hat / (df + 1.0) * (t * t - 2.0 * df / (df - 1.0));
  /*  ----- Estimate the full-model EPE and the interpretation index ----- */
  /*  Equation (E1): estimated full-model EPE; population expression in (D14).
   */
  *EPE1_hat = (1.0 / N + 1.0) * (N - 2.0) / (df - 1.0) * sigma2_hat;
  /*  Equation (19): normalized estimator, corresponding to the population */
  /*  index in Equation (17). */
  *delta_hat = *delEPE_hat / *EPE1_hat;
  /*  This ratio is algebraically identical to Equation (19): */
  /*    f2_hat = t.^2/df; % sample Cohen f_p^2, Equation (E3). */
  /*    normalization = (df-1)/((1+1/N)*(N-2)); */
  /*    delta_hat = normalization * ... */
  /*        ((df/(df+1)*f2_hat - 1/(df+1)) - 1/(df-1)); */
  /*  ----- Analytic predictive p-values ----- */
  /*  Equation (14), at the boundary delEPE_p = 0: */
  /*    |beta_p| * sigma_{r_p} / sigma_epsilon = 1/sqrt(df-1). */
  /*  Conditional on U ~ chi-square(df+1), the coefficient t statistic has a */
  /*  noncentral t distribution with df degrees of freedom and noncentrality */
  /*  magnitude sqrt(U/(df-1)). The two-sided tail is the same for either sign.
   */
  /*  Integrating this tail over U gives p_pred; no random U draws are
   * generated. */
  /*  */
  /*  Keep the existing numerical limits. Truncating the U */
  /*  distribution at these quantiles omits probability at most 2e-12; */
  /*  quadrature error is separate from that bound. */
  observed = fabs(t);
  /*  Exact endpoints, including the limiting case of an infinite t statistic.
   */
  if (observed == 0.0) {
    *p_pred = 1.0;
  } else if (rtIsInf(observed)) {
    *p_pred = 0.0;
  } else {
    /*  Equation (14) uses F_nct(-observed; lambda) + 1-F_nct(observed; lambda).
     */
    /*  The identity 1-F_nct(observed; lambda) = F_nct(-observed; -lambda) */
    /*  gives the same two-sided tail without subtracting a CDF from one. */
    /*  Multiplying by the chi-square density averages over U. */
    *p_pred = integral(observed, df, chi2inv(df + 1.0), b_chi2inv(df + 1.0),
                       abs_tol, rel_tol);
  }
  /*  Preserve the previous helper's numerical guard and rounding protection. */
  if (rtIsInf(*p_pred) || rtIsNaN(*p_pred) || (*p_pred < -5.0E-8) ||
      (*p_pred > 1.00000005)) {
    /*  Standalone C must not abort the host process or clip a NaN into a */
    /*  valid probability. Return a detectable failure; the native caller */
    /*  rejects it after Coder has released its temporary allocations. */
    *p_pred = rtNaN;
  } else {
    *p_pred = fmax(0.0, fmin(1.0, *p_pred));
  }
}

void main_core_anonFcn1(double observed, double df, const emxArray_real_T *u,
                        emxArray_real_T *varargout_1)
{
  emxArray_real_T *r;
  emxArray_real_T *r2;
  const double *u_data;
  double *r1;
  double *r3;
  double *varargout_1_data;
  int32_t i;
  int32_t i1;
  int32_t loop_ub;
  u_data = u->data;
  emxInit_real_T(&r, 2);
  i = r->size[0] * r->size[1];
  r->size[0] = 1;
  loop_ub = u->size[1];
  r->size[1] = u->size[1];
  emxEnsureCapacity_real_T(r, i);
  r1 = r->data;
  for (i1 = 0; i1 < loop_ub; i1++) {
    r1[i1] = u_data[i1] / (df - 1.0);
  }
  b_sqrt(r);
  b_nctcdf(-observed, df, r, varargout_1);
  i = r->size[0] * r->size[1];
  r->size[0] = 1;
  r->size[1] = u->size[1];
  emxEnsureCapacity_real_T(r, i);
  r1 = r->data;
  for (i1 = 0; i1 < loop_ub; i1++) {
    r1[i1] = u_data[i1] / (df - 1.0);
  }
  b_sqrt(r);
  r1 = r->data;
  emxInit_real_T(&r2, 2);
  i = r2->size[0] * r2->size[1];
  r2->size[0] = 1;
  loop_ub = r->size[1];
  r2->size[1] = r->size[1];
  emxEnsureCapacity_real_T(r2, i);
  r3 = r2->data;
  for (i1 = 0; i1 < loop_ub; i1++) {
    r3[i1] = -r1[i1];
  }
  b_nctcdf(-observed, df, r2, r);
  r1 = r->data;
  chi2pdf(u, df + 1.0, r2);
  r3 = r2->data;
  if (varargout_1->size[1] == 1) {
    i = r->size[1];
  } else {
    i = varargout_1->size[1];
  }
  if ((varargout_1->size[1] == r->size[1]) && (i == r2->size[1])) {
    loop_ub = varargout_1->size[1];
    i = varargout_1->size[0] * varargout_1->size[1];
    varargout_1->size[0] = 1;
    emxEnsureCapacity_real_T(varargout_1, i);
    varargout_1_data = varargout_1->data;
    for (i1 = 0; i1 < loop_ub; i1++) {
      varargout_1_data[i1] = (varargout_1_data[i1] + r1[i1]) * r3[i1];
    }
  } else {
    binary_expand_op(varargout_1, r, r2);
  }
  emxFree_real_T(&r2);
  emxFree_real_T(&r);
}

/* End of code generation (main_core.c) */
