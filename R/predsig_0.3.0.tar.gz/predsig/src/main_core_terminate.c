/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * main_core_terminate.c
 *
 * Code generation for function 'main_core_terminate'
 *
 */

/* Include files */
#include "main_core_terminate.h"
#include "rt_nonfinite.h"

/* Function Definitions */
void main_core_terminate(void)
{
}

/* End of code generation (main_core_terminate.c) */
