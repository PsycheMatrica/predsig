/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * eml_erfcore.c
 *
 * Code generation for function 'eml_erfcore'
 *
 */

/* Include files */
#include "eml_erfcore.h"
#include "rt_nonfinite.h"
#include "rt_nonfinite.h"
#include <math.h>

/* Function Definitions */
double eml_erfcore(double x)
{
  double absx;
  double y;
  int32_t eint;
  /* ========================== COPYRIGHT NOTICE ============================ */
  /*  The algorithms for calculating ERF(X) and ERFC(X) are derived           */
  /*  from FDLIBM, which has the following notice:                            */
  /*                                                                          */
  /*  Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved.       */
  /*                                                                          */
  /*  Developed at SunSoft, a Sun Microsystems, Inc. business.                */
  /*  Permission to use, copy, modify, and distribute this                    */
  /*  software is freely granted, provided that this notice                   */
  /*  is preserved.                                                           */
  /* =============================    END    ================================ */
  absx = fabs(x);
  if (rtIsNaN(x)) {
    y = rtNaN;
  } else if (rtIsInf(x)) {
    if (x < 0.0) {
      y = 2.0;
    } else {
      y = 0.0;
    }
  } else if (absx < 0.84375) {
    if (absx < 1.3877787807814457E-17) {
      y = 1.0 - x;
    } else {
      y = x * x;
      y = (y * (y * (y * (y * -2.3763016656650163E-5 - 0.005770270296489442) -
                     0.02848174957559851) -
                0.3250421072470015) +
           0.12837916709551256) /
          (y * (y * (y * (y * (y * -3.960228278775368E-6 +
                               0.00013249473800432164) +
                          0.005081306281875766) +
                     0.0650222499887673) +
                0.39791722395915535) +
           1.0);
      if (x < 0.25) {
        y = 1.0 - (x + x * y);
      } else {
        y = 0.5 - (x * y + (x - 0.5));
      }
    }
  } else if (absx < 1.25) {
    double P;
    P = (absx - 1.0) *
            ((absx - 1.0) *
                 ((absx - 1.0) *
                      ((absx - 1.0) *
                           ((absx - 1.0) *
                                ((absx - 1.0) * -0.002166375594868791 +
                                 0.035478304325618236) -
                            0.11089469428239668) +
                       0.31834661990116175) -
                  0.3722078760357013) +
             0.41485611868374833) -
        0.0023621185607526594;
    y = (absx - 1.0) *
            ((absx - 1.0) *
                 ((absx - 1.0) *
                      ((absx - 1.0) *
                           ((absx - 1.0) *
                                ((absx - 1.0) * 0.011984499846799107 +
                                 0.01363708391202905) +
                            0.12617121980876164) +
                       0.07182865441419627) +
                  0.540397917702171) +
             0.10642088040084423) +
        1.0;
    if (x >= 0.0) {
      y = 0.15493708848953247 - P / y;
    } else {
      y = (P / y + 0.8450629115104675) + 1.0;
    }
  } else if (x < -6.0) {
    y = 2.0;
  } else if (x >= 28.0) {
    y = 0.0;
  } else {
    double P;
    double R;
    y = 1.0 / (absx * absx);
    if (absx < 2.8571414947509766) {
      R = y * (y * (y * (y * (y * (y * (y * -9.814329344169145 -
                                        81.2874355063066) -
                                   184.60509290671104) -
                              162.39666946257347) -
                         62.375332450326006) -
                    10.558626225323291) -
               0.6938585727071818) -
          0.009864944034847148;
      P = y * (y * (y * (y * (y * (y * (y * (y * -0.0604244152148581 +
                                             6.570249770319282) +
                                        108.63500554177944) +
                                   429.00814002756783) +
                              645.3872717332679) +
                         434.56587747522923) +
                    137.65775414351904) +
               19.651271667439257) +
          1.0;
    } else {
      R = y * (y * (y * (y * (y * (y * -483.5191916086514 -
                                   1025.0951316110772) -
                              637.5664433683896) -
                         160.63638485582192) -
                    17.757954917754752) -
               0.799283237680523) -
          0.0098649429247001;
      P = y * (y * (y * (y * (y * (y * (y * -22.44095244658582 +
                                        474.52854120695537) +
                                   2553.0504064331644) +
                              3199.8582195085955) +
                         1536.729586084437) +
                    325.7925129965739) +
               30.33806074348246) +
          1.0;
    }
    if (!rtIsInf(absx) && !rtIsNaN(absx)) {
      y = frexp(absx, &eint);
    } else {
      y = absx;
      eint = 0;
    }
    y = floor(y * 2.097152E+6) / 2.097152E+6 * ldexp(1.0, eint);
    y = exp(-y * y - 0.5625) * exp((y - absx) * (y + absx) + R / P) / absx;
    if (x < 0.0) {
      y = 2.0 - y;
    }
  }
  return y;
}

/* End of code generation (eml_erfcore.c) */
