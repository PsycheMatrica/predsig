/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * main_core_terminate.h
 *
 * Code generation for function 'main_core_terminate'
 *
 */

#ifndef MAIN_CORE_TERMINATE_H
#define MAIN_CORE_TERMINATE_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void main_core_terminate(void);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (main_core_terminate.h) */
