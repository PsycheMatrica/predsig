/* Copyright (C) 2026 Gyeongcheol Cho. CC BY-NC-SA 4.0. */
#include <Rinternals.h>
#include <R_ext/Rdynload.h>
#include <R_ext/Visibility.h>
#include "main_core_initialize.h"
#include "main_core_terminate.h"

extern SEXP predsig_R_core(SEXP, SEXP, SEXP, SEXP, SEXP, SEXP);
extern SEXP predsig_R_supplementary(SEXP, SEXP, SEXP, SEXP, SEXP);
extern SEXP predsig_R_normality(SEXP);

static const R_CallMethodDef call_methods[] = {
    {"predsig_core", (DL_FUNC) &predsig_R_core, 6},
    {"predsig_supplementary", (DL_FUNC) &predsig_R_supplementary, 5},
    {"predsig_normality", (DL_FUNC) &predsig_R_normality, 1},
    {NULL, NULL, 0}
};

void attribute_visible R_init_predsig(DllInfo *dll)
{
    main_core_initialize();
    R_registerRoutines(dll, NULL, call_methods, NULL, NULL);
    R_useDynamicSymbols(dll, FALSE);
    R_forceSymbols(dll, TRUE);
}

void attribute_visible R_unload_predsig(DllInfo *dll)
{
    (void) dll;
    main_core_terminate();
}
