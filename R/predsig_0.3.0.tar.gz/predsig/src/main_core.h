/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * main_core.h
 *
 * Code generation for function 'main_core'
 *
 */

#ifndef MAIN_CORE_H
#define MAIN_CORE_H

/* Include files */
#include "main_core_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void main_core(double t, double sigma2_hat, double N, double P,
                      double abs_tol, double rel_tol, double *delEPE_hat,
                      double *delta_hat, double *p_pred, double *EPE1_hat);

void main_core_anonFcn1(double observed, double df, const emxArray_real_T *u,
                        emxArray_real_T *varargout_1);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (main_core.h) */
