/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * diag.c
 *
 * Code generation for function 'diag'
 *
 */

/* Include files */
#include "diag.h"
#include "main_core_emxutil.h"
#include "main_core_types.h"
#include "rt_nonfinite.h"

/* Function Definitions */
void diag(const emxArray_real_T *v, emxArray_real_T *d)
{
  const double *v_data;
  double *d_data;
  int32_t k;
  v_data = v->data;
  if ((v->size[0] == 1) && (v->size[1] == 1)) {
    int32_t u0;
    u0 = d->size[0];
    d->size[0] = 1;
    emxEnsureCapacity_real_T(d, u0);
    d_data = d->data;
    d_data[0] = v_data[0];
  } else {
    int32_t u0;
    int32_t u1;
    u0 = v->size[0];
    u1 = v->size[1];
    if (u0 <= u1) {
      u1 = u0;
    }
    if (v->size[1] <= 0) {
      u1 = 0;
    }
    u0 = d->size[0];
    d->size[0] = u1;
    emxEnsureCapacity_real_T(d, u0);
    d_data = d->data;
    for (k = 0; k < u1; k++) {
      d_data[k] = v_data[k + v->size[0] * k];
    }
  }
}

/* End of code generation (diag.c) */
