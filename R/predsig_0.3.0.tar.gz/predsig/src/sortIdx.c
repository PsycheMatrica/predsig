/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * sortIdx.c
 *
 * Code generation for function 'sortIdx'
 *
 */

/* Include files */
#include "sortIdx.h"
#include "main_core_emxutil.h"
#include "main_core_types.h"
#include "rt_nonfinite.h"
#include "rt_nonfinite.h"

/* Function Declarations */
static void merge(emxArray_int32_T *idx, emxArray_real_T *x, int32_t offset,
                  int32_t np, int32_t nq, emxArray_int32_T *iwork,
                  emxArray_real_T *xwork);

static void merge_block(emxArray_int32_T *idx, emxArray_real_T *x,
                        int32_t offset, int32_t n, int32_t preSortLevel,
                        emxArray_int32_T *iwork, emxArray_real_T *xwork);

/* Function Definitions */
static void merge(emxArray_int32_T *idx, emxArray_real_T *x, int32_t offset,
                  int32_t np, int32_t nq, emxArray_int32_T *iwork,
                  emxArray_real_T *xwork)
{
  double *x_data;
  double *xwork_data;
  int32_t j;
  int32_t *idx_data;
  int32_t *iwork_data;
  xwork_data = xwork->data;
  iwork_data = iwork->data;
  x_data = x->data;
  idx_data = idx->data;
  if (nq != 0) {
    int32_t iout;
    int32_t n;
    int32_t p;
    int32_t q;
    n = np + nq;
    for (j = 0; j < n; j++) {
      q = offset + j;
      iwork_data[j] = idx_data[q];
      xwork_data[j] = x_data[q];
    }
    p = 0;
    q = np;
    iout = offset - 1;
    int32_t exitg1;
    do {
      exitg1 = 0;
      iout++;
      if (xwork_data[p] <= xwork_data[q]) {
        idx_data[iout] = iwork_data[p];
        x_data[iout] = xwork_data[p];
        if (p + 1 < np) {
          p++;
        } else {
          exitg1 = 1;
        }
      } else {
        idx_data[iout] = iwork_data[q];
        x_data[iout] = xwork_data[q];
        if (q + 1 < n) {
          q++;
        } else {
          q = iout - p;
          for (j = p + 1; j <= np; j++) {
            iout = q + j;
            idx_data[iout] = iwork_data[j - 1];
            x_data[iout] = xwork_data[j - 1];
          }
          exitg1 = 1;
        }
      }
    } while (exitg1 == 0);
  }
}

static void merge_block(emxArray_int32_T *idx, emxArray_real_T *x,
                        int32_t offset, int32_t n, int32_t preSortLevel,
                        emxArray_int32_T *iwork, emxArray_real_T *xwork)
{
  int32_t bLen;
  int32_t k;
  int32_t nPairs;
  nPairs = n >> preSortLevel;
  bLen = 1 << preSortLevel;
  while (nPairs > 1) {
    int32_t tailOffset;
    if (((uint32_t)nPairs & 1U) != 0U) {
      int32_t nTail;
      nPairs--;
      tailOffset = bLen * nPairs;
      nTail = n - tailOffset;
      if (nTail > bLen) {
        merge(idx, x, offset + tailOffset, bLen, nTail - bLen, iwork, xwork);
      }
    }
    tailOffset = bLen << 1;
    nPairs >>= 1;
    for (k = 0; k < nPairs; k++) {
      merge(idx, x, offset + k * tailOffset, bLen, bLen, iwork, xwork);
    }
    bLen = tailOffset;
  }
  if (n > bLen) {
    merge(idx, x, offset, bLen, n - bLen, iwork, xwork);
  }
}

void sortIdx(emxArray_real_T *x, emxArray_int32_T *idx)
{
  emxArray_int32_T *iwork;
  emxArray_real_T *xwork;
  double x4[4];
  double *x_data;
  double *xwork_data;
  int32_t idx4[4];
  int32_t b;
  int32_t bLen;
  int32_t bLen2;
  int32_t b_b;
  int32_t b_k;
  int32_t i1;
  int32_t i2;
  int32_t i4;
  int32_t ib;
  int32_t k;
  int32_t n;
  int32_t nBlocks;
  int32_t quartetOffset;
  int32_t wOffset;
  int32_t *idx_data;
  int32_t *iwork_data;
  uint32_t unnamed_idx_0;
  x_data = x->data;
  unnamed_idx_0 = (uint32_t)x->size[0];
  i1 = idx->size[0];
  idx->size[0] = (int32_t)unnamed_idx_0;
  emxEnsureCapacity_int32_T(idx, i1);
  idx_data = idx->data;
  i1 = (int32_t)unnamed_idx_0;
  for (k = 0; k < i1; k++) {
    idx_data[k] = 0;
  }
  emxInit_int32_T(&iwork, 1);
  i1 = iwork->size[0];
  iwork->size[0] = (int32_t)unnamed_idx_0;
  emxEnsureCapacity_int32_T(iwork, i1);
  iwork_data = iwork->data;
  i1 = (int32_t)unnamed_idx_0;
  for (k = 0; k < i1; k++) {
    iwork_data[k] = 0;
  }
  emxInit_real_T(&xwork, 1);
  i1 = xwork->size[0];
  xwork->size[0] = (int32_t)unnamed_idx_0;
  emxEnsureCapacity_real_T(xwork, i1);
  xwork_data = xwork->data;
  n = x->size[0];
  x4[0] = 0.0;
  idx4[0] = 0;
  x4[1] = 0.0;
  idx4[1] = 0;
  x4[2] = 0.0;
  idx4[2] = 0;
  x4[3] = 0.0;
  idx4[3] = 0;
  nBlocks = 0;
  ib = 0;
  for (k = 0; k < n; k++) {
    if (rtIsNaN(x_data[k])) {
      i1 = (n - nBlocks) - 1;
      idx_data[i1] = k + 1;
      xwork_data[i1] = x_data[k];
      nBlocks++;
    } else {
      ib++;
      idx4[ib - 1] = k + 1;
      x4[ib - 1] = x_data[k];
      if (ib == 4) {
        double d;
        double d1;
        quartetOffset = k - nBlocks;
        if (x4[0] <= x4[1]) {
          i1 = 1;
          i2 = 2;
        } else {
          i1 = 2;
          i2 = 1;
        }
        if (x4[2] <= x4[3]) {
          ib = 3;
          i4 = 4;
        } else {
          ib = 4;
          i4 = 3;
        }
        d = x4[i1 - 1];
        d1 = x4[ib - 1];
        if (d <= d1) {
          if (x4[i2 - 1] <= d1) {
            bLen = i1;
            bLen2 = i2;
            i1 = ib;
            i2 = i4;
          } else if (x4[i2 - 1] <= x4[i4 - 1]) {
            bLen = i1;
            bLen2 = ib;
            i1 = i2;
            i2 = i4;
          } else {
            bLen = i1;
            bLen2 = ib;
            i1 = i4;
          }
        } else if (d <= x4[i4 - 1]) {
          if (x4[i2 - 1] <= x4[i4 - 1]) {
            bLen = ib;
            bLen2 = i1;
            i1 = i2;
            i2 = i4;
          } else {
            bLen = ib;
            bLen2 = i1;
            i1 = i4;
          }
        } else {
          bLen = ib;
          bLen2 = i4;
        }
        idx_data[quartetOffset - 3] = idx4[bLen - 1];
        idx_data[quartetOffset - 2] = idx4[bLen2 - 1];
        idx_data[quartetOffset - 1] = idx4[i1 - 1];
        idx_data[quartetOffset] = idx4[i2 - 1];
        x_data[quartetOffset - 3] = x4[bLen - 1];
        x_data[quartetOffset - 2] = x4[bLen2 - 1];
        x_data[quartetOffset - 1] = x4[i1 - 1];
        x_data[quartetOffset] = x4[i2 - 1];
        ib = 0;
      }
    }
  }
  wOffset = x->size[0] - nBlocks;
  if (ib > 0) {
    int8_t perm[4];
    perm[1] = 0;
    perm[2] = 0;
    perm[3] = 0;
    if (ib == 1) {
      perm[0] = 1;
    } else if (ib == 2) {
      if (x4[0] <= x4[1]) {
        perm[0] = 1;
        perm[1] = 2;
      } else {
        perm[0] = 2;
        perm[1] = 1;
      }
    } else if (x4[0] <= x4[1]) {
      if (x4[1] <= x4[2]) {
        perm[0] = 1;
        perm[1] = 2;
        perm[2] = 3;
      } else if (x4[0] <= x4[2]) {
        perm[0] = 1;
        perm[1] = 3;
        perm[2] = 2;
      } else {
        perm[0] = 3;
        perm[1] = 1;
        perm[2] = 2;
      }
    } else if (x4[0] <= x4[2]) {
      perm[0] = 2;
      perm[1] = 1;
      perm[2] = 3;
    } else if (x4[1] <= x4[2]) {
      perm[0] = 2;
      perm[1] = 3;
      perm[2] = 1;
    } else {
      perm[0] = 3;
      perm[1] = 2;
      perm[2] = 1;
    }
    i1 = (uint8_t)ib;
    for (k = 0; k < i1; k++) {
      quartetOffset = (wOffset - ib) + k;
      i2 = perm[k];
      idx_data[quartetOffset] = idx4[i2 - 1];
      x_data[quartetOffset] = x4[i2 - 1];
    }
  }
  i1 = nBlocks >> 1;
  for (k = 0; k < i1; k++) {
    quartetOffset = wOffset + k;
    i2 = idx_data[quartetOffset];
    ib = (n - k) - 1;
    idx_data[quartetOffset] = idx_data[ib];
    idx_data[ib] = i2;
    x_data[quartetOffset] = xwork_data[ib];
    x_data[ib] = xwork_data[quartetOffset];
  }
  if (((uint32_t)nBlocks & 1U) != 0U) {
    i1 += wOffset;
    x_data[i1] = xwork_data[i1];
  }
  i1 = 2;
  if (wOffset > 1) {
    if (x->size[0] >= 256) {
      nBlocks = wOffset >> 8;
      if (nBlocks > 0) {
        for (b = 0; b < nBlocks; b++) {
          double b_xwork[256];
          int32_t b_iwork[256];
          i4 = (b << 8) - 1;
          for (b_b = 0; b_b < 6; b_b++) {
            bLen = 1 << (b_b + 2);
            bLen2 = bLen << 1;
            n = 256 >> (b_b + 3);
            for (b_k = 0; b_k < n; b_k++) {
              i1 = (i4 + b_k * bLen2) + 1;
              for (k = 0; k < bLen2; k++) {
                ib = i1 + k;
                b_iwork[k] = idx_data[ib];
                b_xwork[k] = x_data[ib];
              }
              i2 = 0;
              quartetOffset = bLen;
              ib = i1 - 1;
              int32_t exitg1;
              do {
                exitg1 = 0;
                ib++;
                if (b_xwork[i2] <= b_xwork[quartetOffset]) {
                  idx_data[ib] = b_iwork[i2];
                  x_data[ib] = b_xwork[i2];
                  if (i2 + 1 < bLen) {
                    i2++;
                  } else {
                    exitg1 = 1;
                  }
                } else {
                  idx_data[ib] = b_iwork[quartetOffset];
                  x_data[ib] = b_xwork[quartetOffset];
                  if (quartetOffset + 1 < bLen2) {
                    quartetOffset++;
                  } else {
                    ib -= i2;
                    for (k = i2 + 1; k <= bLen; k++) {
                      quartetOffset = ib + k;
                      idx_data[quartetOffset] = b_iwork[k - 1];
                      x_data[quartetOffset] = b_xwork[k - 1];
                    }
                    exitg1 = 1;
                  }
                }
              } while (exitg1 == 0);
            }
          }
        }
        i1 = nBlocks << 8;
        quartetOffset = wOffset - i1;
        if (quartetOffset > 0) {
          merge_block(idx, x, i1, quartetOffset, 2, iwork, xwork);
        }
        i1 = 8;
      }
    }
    merge_block(idx, x, 0, wOffset, i1, iwork, xwork);
  }
  emxFree_real_T(&xwork);
  emxFree_int32_T(&iwork);
}

/* End of code generation (sortIdx.c) */
