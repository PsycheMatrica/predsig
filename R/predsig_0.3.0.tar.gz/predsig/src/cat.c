/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * cat.c
 *
 * Code generation for function 'cat'
 *
 */

/* Include files */
#include "cat.h"
#include "main_core_emxutil.h"
#include "main_core_types.h"
#include "rt_nonfinite.h"

/* Function Definitions */
void binary_expand_op_3(emxArray_real_T *in1, const emxArray_real_T *in2,
                        int32_t in3, int32_t in4, const emxArray_real_T *in5,
                        double in6, int32_t in7, const emxArray_real_T *in8,
                        int32_t in9, int32_t in10)
{
  emxArray_real_T *b_in2;
  const double *in2_data;
  const double *in5_data;
  const double *in8_data;
  double *b_in2_data;
  double *in1_data;
  int32_t i;
  int32_t loop_ub;
  int32_t stride_0_0;
  int32_t stride_1_0;
  in8_data = in8->data;
  in5_data = in5->data;
  in2_data = in2->data;
  emxInit_real_T(&b_in2, 1);
  if (in5->size[1] == 1) {
    loop_ub = (in4 - in3) + 1;
  } else {
    loop_ub = in5->size[1];
  }
  stride_0_0 = b_in2->size[0];
  b_in2->size[0] = loop_ub;
  emxEnsureCapacity_real_T(b_in2, stride_0_0);
  b_in2_data = b_in2->data;
  stride_0_0 = (in4 - in3 != 0);
  stride_1_0 = (in5->size[1] != 1);
  for (i = 0; i < loop_ub; i++) {
    b_in2_data[i] =
        in2_data[in3 + i * stride_0_0] * in5_data[i * stride_1_0] / in6;
  }
  stride_0_0 = in1->size[0] * in1->size[1];
  in1->size[0] = loop_ub;
  in1->size[1] = 3;
  emxEnsureCapacity_real_T(in1, stride_0_0);
  in1_data = in1->data;
  for (i = 0; i < loop_ub; i++) {
    in1_data[i] = b_in2_data[i];
  }
  emxFree_real_T(&b_in2);
  stride_0_0 = in10 - in9;
  for (i = 0; i <= stride_0_0; i++) {
    in1_data[i + in1->size[0]] = 1.0 / ((double)in7 * in8_data[in9 + i]);
  }
  for (i = 0; i <= stride_0_0; i++) {
    in1_data[i + in1->size[0] * 2] = in8_data[in9 + i];
  }
}

/* End of code generation (cat.c) */
