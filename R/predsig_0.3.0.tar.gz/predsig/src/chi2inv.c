/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * chi2inv.c
 *
 * Code generation for function 'chi2inv'
 *
 */

/* Include files */
#include "chi2inv.h"
#include "gammaincinv.h"
#include "gammaln.h"
#include "rt_nonfinite.h"
#include "rt_nonfinite.h"
#include <math.h>

/* Function Definitions */
double b_chi2inv(double v)
{
  double d;
  double d1;
  double x;
  x = v / 2.0;
  if ((x >= 0.0) && !rtIsInf(x)) {
    if (x > 0.0) {
      d = x;
      gammaln(&d);
      d1 = x + 1.0;
      gammaln(&d1);
      x = eml_gammaincinv(0.999999999999, x, log(x), d, d1) * 2.0;
    } else {
      x = 0.0;
    }
  } else {
    x = rtNaN;
  }
  return x;
}

double chi2inv(double v)
{
  double d;
  double d1;
  double x;
  x = v / 2.0;
  if ((x >= 0.0) && !rtIsInf(x)) {
    if (x > 0.0) {
      d = x;
      gammaln(&d);
      d1 = x + 1.0;
      gammaln(&d1);
      x = eml_gammaincinv(1.0E-12, x, log(x), d, d1) * 2.0;
    } else {
      x = 0.0;
    }
  } else {
    x = rtNaN;
  }
  return x;
}

/* End of code generation (chi2inv.c) */
