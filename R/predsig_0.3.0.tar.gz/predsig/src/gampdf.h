/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * gampdf.h
 *
 * Code generation for function 'gampdf'
 *
 */

#ifndef GAMPDF_H
#define GAMPDF_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
double f(double z, double a);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (gampdf.h) */
