/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * eps.c
 *
 * Code generation for function 'eps'
 *
 */

/* Include files */
#include "eps.h"
#include "rt_nonfinite.h"
#include "rt_nonfinite.h"
#include <math.h>

/* Function Definitions */
double eps(double x)
{
  double r;
  int32_t exponent;
  if (rtIsInf(x) || rtIsNaN(x)) {
    r = rtNaN;
  } else if (x < 4.450147717014403E-308) {
    r = 5.0E-324;
  } else {
    frexp(x, &exponent);
    r = ldexp(1.0, exponent - 53);
  }
  return r;
}

/* End of code generation (eps.c) */
