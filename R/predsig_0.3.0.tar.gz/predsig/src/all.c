/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * all.c
 *
 * Code generation for function 'all'
 *
 */

/* Include files */
#include "all.h"
#include "main_core_types.h"
#include "rt_nonfinite.h"

/* Function Definitions */
boolean_T all(const emxArray_boolean_T *x)
{
  int32_t ix;
  const boolean_T *x_data;
  boolean_T exitg1;
  boolean_T y;
  x_data = x->data;
  y = true;
  ix = 1;
  exitg1 = false;
  while (!exitg1 && (ix <= x->size[0])) {
    if (!x_data[ix - 1]) {
      y = false;
      exitg1 = true;
    } else {
      ix++;
    }
  }
  return y;
}

boolean_T b_all(const boolean_T x[7])
{
  int32_t k;
  boolean_T exitg1;
  boolean_T y;
  y = true;
  k = 0;
  exitg1 = false;
  while (!exitg1 && (k < 7)) {
    if (!x[k]) {
      y = false;
      exitg1 = true;
    } else {
      k++;
    }
  }
  return y;
}

/* End of code generation (all.c) */
