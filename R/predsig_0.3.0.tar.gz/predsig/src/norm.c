/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * norm.c
 *
 * Code generation for function 'norm'
 *
 */

/* Include files */
#include "norm.h"
#include "main_core_types.h"
#include "rt_nonfinite.h"
#include "rt_nonfinite.h"
#include <math.h>

/* Function Definitions */
double b_norm(const emxArray_real_T *x)
{
  const double *x_data;
  double y;
  int32_t j;
  boolean_T MATRIX_INPUT_AND_P_IS_INF;
  boolean_T VECTOR_INPUT_AND_P_IS_INF;
  x_data = x->data;
  VECTOR_INPUT_AND_P_IS_INF = false;
  MATRIX_INPUT_AND_P_IS_INF = false;
  if ((x->size[0] == 1) || (x->size[1] == 1)) {
    VECTOR_INPUT_AND_P_IS_INF = true;
  } else {
    MATRIX_INPUT_AND_P_IS_INF = true;
  }
  if ((x->size[0] == 0) || (x->size[1] == 0)) {
    y = 0.0;
  } else if (MATRIX_INPUT_AND_P_IS_INF) {
    int32_t i;
    boolean_T exitg1;
    y = 0.0;
    i = 0;
    exitg1 = false;
    while (!exitg1 && (i <= x->size[0] - 1)) {
      double s;
      int32_t b_i;
      s = 0.0;
      b_i = x->size[1];
      for (j = 0; j < b_i; j++) {
        s += fabs(x_data[i + x->size[0] * j]);
      }
      if (rtIsNaN(s)) {
        y = rtNaN;
        exitg1 = true;
      } else {
        if (s > y) {
          y = s;
        }
        i++;
      }
    }
  } else if (VECTOR_INPUT_AND_P_IS_INF) {
    int32_t i;
    y = 0.0;
    i = x->size[0] * x->size[1];
    for (j = 0; j < i; j++) {
      double s;
      s = fabs(x_data[j]);
      if (rtIsNaN(s) || (s > y)) {
        y = s;
      }
    }
  } else {
    y = rtNaN;
  }
  return y;
}

/* End of code generation (norm.c) */
