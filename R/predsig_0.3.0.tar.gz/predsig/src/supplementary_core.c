/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * supplementary_core.c
 *
 * Code generation for function 'supplementary_core'
 *
 */

/* Include files */
#include "supplementary_core.h"
#include "abs.h"
#include "any.h"
#include "blockedSummation.h"
#include "cat.h"
#include "diag.h"
#include "eps.h"
#include "eye.h"
#include "main_core_emxutil.h"
#include "main_core_types.h"
#include "minOrMax.h"
#include "mldivide.h"
#include "norm.h"
#include "qr.h"
#include "rt_nonfinite.h"
#include "sqrt.h"
#include "std.h"
#include "sum.h"
#include "var.h"
#include "vvarstd.h"
#include "rt_nonfinite.h"
#include <math.h>

/* Function Declarations */
static void binary_expand_op_4(emxArray_real_T *in1, const emxArray_real_T *in2,
                               const emxArray_real_T *in3,
                               const emxArray_real_T *in4, int32_t in5,
                               int32_t in6);

static void binary_expand_op_5(emxArray_real_T *in1,
                               const emxArray_real_T *in2);

static void binary_expand_op_6(emxArray_real_T *in1, const emxArray_real_T *in2,
                               const emxArray_real_T *in3,
                               const emxArray_real_T *in4);

/* Function Definitions */
static void binary_expand_op_4(emxArray_real_T *in1, const emxArray_real_T *in2,
                               const emxArray_real_T *in3,
                               const emxArray_real_T *in4, int32_t in5,
                               int32_t in6)
{
  const double *in3_data;
  const double *in4_data;
  double b_in2;
  double *in1_data;
  int32_t i;
  int32_t i1;
  int32_t loop_ub;
  int32_t stride_0_0;
  int32_t stride_1_0;
  in4_data = in4->data;
  in3_data = in3->data;
  b_in2 = (double)in2->size[0] - 1.0;
  i = in6 - in5;
  if (i == 0) {
    loop_ub = in3->size[1];
  } else {
    loop_ub = i + 1;
  }
  stride_1_0 = in1->size[0];
  in1->size[0] = loop_ub;
  emxEnsureCapacity_real_T(in1, stride_1_0);
  in1_data = in1->data;
  stride_0_0 = (in3->size[1] != 1);
  stride_1_0 = (i != 0);
  for (i1 = 0; i1 < loop_ub; i1++) {
    in1_data[i1] =
        b_in2 * in3_data[i1 * stride_0_0] * in4_data[in5 + i1 * stride_1_0];
  }
}

static void binary_expand_op_5(emxArray_real_T *in1, const emxArray_real_T *in2)
{
  emxArray_real_T *b_in2;
  const double *in2_data;
  double *b_in2_data;
  double *in1_data;
  int32_t i;
  int32_t loop_ub;
  int32_t stride_0_0;
  int32_t stride_1_0;
  in2_data = in2->data;
  in1_data = in1->data;
  emxInit_real_T(&b_in2, 1);
  if (in1->size[0] == 1) {
    loop_ub = in2->size[0];
  } else {
    loop_ub = in1->size[0];
  }
  stride_0_0 = b_in2->size[0];
  b_in2->size[0] = loop_ub;
  emxEnsureCapacity_real_T(b_in2, stride_0_0);
  b_in2_data = b_in2->data;
  stride_0_0 = (in2->size[0] != 1);
  stride_1_0 = (in1->size[0] != 1);
  for (i = 0; i < loop_ub; i++) {
    b_in2_data[i] = in2_data[i * stride_0_0] - in1_data[i * stride_1_0];
  }
  b_abs(b_in2, in1);
  emxFree_real_T(&b_in2);
}

static void binary_expand_op_6(emxArray_real_T *in1, const emxArray_real_T *in2,
                               const emxArray_real_T *in3,
                               const emxArray_real_T *in4)
{
  emxArray_real_T *b_in2;
  const double *in2_data;
  const double *in3_data;
  const double *in4_data;
  double *b_in2_data;
  double *in1_data;
  int32_t i;
  int32_t i1;
  int32_t loop_ub;
  int32_t stride_0_0;
  int32_t stride_1_0;
  in4_data = in4->data;
  in3_data = in3->data;
  in2_data = in2->data;
  stride_1_0 = in3->size[0];
  loop_ub = in3->size[1];
  stride_0_0 = in1->size[0];
  in1->size[0] = stride_1_0;
  emxEnsureCapacity_real_T(in1, stride_0_0);
  in1_data = in1->data;
  for (i = 0; i < stride_1_0; i++) {
    in1_data[i] = 0.0;
  }
  for (i = 0; i < loop_ub; i++) {
    double d;
    d = in4_data[i];
    for (i1 = 0; i1 < stride_1_0; i1++) {
      in1_data[i1] += in3_data[i1 + in3->size[0] * i] * d;
    }
  }
  emxInit_real_T(&b_in2, 1);
  if (in1->size[0] == 1) {
    loop_ub = in2->size[0];
  } else {
    loop_ub = in1->size[0];
  }
  stride_0_0 = b_in2->size[0];
  b_in2->size[0] = loop_ub;
  emxEnsureCapacity_real_T(b_in2, stride_0_0);
  b_in2_data = b_in2->data;
  stride_0_0 = (in2->size[0] != 1);
  stride_1_0 = (in1->size[0] != 1);
  for (i = 0; i < loop_ub; i++) {
    b_in2_data[i] = in2_data[i * stride_0_0] - in1_data[i * stride_1_0];
  }
  stride_0_0 = in1->size[0];
  in1->size[0] = loop_ub;
  emxEnsureCapacity_real_T(in1, stride_0_0);
  in1_data = in1->data;
  for (i = 0; i < loop_ub; i++) {
    in1_data[i] = b_in2_data[i];
  }
  emxFree_real_T(&b_in2);
}

void supplementary_core(const emxArray_real_T *y, const emxArray_real_T *X,
                        const emxArray_real_T *b, const emxArray_real_T *se,
                        double sigma2, emxArray_real_T *ResultsMat,
                        emxArray_real_T *residuals, emxArray_real_T *leverage,
                        emxArray_real_T *VIF, double *status)
{
  emxArray_boolean_T *c_y;
  emxArray_real_T *D;
  emxArray_real_T *Q;
  emxArray_real_T *R;
  emxArray_real_T *all_variance_factors;
  emxArray_real_T *b_y;
  emxArray_real_T *r;
  emxArray_real_T *r1;
  emxArray_real_T *r2;
  const double *X_data;
  const double *b_data;
  const double *se_data;
  const double *y_data;
  double checkScale;
  double *D_data;
  double *Q_data;
  double *ResultsMat_data;
  double *all_variance_factors_data;
  double *b_y_data;
  double *residuals_data;
  int32_t b_loop_ub;
  int32_t b_status;
  int32_t c_loop_ub;
  int32_t df_aux;
  int32_t i;
  int32_t i1;
  int32_t loop_ub;
  int32_t sizes_idx_1;
  int8_t input_sizes_idx_1;
  boolean_T empty_non_axis_sizes;
  boolean_T *c_y_data;
  se_data = se->data;
  b_data = b->data;
  X_data = X->data;
  y_data = y->data;
  /* SUPPLEMENTARY_CORE Check an OLS fit and calculate supplementary results. */
  /*    X contains the P predictors in slope order. y, b, and se are column */
  /*    vectors. b and se include the intercept first. */
  /*    sigma2 is SSE/df from the supplied ordinary least squares fit. */
  /*    Each row of ResultsMat contains [standardized_beta, */
  /*    predictor_residual_variance, variance_factor]. */
  /*    residuals and leverage follow the retained sample. VIF follows slope
   * order. */
  /*    Status: 0 success, 1 rank deficient, 2 invalid variance, 3 fit mismatch.
   */
  /*    The callers validate input shapes and model scope before invoking this
   */
  /*    engine and translate a nonzero status into the public error message. */
  /*    Copyright (C) 2026 Gyeongcheol Cho. CC BY-NC-SA 4.0; see LICENSE. */
  /*  1. Allocate results and derive dimensions (SUPPORT) */
  df_aux = X->size[0] - X->size[1];
  loop_ub = X->size[1];
  b_loop_ub = ResultsMat->size[0] * ResultsMat->size[1];
  ResultsMat->size[0] = X->size[1];
  ResultsMat->size[1] = 3;
  emxEnsureCapacity_real_T(ResultsMat, b_loop_ub);
  ResultsMat_data = ResultsMat->data;
  b_loop_ub = X->size[1] * 3;
  for (i = 0; i < b_loop_ub; i++) {
    ResultsMat_data[i] = rtNaN;
  }
  sizes_idx_1 = X->size[0];
  b_loop_ub = residuals->size[0];
  residuals->size[0] = X->size[0];
  emxEnsureCapacity_real_T(residuals, b_loop_ub);
  residuals_data = residuals->data;
  b_loop_ub = leverage->size[0];
  leverage->size[0] = X->size[0];
  emxEnsureCapacity_real_T(leverage, b_loop_ub);
  ResultsMat_data = leverage->data;
  for (i = 0; i < sizes_idx_1; i++) {
    residuals_data[i] = rtNaN;
    ResultsMat_data[i] = rtNaN;
  }
  b_loop_ub = VIF->size[0];
  VIF->size[0] = X->size[1];
  emxEnsureCapacity_real_T(VIF, b_loop_ub);
  ResultsMat_data = VIF->data;
  for (i = 0; i < loop_ub; i++) {
    ResultsMat_data[i] = rtNaN;
  }
  b_status = 0;
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   */
  /*  2. Factor the retained design once (CORE) */
  /*  With D=Q*R, the row sums of (R^(-1)).^2 give the diagonal of (D'*D)^(-1).
   */
  /*  The intercept variance factor comes first, followed by the P slope v_p. */
  if (X->size[0] != 0) {
    loop_ub = X->size[0];
  } else {
    loop_ub = 0;
  }
  empty_non_axis_sizes = (loop_ub == 0);
  if (empty_non_axis_sizes || (X->size[0] != 0)) {
    input_sizes_idx_1 = 1;
  } else {
    input_sizes_idx_1 = 0;
  }
  if (empty_non_axis_sizes || ((X->size[0] != 0) && (X->size[1] != 0))) {
    sizes_idx_1 = X->size[1];
  } else {
    sizes_idx_1 = 0;
  }
  emxInit_real_T(&D, 2);
  b_loop_ub = D->size[0] * D->size[1];
  D->size[0] = loop_ub;
  c_loop_ub = input_sizes_idx_1 + sizes_idx_1;
  D->size[1] = c_loop_ub;
  emxEnsureCapacity_real_T(D, b_loop_ub);
  D_data = D->data;
  b_loop_ub = input_sizes_idx_1;
  for (i = 0; i < b_loop_ub; i++) {
    for (i1 = 0; i1 < loop_ub; i1++) {
      D_data[i1] = 1.0;
    }
  }
  for (i = 0; i < sizes_idx_1; i++) {
    for (i1 = 0; i1 < loop_ub; i1++) {
      D_data[i1 + D->size[0] * (i + input_sizes_idx_1)] =
          X_data[i1 + loop_ub * i];
    }
  }
  emxInit_real_T(&Q, 2);
  emxInit_real_T(&R, 2);
  qr(D, Q, R);
  Q_data = Q->data;
  emxInit_real_T(&r, 1);
  diag(R, r);
  emxInit_real_T(&b_y, 1);
  b_abs(r, b_y);
  b_y_data = b_y->data;
  checkScale = fmax(X->size[0], (double)X->size[1] + 1.0) * eps(b_norm(R));
  emxInit_boolean_T(&c_y);
  sizes_idx_1 = b_y->size[0];
  b_loop_ub = c_y->size[0];
  c_y->size[0] = b_y->size[0];
  emxEnsureCapacity_boolean_T(c_y, b_loop_ub);
  c_y_data = c_y->data;
  for (i = 0; i < sizes_idx_1; i++) {
    c_y_data[i] = (b_y_data[i] <= checkScale);
  }
  emxInit_real_T(&all_variance_factors, 1);
  emxInit_real_T(&r1, 2);
  emxInit_real_T(&r2, 2);
  if (any(c_y)) {
    b_status = 1;
  } else {
    double y_sd;
    int32_t i2;
    int32_t i3;
    eye((double)X->size[1] + 1.0, r1);
    mldivide(R, r1);
    b_y_data = r1->data;
    b_loop_ub = R->size[0] * R->size[1];
    R->size[0] = r1->size[0];
    R->size[1] = r1->size[1];
    emxEnsureCapacity_real_T(R, b_loop_ub);
    ResultsMat_data = R->data;
    b_loop_ub = r1->size[0] * r1->size[1];
    for (i = 0; i < b_loop_ub; i++) {
      checkScale = b_y_data[i];
      ResultsMat_data[i] = checkScale * checkScale;
    }
    sum(R, all_variance_factors);
    all_variance_factors_data = all_variance_factors->data;
    if (all_variance_factors->size[0] < 2) {
      i2 = 0;
      i3 = -1;
    } else {
      i2 = 1;
      i3 = all_variance_factors->size[0] - 1;
    }
    /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     */
    /*  3. Check the fitted variance and OLS consistency (CHECK) */
    /*  Cross-check the variance and standard errors from the supplied fit
     * against */
    /*  its retained sample. The wrapper uses the supplied fit for inference. */
    y_sd = vvarstd(y, y->size[0]);
    if (rtIsInf(sigma2) || rtIsNaN(sigma2) || (sigma2 <= 0.0) ||
        (rtIsInf(y_sd) || rtIsNaN(y_sd)) || (y_sd <= 0.0)) {
      b_status = 2;
    } else {
      if (y->size[0] == D->size[0]) {
        b_loop_ub = residuals->size[0];
        residuals->size[0] = loop_ub;
        emxEnsureCapacity_real_T(residuals, b_loop_ub);
        residuals_data = residuals->data;
        for (i = 0; i < loop_ub; i++) {
          checkScale = 0.0;
          for (i1 = 0; i1 < c_loop_ub; i1++) {
            checkScale += D_data[i + D->size[0] * i1] * b_data[i1];
          }
          residuals_data[i] = y_data[i] - checkScale;
        }
      } else {
        binary_expand_op_6(residuals, y, D, b);
        residuals_data = residuals->data;
      }
      b_abs(se, r);
      ResultsMat_data = r->data;
      b_loop_ub = b_y->size[0];
      b_y->size[0] = r->size[0] + 1;
      emxEnsureCapacity_real_T(b_y, b_loop_ub);
      b_y_data = b_y->data;
      b_y_data[0] = 1.0;
      b_loop_ub = r->size[0];
      for (i = 0; i < b_loop_ub; i++) {
        b_y_data[i + 1] = ResultsMat_data[i];
      }
      checkScale = maximum(b_y);
      sizes_idx_1 = all_variance_factors->size[0];
      b_loop_ub = r->size[0];
      r->size[0] = all_variance_factors->size[0];
      emxEnsureCapacity_real_T(r, b_loop_ub);
      ResultsMat_data = r->data;
      for (i = 0; i < sizes_idx_1; i++) {
        ResultsMat_data[i] = sigma2 * all_variance_factors_data[i];
      }
      c_sqrt(r);
      ResultsMat_data = r->data;
      if (se->size[0] == r->size[0]) {
        sizes_idx_1 = se->size[0];
        b_loop_ub = b_y->size[0];
        b_y->size[0] = se->size[0];
        emxEnsureCapacity_real_T(b_y, b_loop_ub);
        b_y_data = b_y->data;
        for (i = 0; i < sizes_idx_1; i++) {
          b_y_data[i] = se_data[i] - ResultsMat_data[i];
        }
        b_abs(b_y, r);
        ResultsMat_data = r->data;
      } else {
        binary_expand_op_5(r, se);
        ResultsMat_data = r->data;
      }
      checkScale *= 2.0E-8;
      sizes_idx_1 = r->size[0];
      b_loop_ub = c_y->size[0];
      c_y->size[0] = r->size[0];
      emxEnsureCapacity_boolean_T(c_y, b_loop_ub);
      c_y_data = c_y->data;
      for (i = 0; i < sizes_idx_1; i++) {
        c_y_data[i] = (ResultsMat_data[i] > checkScale);
      }
      if (any(c_y)) {
        b_status = 3;
      } else {
        sizes_idx_1 = residuals->size[0];
        b_loop_ub = b_y->size[0];
        b_y->size[0] = residuals->size[0];
        emxEnsureCapacity_real_T(b_y, b_loop_ub);
        b_y_data = b_y->data;
        for (i = 0; i < sizes_idx_1; i++) {
          checkScale = residuals_data[i];
          b_y_data[i] = checkScale * checkScale;
        }
        if (fabs(blockedSummation(b_y, b_y->size[0]) / ((double)df_aux - 1.0) -
                 sigma2) > 2.0E-8 * fmax(1.0, sigma2)) {
          b_status = 3;
        } else {
          int32_t i4;
          /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
           */
          /*  4. Calculate supplementary fitted-model quantities (CORE) */
          if (b->size[0] < 2) {
            i4 = 0;
            loop_ub = 0;
          } else {
            i4 = 1;
            loop_ub = b->size[0];
          }
          /*  The auxiliary residual variance estimate equals RSS_aux/(N-P) by
           * (B14). */
          b_loop_ub = r1->size[0] * r1->size[1];
          r1->size[0] = Q->size[0];
          r1->size[1] = Q->size[1];
          emxEnsureCapacity_real_T(r1, b_loop_ub);
          b_y_data = r1->data;
          b_loop_ub = Q->size[0] * Q->size[1];
          for (i = 0; i < b_loop_ub; i++) {
            checkScale = Q_data[i];
            b_y_data[i] = checkScale * checkScale;
          }
          sum(r1, leverage);
          var(X, r2);
          b_y_data = r2->data;
          c_loop_ub = i3 - i2;
          if (r2->size[1] == c_loop_ub + 1) {
            sizes_idx_1 = r2->size[1];
            b_loop_ub = VIF->size[0];
            VIF->size[0] = r2->size[1];
            emxEnsureCapacity_real_T(VIF, b_loop_ub);
            ResultsMat_data = VIF->data;
            for (i = 0; i < sizes_idx_1; i++) {
              ResultsMat_data[i] = ((double)X->size[0] - 1.0) * b_y_data[i] *
                                   all_variance_factors_data[i2 + i];
            }
          } else {
            binary_expand_op_4(VIF, X, r2, all_variance_factors, i2, i3);
          }
          b_std(X, r2);
          b_y_data = r2->data;
          sizes_idx_1 = loop_ub - i4;
          if (sizes_idx_1 == r2->size[1]) {
            b_loop_ub = ResultsMat->size[0] * ResultsMat->size[1];
            ResultsMat->size[0] = sizes_idx_1;
            ResultsMat->size[1] = 3;
            emxEnsureCapacity_real_T(ResultsMat, b_loop_ub);
            ResultsMat_data = ResultsMat->data;
            for (i = 0; i < sizes_idx_1; i++) {
              ResultsMat_data[i] = b_data[i4 + i] * b_y_data[i] / y_sd;
            }
            for (i = 0; i <= c_loop_ub; i++) {
              ResultsMat_data[i + ResultsMat->size[0]] =
                  1.0 / ((double)df_aux * all_variance_factors_data[i2 + i]);
            }
            for (i = 0; i <= c_loop_ub; i++) {
              ResultsMat_data[i + ResultsMat->size[0] * 2] =
                  all_variance_factors_data[i2 + i];
            }
          } else {
            binary_expand_op_3(ResultsMat, b, i4, loop_ub - 1, r2, y_sd, df_aux,
                               all_variance_factors, i2, i3);
          }
          /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
           */
        }
      }
    }
  }
  emxFree_real_T(&r);
  emxFree_boolean_T(&c_y);
  emxFree_real_T(&r2);
  emxFree_real_T(&r1);
  emxFree_real_T(&b_y);
  emxFree_real_T(&R);
  emxFree_real_T(&Q);
  emxFree_real_T(&all_variance_factors);
  emxFree_real_T(&D);
  *status = b_status;
}

/* End of code generation (supplementary_core.c) */
