/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * blockedSummation.c
 *
 * Code generation for function 'blockedSummation'
 *
 */

/* Include files */
#include "blockedSummation.h"
#include "main_core_types.h"
#include "rt_nonfinite.h"

/* Function Definitions */
double blockedSummation(const emxArray_real_T *x, int32_t vlen)
{
  const double *x_data;
  double y;
  int32_t b_k;
  int32_t k;
  x_data = x->data;
  if ((x->size[0] == 0) || (vlen == 0)) {
    y = 0.0;
  } else {
    int32_t firstBlockLength;
    int32_t lastBlockLength;
    int32_t nblocks;
    if (vlen <= 1024) {
      firstBlockLength = vlen;
      lastBlockLength = 0;
      nblocks = 1;
    } else {
      firstBlockLength = 1024;
      nblocks = (int32_t)((uint32_t)vlen >> 10);
      lastBlockLength = vlen - (nblocks << 10);
      if (lastBlockLength > 0) {
        nblocks++;
      } else {
        lastBlockLength = 1024;
      }
    }
    y = x_data[0];
    for (k = 2; k <= firstBlockLength; k++) {
      y += x_data[k - 1];
    }
    for (k = 2; k <= nblocks; k++) {
      double bsum;
      int32_t hi;
      firstBlockLength = (k - 1) << 10;
      bsum = x_data[firstBlockLength];
      if (k == nblocks) {
        hi = lastBlockLength;
      } else {
        hi = 1024;
      }
      for (b_k = 2; b_k <= hi; b_k++) {
        bsum += x_data[(firstBlockLength + b_k) - 1];
      }
      y += bsum;
    }
  }
  return y;
}

/* End of code generation (blockedSummation.c) */
