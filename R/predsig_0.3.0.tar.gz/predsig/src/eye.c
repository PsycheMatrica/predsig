/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * eye.c
 *
 * Code generation for function 'eye'
 *
 */

/* Include files */
#include "eye.h"
#include "main_core_emxutil.h"
#include "main_core_types.h"
#include "rt_nonfinite.h"

/* Function Definitions */
void eye(double varargin_1, emxArray_real_T *b_I)
{
  double *I_data;
  int32_t k;
  int32_t loop_ub;
  int32_t m;
  m = (int32_t)varargin_1;
  loop_ub = b_I->size[0] * b_I->size[1];
  b_I->size[0] = (int32_t)varargin_1;
  b_I->size[1] = (int32_t)varargin_1;
  emxEnsureCapacity_real_T(b_I, loop_ub);
  I_data = b_I->data;
  loop_ub = (int32_t)varargin_1 * (int32_t)varargin_1;
  for (k = 0; k < loop_ub; k++) {
    I_data[k] = 0.0;
  }
  for (k = 0; k < m; k++) {
    I_data[k + b_I->size[0] * k] = 1.0;
  }
}

/* End of code generation (eye.c) */
