/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * gammaincinv.c
 *
 * Code generation for function 'gammaincinv'
 *
 */

/* Include files */
#include "gammaincinv.h"
#include "eml_gammainc.h"
#include "main_core_rtwutil.h"
#include "rt_nonfinite.h"
#include <math.h>

/* Function Definitions */
double eml_gammaincinv(double p, double a, double la, double lga, double lgap1)
{
  double rval;
  boolean_T upper;
  upper = false;
  if (a == rtInf) {
    rval = rtInf;
  } else if (lga == rtInf) {
    rval = a;
  } else {
    double b_f;
    double ftol1;
    double log1mpLower;
    double nu;
    double oldz;
    double pLower;
    int32_t i;
    int32_t sgn;
    boolean_T exitg1;
    nu = 2.0 * a;
    if (p > 0.5) {
      p = 9.999778782798785E-13;
      upper = true;
      pLower = 0.999999999999;
      log1mpLower = -27.63104323789336;
    } else {
      pLower = p;
      log1mpLower = -9.999778782803785E-13 * (-p / -9.999778782798785E-13);
    }
    b_f = log(pLower);
    if (nu < -1.24 * b_f) {
      pLower =
          rt_powd_snf(pLower * exp(lgap1 + a * 0.693147180559945), 1.0 / a);
      if (pLower < 2.2250738585072014E-306) {
        pLower = 2.2250738585072014E-306;
      }
    } else if (nu <= 0.32) {
      pLower = 0.4;
      i = 0;
      exitg1 = false;
      while (!exitg1 && (i < 200)) {
        oldz = pLower;
        ftol1 = pLower * (pLower + 4.67) + 1.0;
        b_f = pLower * (pLower * (pLower + 6.66) + 6.73);
        pLower -= (1.0 - exp(((log1mpLower + lga) + 0.5 * pLower) +
                             (a - 1.0) * 0.693147180559945) *
                             b_f / ftol1) /
                  (((2.0 * pLower + 4.67) / ftol1 - 0.5) -
                   (pLower * (3.0 * pLower + 13.32) + 6.73) / b_f);
        if (fabs(oldz - pLower) < 0.01 * pLower) {
          exitg1 = true;
        } else {
          i++;
        }
      }
    } else {
      if (fabs(pLower - 0.5) <= 0.425) {
        b_f = 0.180625 - (pLower - 0.5) * (pLower - 0.5);
        rval = (pLower - 0.5) *
               (((((((2509.0809287301227 * b_f + 33430.57558358813) * b_f +
                     67265.7709270087) *
                        b_f +
                    45921.95393154987) *
                       b_f +
                   13731.69376550946) *
                      b_f +
                  1971.5909503065513) *
                     b_f +
                 133.14166789178438) *
                    b_f +
                3.3871328727963665) /
               (((((((5226.495278852854 * b_f + 28729.085735721943) * b_f +
                     39307.89580009271) *
                        b_f +
                    21213.794301586597) *
                       b_f +
                   5394.196021424751) *
                      b_f +
                  687.1870074920579) *
                     b_f +
                 42.31333070160091) *
                    b_f +
                1.0);
      } else {
        if (pLower - 0.5 < 0.0) {
          b_f = sqrt(-b_f);
        } else {
          b_f = sqrt(-log(1.0 - pLower));
        }
        if (b_f <= 5.0) {
          b_f -= 1.6;
          rval =
              (((((((0.0007745450142783414 * b_f + 0.022723844989269184) * b_f +
                    0.2417807251774506) *
                       b_f +
                   1.2704582524523684) *
                      b_f +
                  3.6478483247632045) *
                     b_f +
                 5.769497221460691) *
                    b_f +
                4.630337846156546) *
                   b_f +
               1.4234371107496835) /
              (((((((1.0507500716444169E-9 * b_f + 0.0005475938084995345) *
                        b_f +
                    0.015198666563616457) *
                       b_f +
                   0.14810397642748008) *
                      b_f +
                  0.6897673349851) *
                     b_f +
                 1.6763848301838038) *
                    b_f +
                2.053191626637759) *
                   b_f +
               1.0);
        } else {
          b_f -= 5.0;
          rval = (((((((2.0103343992922881E-7 * b_f + 2.7115555687434876E-5) *
                           b_f +
                       0.0012426609473880784) *
                          b_f +
                      0.026532189526576124) *
                         b_f +
                     0.29656057182850487) *
                        b_f +
                    1.7848265399172913) *
                       b_f +
                   5.463784911164114) *
                      b_f +
                  6.657904643501103) /
                 (((((((2.0442631033899397E-15 * b_f + 1.421511758316446E-7) *
                           b_f +
                       1.8463183175100548E-5) *
                          b_f +
                      0.0007868691311456133) *
                         b_f +
                     0.014875361290850615) *
                        b_f +
                    0.1369298809227358) *
                       b_f +
                   0.599832206555888) *
                      b_f +
                  1.0);
        }
        if (pLower - 0.5 < 0.0) {
          rval = -rval;
        }
      }
      ftol1 = 0.222222 / nu;
      pLower = (rval * sqrt(ftol1) + 1.0) - ftol1;
      pLower *= nu * pLower * pLower;
      if (pLower > 2.2 * nu + 6.0) {
        pLower = -2.0 * ((log1mpLower - (a - 1.0) * log(0.5 * pLower)) + lga);
      }
    }
    rval = 0.5 * pLower;
    pLower = rtInf;
    oldz = rtInf;
    ftol1 = 2.220446049250313E-14 * p;
    if (upper) {
      sgn = -1;
    } else {
      sgn = 1;
    }
    nu = 0.0;
    log1mpLower = 1.7976931348623157E+308;
    i = 0;
    exitg1 = false;
    while (!exitg1 && (i < 1000)) {
      b_f = (double)sgn * (eml_gammainc(rval, a, la, lgap1, upper) - p);
      if ((b_f * pLower < 0.0) && (fabs(pLower) <= fabs(b_f))) {
        rval = 0.5 * rval + 0.5 * oldz;
        b_f = (double)sgn * (eml_gammainc(rval, a, la, lgap1, upper) - p);
      }
      if (b_f > 0.0) {
        log1mpLower = rval;
      } else {
        nu = rval;
      }
      if ((fabs(b_f) < ftol1) ||
          (fabs(rval - oldz) <
           2.220446049250313E-16 * rval + 2.2250738585072014E-308)) {
        exitg1 = true;
      } else {
        boolean_T guard1;
        oldz = rval;
        pLower = b_f;
        guard1 = false;
        if (i < 500) {
          rval *=
              1.0 - b_f / (rval * exp(((a - 1.0) * log(rval) - rval) - lga) +
                           b_f * ((rval + 1.0) - a) / 2.0);
          if (rval <= nu) {
            if (nu == 0.0) {
              if (fabs((double)upper - p) <
                  fabs(eml_gammainc(2.2250738585072014E-308, a, la, lgap1,
                                    upper) -
                       p)) {
                rval = 0.0;
                exitg1 = true;
              } else {
                nu = 2.2250738585072014E-308;
                guard1 = true;
              }
            } else {
              guard1 = true;
            }
          } else {
            if (rval >= log1mpLower) {
              rval = 0.01 * nu + 0.99 * log1mpLower;
            }
            i++;
          }
        } else {
          b_f = 1.0E+8 * nu;
          if (b_f < log1mpLower) {
            oldz = b_f;
            pLower = (double)sgn * (eml_gammainc(b_f, a, la, lgap1, upper) - p);
            if (pLower > 0.0) {
              log1mpLower = b_f;
            } else {
              nu = b_f;
            }
          }
          rval = 0.5 * nu + 0.5 * log1mpLower;
          i++;
        }
        if (guard1) {
          rval = 0.99 * nu + 0.01 * log1mpLower;
          i++;
        }
      }
    }
  }
  return rval;
}

/* End of code generation (gammaincinv.c) */
