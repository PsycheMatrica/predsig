/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * xnrm2.c
 *
 * Code generation for function 'xnrm2'
 *
 */

/* Include files */
#include "xnrm2.h"
#include "main_core_types.h"
#include "rt_nonfinite.h"
#include "rt_nonfinite.h"
#include <math.h>

/* Function Definitions */
double b_xnrm2(int32_t n, const emxArray_real_T *x, int32_t ix0)
{
  const double *x_data;
  double y;
  int32_t k;
  x_data = x->data;
  y = 0.0;
  if (n >= 1) {
    if (n == 1) {
      y = fabs(x_data[ix0 - 1]);
    } else {
      double scale;
      int32_t kend;
      scale = 3.312168642111238E-170;
      kend = ix0 + n;
      for (k = ix0; k < kend; k++) {
        double absxk;
        absxk = fabs(x_data[k - 1]);
        if (absxk > scale) {
          double t;
          t = scale / absxk;
          y = y * t * t + 1.0;
          scale = absxk;
        } else {
          double t;
          t = absxk / scale;
          y += t * t;
        }
      }
      y = scale * sqrt(y);
      if (rtIsNaN(y)) {
        int32_t b_k;
        b_k = ix0;
        int32_t exitg1;
        do {
          exitg1 = 0;
          if (b_k <= kend - 1) {
            if (rtIsNaN(x_data[b_k - 1])) {
              exitg1 = 1;
            } else {
              b_k++;
            }
          } else {
            y = rtInf;
            exitg1 = 1;
          }
        } while (exitg1 == 0);
      }
    }
  }
  return y;
}

double xnrm2(int32_t n, const emxArray_real_T *x)
{
  const double *x_data;
  double scale;
  double y;
  int32_t k;
  boolean_T b;
  x_data = x->data;
  y = 0.0;
  scale = 3.312168642111238E-170;
  for (k = 0; k < n; k++) {
    double absxk;
    absxk = fabs(x_data[k]);
    if (absxk > scale) {
      double t;
      t = scale / absxk;
      y = y * t * t + 1.0;
      scale = absxk;
    } else {
      double t;
      t = absxk / scale;
      y += t * t;
    }
  }
  y = scale * sqrt(y);
  b = rtIsNaN(y);
  if (b) {
    int32_t b_k;
    b_k = 0;
    int32_t exitg1;
    do {
      exitg1 = 0;
      if (b_k <= n - 1) {
        if (rtIsNaN(x_data[b_k])) {
          exitg1 = 1;
        } else {
          b_k++;
        }
      } else {
        y = rtInf;
        exitg1 = 1;
      }
    } while (exitg1 == 0);
  }
  return y;
}

/* End of code generation (xnrm2.c) */
