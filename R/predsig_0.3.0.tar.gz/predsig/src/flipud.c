/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * flipud.c
 *
 * Code generation for function 'flipud'
 *
 */

/* Include files */
#include "flipud.h"
#include "rt_nonfinite.h"

/* Function Definitions */
void flipud(double x_data[], const int32_t *x_size)
{
  int32_t b_i;
  int32_t i;
  int32_t m;
  m = *x_size - 1;
  i = *x_size >> 1;
  for (b_i = 0; b_i < i; b_i++) {
    double xtmp;
    int32_t i1;
    xtmp = x_data[b_i];
    i1 = m - b_i;
    x_data[b_i] = x_data[i1];
    x_data[i1] = xtmp;
  }
}

/* End of code generation (flipud.c) */
