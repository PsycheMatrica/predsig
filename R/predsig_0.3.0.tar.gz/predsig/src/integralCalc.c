/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * integralCalc.c
 *
 * Code generation for function 'integralCalc'
 *
 */

/* Include files */
#include "integralCalc.h"
#include "main_core.h"
#include "main_core_emxutil.h"
#include "main_core_types.h"
#include "rt_nonfinite.h"
#include "rt_nonfinite.h"
#include <math.h>

/* Function Declarations */
static void times(emxArray_real_T *in1, const emxArray_real_T *in2);

/* Function Definitions */
static void times(emxArray_real_T *in1, const emxArray_real_T *in2)
{
  emxArray_real_T *b_in1;
  const double *in2_data;
  double *b_in1_data;
  double *in1_data;
  int32_t i;
  int32_t loop_ub;
  int32_t stride_0_1;
  int32_t stride_1_1;
  in2_data = in2->data;
  in1_data = in1->data;
  emxInit_real_T(&b_in1, 2);
  stride_0_1 = b_in1->size[0] * b_in1->size[1];
  b_in1->size[0] = 1;
  if (in2->size[1] == 1) {
    loop_ub = in1->size[1];
  } else {
    loop_ub = in2->size[1];
  }
  b_in1->size[1] = loop_ub;
  emxEnsureCapacity_real_T(b_in1, stride_0_1);
  b_in1_data = b_in1->data;
  stride_0_1 = (in1->size[1] != 1);
  stride_1_1 = (in2->size[1] != 1);
  for (i = 0; i < loop_ub; i++) {
    b_in1_data[i] = in1_data[i * stride_0_1] * in2_data[i * stride_1_1];
  }
  stride_0_1 = in1->size[0] * in1->size[1];
  in1->size[0] = 1;
  in1->size[1] = loop_ub;
  emxEnsureCapacity_real_T(in1, stride_0_1);
  in1_data = in1->data;
  for (i = 0; i < loop_ub; i++) {
    in1_data[i] = b_in1_data[i];
  }
  emxFree_real_T(&b_in1);
}

double scalarValuedIntegral(double fun_workspace_observed,
                            double fun_workspace_df, double A, double B,
                            const emxArray_real_T *interval, int32_t nt,
                            double pathlen, int8_t problemType,
                            int32_t MaxIntervalCount, double opstruct_absTol,
                            double opstruct_relTol,
                            const double opstruct_rule_Nodes[15],
                            const double opstruct_rule_LowWeights[15],
                            const double opstruct_rule_HighWeights[15],
                            double *errbnd, boolean_T *success)
{
  emxArray_real_T *errsubs;
  emxArray_real_T *fx;
  emxArray_real_T *qsubs;
  emxArray_real_T *subs;
  emxArray_real_T *t;
  emxArray_real_T *w;
  emxArray_real_T *x;
  double EWT[15];
  const double *interval_data;
  double err_ok;
  double previousErrbnd;
  double q;
  double q_ok;
  double relTol;
  double *errsubs_data;
  double *qsubs_data;
  double *subs_data;
  double *t_data;
  double *w_data;
  double *x_data;
  int32_t j;
  int32_t k;
  int32_t nSubsDivisionsBeforeAcceptance;
  int32_t nrefine;
  int32_t nsubs;
  boolean_T firstIteration;
  boolean_T noAcceptedSubIntervals;
  boolean_T overrideMaxIntervalCount;
  interval_data = interval->data;
  *success = true;
  for (k = 0; k < 15; k++) {
    EWT[k] = opstruct_rule_HighWeights[k] - opstruct_rule_LowWeights[k];
  }
  relTol = opstruct_relTol;
  if ((!(opstruct_absTol > 0.0) || !(opstruct_relTol == 0.0)) &&
      (opstruct_relTol < 2.220446049250313E-14)) {
    relTol = 2.220446049250313E-14;
  }
  overrideMaxIntervalCount = true;
  noAcceptedSubIntervals = true;
  nSubsDivisionsBeforeAcceptance = -1;
  nsubs = nt - 1;
  previousErrbnd = -1.0;
  emxInit_real_T(&subs, 2);
  nrefine = subs->size[0] * subs->size[1];
  subs->size[0] = 2;
  subs->size[1] = nt - 1;
  emxEnsureCapacity_real_T(subs, nrefine);
  subs_data = subs->data;
  emxInit_real_T(&qsubs, 2);
  nrefine = qsubs->size[0] * qsubs->size[1];
  qsubs->size[0] = 1;
  qsubs->size[1] = nt - 1;
  emxEnsureCapacity_real_T(qsubs, nrefine);
  qsubs_data = qsubs->data;
  emxInit_real_T(&errsubs, 2);
  nrefine = errsubs->size[0] * errsubs->size[1];
  errsubs->size[0] = 1;
  errsubs->size[1] = nt - 1;
  emxEnsureCapacity_real_T(errsubs, nrefine);
  errsubs_data = errsubs->data;
  for (k = 0; k < nsubs; k++) {
    subs_data[2 * k] = interval_data[k];
    subs_data[2 * k + 1] = interval_data[k + 1];
  }
  q = 0.0;
  *errbnd = 0.0;
  q_ok = 0.0;
  err_ok = 0.0;
  firstIteration = true;
  emxInit_real_T(&x, 2);
  emxInit_real_T(&fx, 2);
  emxInit_real_T(&t, 2);
  emxInit_real_T(&w, 2);
  int32_t exitg1;
  do {
    double absti;
    double bpa50;
    double errsubs1norm;
    double halfh;
    double midpt;
    int32_t b_nsubs;
    int32_t i;
    int32_t loop_ub;
    boolean_T guard1;
    boolean_T guard2;
    exitg1 = 0;
    nrefine = x->size[0] * x->size[1];
    x->size[0] = 1;
    x->size[1] = nsubs * 15;
    emxEnsureCapacity_real_T(x, nrefine);
    x_data = x->data;
    for (k = 0; k < nsubs; k++) {
      bpa50 = subs_data[2 * k];
      absti = subs_data[2 * k + 1];
      midpt = (bpa50 + absti) / 2.0;
      halfh = (absti - bpa50) / 2.0;
      for (j = 0; j < 15; j++) {
        x_data[k * 15 + j] = opstruct_rule_Nodes[j] * halfh + midpt;
      }
    }
    nrefine = t->size[0] * t->size[1];
    t->size[0] = 1;
    loop_ub = x->size[1];
    t->size[1] = x->size[1];
    emxEnsureCapacity_real_T(t, nrefine);
    t_data = t->data;
    nrefine = w->size[0] * w->size[1];
    w->size[0] = 1;
    w->size[1] = x->size[1];
    emxEnsureCapacity_real_T(w, nrefine);
    w_data = w->data;
    if (problemType == 1) {
      double bma75;
      bpa50 = B - A;
      bma75 = 0.75 * bpa50;
      halfh = 0.25 * bpa50;
      bpa50 = 0.5 * (B + A);
      for (k = 0; k < loop_ub; k++) {
        errsubs1norm = x_data[k];
        absti = fabs(errsubs1norm);
        if (absti > 0.25) {
          midpt =
              halfh * ((absti - 1.0) * (absti - 1.0)) * ((absti - 1.0) + 3.0);
          if (errsubs1norm < 0.0) {
            t_data[k] = A + midpt;
          } else {
            t_data[k] = B - midpt;
          }
          w_data[k] = -bma75 * (absti - 1.0) * ((absti - 1.0) + 2.0);
        } else {
          midpt = errsubs1norm * errsubs1norm;
          t_data[k] = halfh * errsubs1norm * (3.0 - midpt) + bpa50;
          w_data[k] = bma75 * (1.0 - midpt);
        }
      }
    } else if (problemType == 2) {
      for (k = 0; k < loop_ub; k++) {
        bpa50 = x_data[k];
        absti = bpa50 / (1.0 - bpa50);
        t_data[k] = A + absti * absti;
        w_data[k] = 2.0 * absti / ((1.0 - bpa50) * (1.0 - bpa50));
      }
    } else if (problemType == 3) {
      for (k = 0; k < loop_ub; k++) {
        bpa50 = x_data[k];
        absti = bpa50 / (bpa50 + 1.0);
        t_data[k] = B - absti * absti;
        w_data[k] = -2.0 * absti / ((bpa50 + 1.0) * (bpa50 + 1.0));
      }
    } else {
      for (k = 0; k < loop_ub; k++) {
        bpa50 = x_data[k];
        midpt = bpa50 * bpa50;
        t_data[k] = bpa50 / (1.0 - midpt);
        w_data[k] = (midpt + 1.0) / ((1.0 - midpt) * (1.0 - midpt));
      }
    }
    guard1 = false;
    guard2 = false;
    if (firstIteration) {
      main_core_anonFcn1(fun_workspace_observed, fun_workspace_df, t, fx);
      firstIteration = false;
      if (fx->size[1] == w->size[1]) {
        loop_ub = fx->size[1];
        nrefine = fx->size[0] * fx->size[1];
        fx->size[0] = 1;
        emxEnsureCapacity_real_T(fx, nrefine);
        x_data = fx->data;
        for (k = 0; k < loop_ub; k++) {
          x_data[k] *= w_data[k];
        }
      } else {
        times(fx, w);
        x_data = fx->data;
      }
      guard2 = true;
    } else {
      boolean_T exitg2;
      boolean_T tooClose;
      bpa50 = fabs(t_data[0]);
      tooClose = false;
      nrefine = 1;
      exitg2 = false;
      while (!exitg2 && (nrefine + 1 <= t->size[1])) {
        absti = bpa50;
        bpa50 = fabs(t_data[nrefine]);
        if (fabs(t_data[nrefine] - t_data[nrefine - 1]) <=
            2.220446049250313E-14 * fmax(absti, bpa50)) {
          tooClose = true;
          exitg2 = true;
        } else {
          nrefine++;
        }
      }
      if (tooClose) {
        *success = false;
        exitg1 = 1;
      } else {
        main_core_anonFcn1(fun_workspace_observed, fun_workspace_df, t, fx);
        if (fx->size[1] == w->size[1]) {
          loop_ub = fx->size[1];
          nrefine = fx->size[0] * fx->size[1];
          fx->size[0] = 1;
          emxEnsureCapacity_real_T(fx, nrefine);
          x_data = fx->data;
          for (k = 0; k < loop_ub; k++) {
            x_data[k] *= w_data[k];
          }
        } else {
          times(fx, w);
          x_data = fx->data;
        }
        guard2 = true;
      }
    }
    if (guard2) {
      q = 0.0;
      if (nsubs > qsubs->size[1]) {
        nrefine = qsubs->size[0] * qsubs->size[1];
        qsubs->size[0] = 1;
        qsubs->size[1] = nsubs;
        emxEnsureCapacity_real_T(qsubs, nrefine);
        qsubs_data = qsubs->data;
        nrefine = errsubs->size[0] * errsubs->size[1];
        errsubs->size[0] = 1;
        errsubs->size[1] = nsubs;
        emxEnsureCapacity_real_T(errsubs, nrefine);
        errsubs_data = errsubs->data;
      }
      for (k = 0; k < nsubs; k++) {
        absti = 0.0;
        midpt = 0.0;
        for (j = 0; j < 15; j++) {
          bpa50 = x_data[k * 15 + j];
          absti += opstruct_rule_HighWeights[j] * bpa50;
          midpt += EWT[j] * bpa50;
        }
        halfh = (subs_data[2 * k + 1] - subs_data[2 * k]) / 2.0;
        bpa50 = absti * halfh;
        qsubs_data[k] = bpa50;
        errsubs_data[k] = midpt * halfh;
        q += bpa50;
      }
      q += q_ok;
      halfh = fmax(opstruct_absTol, fabs(q) * relTol);
      bpa50 = 2.0 * halfh / pathlen;
      errsubs1norm = 0.0;
      nrefine = 0;
      *errbnd = fabs(err_ok);
      for (k = 0; k < nsubs; k++) {
        absti = errsubs_data[k];
        midpt = fabs(absti);
        loop_ub = 2 * k + 1;
        if (midpt < bpa50 * ((subs_data[loop_ub] - subs_data[2 * k]) / 2.0)) {
          err_ok += absti;
          q_ok += qsubs_data[k];
        } else {
          errsubs1norm += midpt;
          nrefine++;
          i = 2 * (nrefine - 1);
          subs_data[i] = subs_data[2 * k];
          subs_data[i + 1] = subs_data[loop_ub];
        }
        *errbnd += midpt;
      }
      if (noAcceptedSubIntervals && (nsubs == nrefine)) {
        noAcceptedSubIntervals = true;
      } else {
        noAcceptedSubIntervals = false;
      }
      nsubs = nrefine;
      if (noAcceptedSubIntervals) {
        if (!rtIsInf(q) && !rtIsNaN(q) &&
            (!rtIsInf(*errbnd) && !rtIsNaN(*errbnd))) {
          nSubsDivisionsBeforeAcceptance++;
          guard1 = true;
        } else {
          *success = false;
          exitg1 = 1;
        }
      } else {
        bpa50 = fabs(err_ok);
        if (bpa50 <= halfh) {
          *errbnd = bpa50 + errsubs1norm;
          if (!rtIsInf(q) && !rtIsNaN(q) &&
              (!rtIsInf(*errbnd) && !rtIsNaN(*errbnd))) {
            if ((*errbnd < halfh) || (nrefine == 0)) {
              exitg1 = 1;
            } else {
              guard1 = true;
            }
          } else {
            *success = false;
            exitg1 = 1;
          }
        } else {
          nsubs = nt - 1;
          for (k = 0; k < nsubs; k++) {
            subs_data[2 * k] = interval_data[k];
            subs_data[2 * k + 1] = interval_data[k + 1];
          }
          for (j = 0; j <= nSubsDivisionsBeforeAcceptance; j++) {
            b_nsubs = nsubs << 1;
            if (b_nsubs > subs->size[1]) {
              nrefine = b_nsubs - subs->size[1];
              i = subs->size[1];
              loop_ub = subs->size[0] * subs->size[1];
              subs->size[0] = 2;
              subs->size[1] += nrefine;
              emxEnsureCapacity_real_T(subs, loop_ub);
              subs_data = subs->data;
              for (k = 0; k < nrefine; k++) {
                loop_ub = k + i;
                subs_data[2 * loop_ub] = 0.0;
                subs_data[2 * loop_ub + 1] = 0.0;
              }
            }
            for (k = nsubs; k >= 1; k--) {
              loop_ub = (k << 1) - 1;
              nrefine = 2 * (k - 1);
              subs_data[2 * loop_ub + 1] = subs_data[nrefine + 1];
              subs_data[2 * loop_ub] =
                  (subs_data[nrefine] + subs_data[nrefine + 1]) / 2.0;
              i = 2 * (loop_ub - 1);
              subs_data[i + 1] = subs_data[2 * loop_ub];
              subs_data[i] = subs_data[nrefine];
            }
            nsubs = b_nsubs;
          }
          noAcceptedSubIntervals = true;
          nSubsDivisionsBeforeAcceptance++;
          q_ok = 0.0;
          err_ok = 0.0;
          guard1 = true;
        }
      }
    }
    if (guard1) {
      b_nsubs = nsubs << 1;
      if (overrideMaxIntervalCount || (b_nsubs <= MaxIntervalCount) ||
          (*errbnd <= previousErrbnd / 2.0)) {
        overrideMaxIntervalCount = true;
        if (b_nsubs > subs->size[1]) {
          nrefine = b_nsubs - subs->size[1];
          i = subs->size[1];
          loop_ub = subs->size[0] * subs->size[1];
          subs->size[0] = 2;
          subs->size[1] += nrefine;
          emxEnsureCapacity_real_T(subs, loop_ub);
          subs_data = subs->data;
          for (k = 0; k < nrefine; k++) {
            loop_ub = k + i;
            subs_data[2 * loop_ub] = 0.0;
            subs_data[2 * loop_ub + 1] = 0.0;
          }
        }
        for (k = nsubs; k >= 1; k--) {
          loop_ub = (k << 1) - 1;
          nrefine = 2 * (k - 1);
          subs_data[2 * loop_ub + 1] = subs_data[nrefine + 1];
          subs_data[2 * loop_ub] =
              (subs_data[nrefine] + subs_data[nrefine + 1]) / 2.0;
          i = 2 * (loop_ub - 1);
          subs_data[i + 1] = subs_data[2 * loop_ub];
          subs_data[i] = subs_data[nrefine];
        }
      } else {
        overrideMaxIntervalCount = false;
      }
      nsubs = b_nsubs;
      *success = overrideMaxIntervalCount;
      if (!overrideMaxIntervalCount) {
        exitg1 = 1;
      } else {
        previousErrbnd = *errbnd;
        overrideMaxIntervalCount = false;
      }
    }
  } while (exitg1 == 0);
  emxFree_real_T(&w);
  emxFree_real_T(&t);
  emxFree_real_T(&fx);
  emxFree_real_T(&x);
  emxFree_real_T(&errsubs);
  emxFree_real_T(&qsubs);
  emxFree_real_T(&subs);
  return q;
}

/* End of code generation (integralCalc.c) */
