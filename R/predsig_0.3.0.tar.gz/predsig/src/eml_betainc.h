/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * eml_betainc.h
 *
 * Code generation for function 'eml_betainc'
 *
 */

#ifndef EML_BETAINC_H
#define EML_BETAINC_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
double betainc_cf(double x, double a, double b);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (eml_betainc.h) */
