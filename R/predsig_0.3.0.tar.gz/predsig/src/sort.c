/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * sort.c
 *
 * Code generation for function 'sort'
 *
 */

/* Include files */
#include "sort.h"
#include "main_core_emxutil.h"
#include "main_core_types.h"
#include "rt_nonfinite.h"
#include "sortIdx.h"

/* Function Definitions */
void b_sort(emxArray_real_T *x, emxArray_int32_T *idx)
{
  emxArray_real_T *vwork;
  double *vwork_data;
  double *x_data;
  int32_t dim;
  int32_t i;
  int32_t i1;
  int32_t j;
  int32_t k;
  int32_t vstride;
  int32_t *idx_data;
  int32_t *iidx_data;
  x_data = x->data;
  dim = 2;
  if (x->size[0] != 1) {
    dim = 1;
  }
  if (dim <= 1) {
    i = x->size[0];
  } else {
    i = 1;
  }
  emxInit_real_T(&vwork, 1);
  i1 = vwork->size[0];
  vwork->size[0] = i;
  emxEnsureCapacity_real_T(vwork, i1);
  vwork_data = vwork->data;
  i1 = idx->size[0];
  idx->size[0] = x->size[0];
  emxEnsureCapacity_int32_T(idx, i1);
  idx_data = idx->data;
  vstride = 1;
  i1 = dim - 2;
  for (k = 0; k <= i1; k++) {
    vstride *= x->size[0];
  }
  emxInit_int32_T(&idx, 1);
  for (j = 0; j < vstride; j++) {
    for (k = 0; k < i; k++) {
      vwork_data[k] = x_data[j + k * vstride];
    }
    sortIdx(vwork, idx);
    iidx_data = idx->data;
    vwork_data = vwork->data;
    for (k = 0; k < i; k++) {
      i1 = j + k * vstride;
      x_data[i1] = vwork_data[k];
      idx_data[i1] = iidx_data[k];
    }
  }
  emxFree_int32_T(&idx);
  emxFree_real_T(&vwork);
}

void sort(emxArray_real_T *x)
{
  emxArray_int32_T *b_vwork;
  emxArray_real_T *vwork;
  double *vwork_data;
  double *x_data;
  int32_t dim;
  int32_t i;
  int32_t i1;
  int32_t j;
  int32_t k;
  int32_t vstride;
  x_data = x->data;
  dim = 2;
  if (x->size[0] != 1) {
    dim = 1;
  }
  if (dim <= 1) {
    i = x->size[0];
  } else {
    i = 1;
  }
  emxInit_real_T(&vwork, 1);
  i1 = vwork->size[0];
  vwork->size[0] = i;
  emxEnsureCapacity_real_T(vwork, i1);
  vwork_data = vwork->data;
  vstride = 1;
  i1 = dim - 2;
  for (k = 0; k <= i1; k++) {
    vstride *= x->size[0];
  }
  emxInit_int32_T(&b_vwork, 1);
  for (j = 0; j < vstride; j++) {
    for (k = 0; k < i; k++) {
      vwork_data[k] = x_data[j + k * vstride];
    }
    sortIdx(vwork, b_vwork);
    vwork_data = vwork->data;
    for (k = 0; k < i; k++) {
      x_data[j + k * vstride] = vwork_data[k];
    }
  }
  emxFree_int32_T(&b_vwork);
  emxFree_real_T(&vwork);
}

/* End of code generation (sort.c) */
