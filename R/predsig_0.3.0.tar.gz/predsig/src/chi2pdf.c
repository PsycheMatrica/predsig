/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * chi2pdf.c
 *
 * Code generation for function 'chi2pdf'
 *
 */

/* Include files */
#include "chi2pdf.h"
#include "gampdf.h"
#include "main_core_emxutil.h"
#include "main_core_types.h"
#include "rt_nonfinite.h"
#include "rt_nonfinite.h"
#include <math.h>

/* Function Definitions */
void chi2pdf(const emxArray_real_T *x, double v, emxArray_real_T *y)
{
  const double *x_data;
  double a;
  double *y_data;
  int32_t i;
  int32_t i1;
  int32_t k;
  x_data = x->data;
  a = v / 2.0;
  i = y->size[0] * y->size[1];
  y->size[0] = 1;
  i1 = x->size[1];
  y->size[1] = x->size[1];
  emxEnsureCapacity_real_T(y, i);
  y_data = y->data;
  for (k = 0; k < i1; k++) {
    if ((a >= 0.0) && !rtIsNaN(x_data[k])) {
      double zk;
      zk = x_data[k] / 2.0;
      if (zk == 0.0) {
        if (a < 1.0) {
          y_data[k] = rtInf;
        } else if (a > 1.0) {
          y_data[k] = 0.0;
        } else {
          y_data[k] = 0.5;
        }
      } else if ((zk < 0.0) || rtIsInf(zk) || rtIsInf(a)) {
        y_data[k] = 0.0;
      } else if (a < 1.0) {
        y_data[k] = f(zk, a) * exp(log(a) - log(zk)) / 2.0;
      } else {
        y_data[k] = f(zk, a - 1.0) / 2.0;
      }
    } else {
      y_data[k] = rtNaN;
    }
  }
}

/* End of code generation (chi2pdf.c) */
