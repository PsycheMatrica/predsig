/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * nctcdf.h
 *
 * Code generation for function 'nctcdf'
 *
 */

#ifndef NCTCDF_H
#define NCTCDF_H

/* Include files */
#include "main_core_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void b_nctcdf(double x, double nu, const emxArray_real_T *delta,
              emxArray_real_T *p);

double nctcdf(double x, double nu, double delta);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (nctcdf.h) */
