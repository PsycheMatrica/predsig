/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * asinh.c
 *
 * Code generation for function 'asinh'
 *
 */

/* Include files */
#include "asinh.h"
#include "rt_nonfinite.h"
#include "rt_nonfinite.h"
#include <math.h>

/* Function Definitions */
void b_asinh(double *x)
{
  boolean_T xneg;
  xneg = (*x < 0.0);
  if (xneg) {
    *x = -*x;
  }
  if (*x >= 2.68435456E+8) {
    *x = log(*x) + 0.6931471805599453;
  } else if (*x > 2.0) {
    *x = log(2.0 * *x + 1.0 / (sqrt(*x * *x + 1.0) + *x));
  } else {
    double t;
    t = *x * *x;
    *x += t / (sqrt(t + 1.0) + 1.0);
    t = fabs(*x);
    if ((t > 4.503599627370496E+15) || (rtIsInf(*x) || rtIsNaN(*x))) {
      (*x)++;
      *x = log(*x);
    } else if (!(t < 2.220446049250313E-16)) {
      *x = log(*x + 1.0) * (*x / ((*x + 1.0) - 1.0));
    }
  }
  if (xneg) {
    *x = -*x;
  }
}

/* End of code generation (asinh.c) */
