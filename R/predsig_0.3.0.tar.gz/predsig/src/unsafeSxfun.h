/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * unsafeSxfun.h
 *
 * Code generation for function 'unsafeSxfun'
 *
 */

#ifndef UNSAFESXFUN_H
#define UNSAFESXFUN_H

/* Include files */
#include "main_core_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void binary_expand_op_1(emxArray_real_T *in1, const emxArray_real_T *in3,
                        const double in4_data[], const int32_t *in4_size,
                        double in5);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (unsafeSxfun.h) */
