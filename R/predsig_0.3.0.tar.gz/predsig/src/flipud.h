/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * flipud.h
 *
 * Code generation for function 'flipud'
 *
 */

#ifndef FLIPUD_H
#define FLIPUD_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void flipud(double x_data[], const int32_t *x_size);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (flipud.h) */
