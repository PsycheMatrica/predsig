/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * main_core_data.h
 *
 * Code generation for function 'main_core_data'
 *
 */

#ifndef MAIN_CORE_DATA_H
#define MAIN_CORE_DATA_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>

/* Variable Declarations */
extern const double dv[31];

#endif
/* End of code generation (main_core_data.h) */
