/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * xgerc.c
 *
 * Code generation for function 'xgerc'
 *
 */

/* Include files */
#include "xgerc.h"
#include "main_core_types.h"
#include "rt_nonfinite.h"

/* Function Definitions */
void xgerc(int32_t m, int32_t n, double alpha1, int32_t ix0,
           const emxArray_real_T *y, emxArray_real_T *A, int32_t ia0,
           int32_t lda)
{
  const double *y_data;
  double *A_data;
  int32_t ijA;
  int32_t j;
  A_data = A->data;
  y_data = y->data;
  if (!(alpha1 == 0.0)) {
    int32_t jA;
    jA = ia0;
    for (j = 0; j < n; j++) {
      if (y_data[j] != 0.0) {
        double temp;
        int32_t i;
        temp = y_data[j] * alpha1;
        i = m + jA;
        for (ijA = jA; ijA < i; ijA++) {
          A_data[ijA - 1] += A_data[((ix0 + ijA) - jA) - 1] * temp;
        }
      }
      jA += lda;
    }
  }
}

/* End of code generation (xgerc.c) */
