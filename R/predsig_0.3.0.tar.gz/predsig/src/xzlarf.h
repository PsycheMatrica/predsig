/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * xzlarf.h
 *
 * Code generation for function 'xzlarf'
 *
 */

#ifndef XZLARF_H
#define XZLARF_H

/* Include files */
#include "main_core_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void xzlarf(int32_t m, int32_t n, int32_t iv0, double tau, emxArray_real_T *C,
            int32_t ic0, int32_t ldc, emxArray_real_T *work);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (xzlarf.h) */
