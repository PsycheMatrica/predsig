/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * integralCalc.h
 *
 * Code generation for function 'integralCalc'
 *
 */

#ifndef INTEGRALCALC_H
#define INTEGRALCALC_H

/* Include files */
#include "main_core_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
double scalarValuedIntegral(double fun_workspace_observed,
                            double fun_workspace_df, double A, double B,
                            const emxArray_real_T *interval, int32_t nt,
                            double pathlen, int8_t problemType,
                            int32_t MaxIntervalCount, double opstruct_absTol,
                            double opstruct_relTol,
                            const double opstruct_rule_Nodes[15],
                            const double opstruct_rule_LowWeights[15],
                            const double opstruct_rule_HighWeights[15],
                            double *errbnd, boolean_T *success);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (integralCalc.h) */
