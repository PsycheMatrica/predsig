/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * qrsolve.c
 *
 * Code generation for function 'qrsolve'
 *
 */

/* Include files */
#include "qrsolve.h"
#include "main_core_emxutil.h"
#include "main_core_types.h"
#include "rt_nonfinite.h"
#include "xnrm2.h"
#include "xzlarf.h"
#include "xzlarfg.h"
#include <math.h>

/* Function Definitions */
void qrsolve(const emxArray_real_T *A, const emxArray_real_T *B,
             emxArray_real_T *Y)
{
  emxArray_int32_T *jpvt;
  emxArray_real_T *b_A;
  emxArray_real_T *b_B;
  emxArray_real_T *tau;
  emxArray_real_T *vn1;
  emxArray_real_T *vn2;
  emxArray_real_T *work;
  const double *A_data;
  const double *B_data;
  double tol;
  double *Y_data;
  double *b_A_data;
  double *tau_data;
  double *vn2_data;
  double *work_data;
  int32_t b_j;
  int32_t i;
  int32_t j;
  int32_t k;
  int32_t loop_ub;
  int32_t m;
  int32_t maxmn;
  int32_t minmana;
  int32_t minmn;
  int32_t rankA;
  int32_t *jpvt_data;
  B_data = B->data;
  A_data = A->data;
  emxInit_real_T(&b_A, 2);
  m = A->size[0];
  minmn = b_A->size[0] * b_A->size[1];
  b_A->size[0] = A->size[0];
  loop_ub = A->size[1];
  b_A->size[1] = A->size[1];
  emxEnsureCapacity_real_T(b_A, minmn);
  b_A_data = b_A->data;
  minmn = A->size[0] * A->size[1];
  for (j = 0; j < minmn; j++) {
    b_A_data[j] = A_data[j];
  }
  minmn = A->size[0];
  minmana = A->size[1];
  if (minmn <= minmana) {
    minmana = minmn;
  }
  emxInit_real_T(&tau, 1);
  minmn = tau->size[0];
  tau->size[0] = minmana;
  emxEnsureCapacity_real_T(tau, minmn);
  tau_data = tau->data;
  for (j = 0; j < minmana; j++) {
    tau_data[j] = 0.0;
  }
  emxInit_int32_T(&jpvt, 2);
  if (minmana < 1) {
    minmn = jpvt->size[0] * jpvt->size[1];
    jpvt->size[0] = 1;
    jpvt->size[1] = A->size[1];
    emxEnsureCapacity_int32_T(jpvt, minmn);
    jpvt_data = jpvt->data;
    for (j = 0; j < loop_ub; j++) {
      jpvt_data[j] = j + 1;
    }
  } else {
    minmn = jpvt->size[0] * jpvt->size[1];
    jpvt->size[0] = 1;
    jpvt->size[1] = A->size[1];
    emxEnsureCapacity_int32_T(jpvt, minmn);
    jpvt_data = jpvt->data;
    emxInit_real_T(&work, 1);
    minmn = work->size[0];
    work->size[0] = A->size[1];
    emxEnsureCapacity_real_T(work, minmn);
    work_data = work->data;
    emxInit_real_T(&vn1, 1);
    minmn = vn1->size[0];
    vn1->size[0] = A->size[1];
    emxEnsureCapacity_real_T(vn1, minmn);
    Y_data = vn1->data;
    emxInit_real_T(&vn2, 1);
    minmn = vn2->size[0];
    vn2->size[0] = A->size[1];
    emxEnsureCapacity_real_T(vn2, minmn);
    vn2_data = vn2->data;
    for (j = 0; j < loop_ub; j++) {
      jpvt_data[j] = j + 1;
      work_data[j] = 0.0;
      tol = b_xnrm2(m, A, j * m + 1);
      Y_data[j] = tol;
      vn2_data[j] = tol;
    }
    for (b_j = 0; b_j < minmana; b_j++) {
      double temp1;
      int32_t ii;
      int32_t ii_tmp;
      int32_t mmi;
      int32_t nmi;
      ii_tmp = b_j * m;
      ii = ii_tmp + b_j;
      nmi = (loop_ub - b_j) - 1;
      mmi = m - b_j;
      if (nmi < 0) {
        minmn = -1;
      } else {
        minmn = 0;
        if (nmi > 0) {
          tol = Y_data[b_j];
          for (j = 2; j <= nmi + 1; j++) {
            temp1 = Y_data[(b_j + j) - 1];
            if (temp1 > tol) {
              minmn = j - 1;
              tol = temp1;
            }
          }
        }
      }
      rankA = b_j + minmn;
      if (rankA + 1 != b_j + 1) {
        minmn = rankA * m;
        for (j = 0; j < m; j++) {
          maxmn = minmn + j;
          tol = b_A_data[maxmn];
          i = ii_tmp + j;
          b_A_data[maxmn] = b_A_data[i];
          b_A_data[i] = tol;
        }
        minmn = jpvt_data[rankA];
        jpvt_data[rankA] = jpvt_data[b_j];
        jpvt_data[b_j] = minmn;
        Y_data[rankA] = Y_data[b_j];
        vn2_data[rankA] = vn2_data[b_j];
      }
      if (b_j + 1 < m) {
        tol = b_A_data[ii];
        temp1 = xzlarfg(mmi, &tol, b_A, ii + 2);
        b_A_data = b_A->data;
        tau_data[b_j] = temp1;
        b_A_data[ii] = tol;
      } else {
        temp1 = 0.0;
        tau_data[b_j] = 0.0;
      }
      if (b_j + 1 < loop_ub) {
        tol = b_A_data[ii];
        b_A_data[ii] = 1.0;
        xzlarf(mmi, nmi, ii + 1, temp1, b_A, (ii + m) + 1, m, work);
        b_A_data = b_A->data;
        b_A_data[ii] = tol;
      }
      for (j = b_j + 2; j <= loop_ub; j++) {
        minmn = b_j + (j - 1) * m;
        tol = Y_data[j - 1];
        if (tol != 0.0) {
          double temp2;
          temp1 = fabs(b_A_data[minmn]) / tol;
          temp1 = 1.0 - temp1 * temp1;
          if (temp1 < 0.0) {
            temp1 = 0.0;
          }
          temp2 = tol / vn2_data[j - 1];
          temp2 = temp1 * (temp2 * temp2);
          if (temp2 <= 1.4901161193847656E-8) {
            if (b_j + 1 < m) {
              tol = b_xnrm2(mmi - 1, b_A, minmn + 2);
              Y_data[j - 1] = tol;
              vn2_data[j - 1] = tol;
            } else {
              Y_data[j - 1] = 0.0;
              vn2_data[j - 1] = 0.0;
            }
          } else {
            Y_data[j - 1] = tol * sqrt(temp1);
          }
        }
      }
    }
    emxFree_real_T(&vn2);
    emxFree_real_T(&vn1);
    emxFree_real_T(&work);
  }
  rankA = 0;
  if (b_A->size[0] < b_A->size[1]) {
    minmn = b_A->size[0];
    maxmn = b_A->size[1];
  } else {
    minmn = b_A->size[1];
    maxmn = b_A->size[0];
  }
  if (minmn > 0) {
    tol = fmin(1.4901161193847656E-8, 2.220446049250313E-15 * (double)maxmn) *
          fabs(b_A_data[0]);
    while ((rankA < minmn) &&
           !(fabs(b_A_data[rankA + b_A->size[0] * rankA]) <= tol)) {
      rankA++;
    }
  }
  emxInit_real_T(&b_B, 2);
  minmn = b_B->size[0] * b_B->size[1];
  b_B->size[0] = B->size[0];
  i = B->size[1];
  b_B->size[1] = B->size[1];
  emxEnsureCapacity_real_T(b_B, minmn);
  work_data = b_B->data;
  minmn = B->size[0] * B->size[1];
  for (j = 0; j < minmn; j++) {
    work_data[j] = B_data[j];
  }
  minmn = Y->size[0] * Y->size[1];
  Y->size[0] = b_A->size[1];
  Y->size[1] = B->size[1];
  emxEnsureCapacity_real_T(Y, minmn);
  Y_data = Y->data;
  minmn = b_A->size[1] * B->size[1];
  for (j = 0; j < minmn; j++) {
    Y_data[j] = 0.0;
  }
  minmn = b_A->size[0];
  maxmn = b_A->size[1];
  if (minmn <= maxmn) {
    maxmn = minmn;
  }
  for (b_j = 0; b_j < maxmn; b_j++) {
    minmn = b_A->size[0];
    if (tau_data[b_j] != 0.0) {
      for (k = 0; k < i; k++) {
        tol = work_data[b_j + b_B->size[0] * k];
        for (j = b_j + 2; j <= minmn; j++) {
          tol += b_A_data[(j + b_A->size[0] * b_j) - 1] *
                 work_data[(j + b_B->size[0] * k) - 1];
        }
        tol *= tau_data[b_j];
        if (tol != 0.0) {
          work_data[b_j + b_B->size[0] * k] -= tol;
          for (j = b_j + 2; j <= minmn; j++) {
            work_data[(j + b_B->size[0] * k) - 1] -=
                b_A_data[(j + b_A->size[0] * b_j) - 1] * tol;
          }
        }
      }
    }
  }
  emxFree_real_T(&tau);
  for (k = 0; k < i; k++) {
    for (j = 0; j < rankA; j++) {
      Y_data[(jpvt_data[j] + Y->size[0] * k) - 1] =
          work_data[j + b_B->size[0] * k];
    }
    for (j = rankA; j >= 1; j--) {
      minmn = jpvt_data[j - 1];
      Y_data[(minmn + Y->size[0] * k) - 1] /=
          b_A_data[(j + b_A->size[0] * (j - 1)) - 1];
      for (b_j = 0; b_j <= j - 2; b_j++) {
        Y_data[(jpvt_data[b_j] + Y->size[0] * k) - 1] -=
            Y_data[(minmn + Y->size[0] * k) - 1] *
            b_A_data[b_j + b_A->size[0] * (j - 1)];
      }
    }
  }
  emxFree_real_T(&b_B);
  emxFree_int32_T(&jpvt);
  emxFree_real_T(&b_A);
}

/* End of code generation (qrsolve.c) */
