/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * integral.h
 *
 * Code generation for function 'integral'
 *
 */

#ifndef INTEGRAL_H
#define INTEGRAL_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
double integral(double fun_workspace_observed, double fun_workspace_df,
                double a, double b, double nv_AbsTol, double nv_RelTol);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (integral.h) */
