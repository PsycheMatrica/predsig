/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * main_core_data.c
 *
 * Code generation for function 'main_core_data'
 *
 */

/* Include files */
#include "main_core_data.h"
#include "rt_nonfinite.h"

/* Variable Definitions */
const double dv[31] = {0.0,
                       0.15342640972002736,
                       0.08106146679532726,
                       0.05481412105191765,
                       0.0413406959554093,
                       0.03316287351993629,
                       0.02767792568499834,
                       0.023746163656297496,
                       0.020790672103765093,
                       0.018488450532673187,
                       0.016644691189821193,
                       0.015134973221917378,
                       0.013876128823070748,
                       0.012810465242920227,
                       0.01189670994589177,
                       0.011104559758206917,
                       0.010411265261972096,
                       0.009799416126158804,
                       0.009255462182712733,
                       0.008768700134139386,
                       0.00833056343336287,
                       0.00793411456431402,
                       0.007573675487951841,
                       0.007244554301320383,
                       0.00694284010720953,
                       0.006665247032707682,
                       0.006408994188004207,
                       0.006171712263039458,
                       0.0059513701127588475,
                       0.0057462165130101155,
                       0.005554733551962801};

/* End of code generation (main_core_data.c) */
