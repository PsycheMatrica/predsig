/* Copyright (C) 2026 Gyeongcheol Cho. CC BY-NC-SA 4.0.
 * Handwritten R interface; generated computational files retain their notices.
 * Statistical calculations are implemented by the generated engines.
 */
#include <R.h>
#include <Rinternals.h>
#include <R_ext/Memory.h>
#include <R_ext/Utils.h>
#include <math.h>
#include "main_core.h"
#include "supplementary_core.h"

static int numeric_type(SEXP value)
{
    return TYPEOF(value) == REALSXP || TYPEOF(value) == INTSXP;
}

static double finite_scalar(SEXP value, const char *name)
{
    double answer;
    if (!numeric_type(value) || XLENGTH(value) != 1)
        Rf_error("%s must be a finite numeric scalar.", name);
    answer = Rf_asReal(value);
    if (!R_FINITE(answer))
        Rf_error("%s must be a finite numeric scalar.", name);
    return answer;
}

SEXP predsig_R_core(SEXP t, SEXP sigma2, SEXP sample_size, SEXP slopes,
                   SEXP absolute_tolerance, SEXP relative_tolerance)
{
    double variance = finite_scalar(sigma2, "sigma2_hat");
    double N = finite_scalar(sample_size, "N");
    double P = finite_scalar(slopes, "P");
    double abs_tol = finite_scalar(absolute_tolerance, "abs_tol");
    double rel_tol = finite_scalar(relative_tolerance, "rel_tol");
    R_xlen_t count, index;
    SEXP dimensions, values, answer, names, delEPE, delta, p_pred, EPE1;

    if (variance <= 0)
        Rf_error("sigma2_hat must be positive.");
    if (N <= 0 || P <= 0 || N != floor(N) || P != floor(P))
        Rf_error("N and P must be positive integers.");
    if (N <= P + 2)
        Rf_error("Require N > P + 2.");
    if (abs_tol < 0 || rel_tol < 0 || (abs_tol == 0 && rel_tol == 0))
        Rf_error("Integration tolerances must be nonnegative, with at least one positive.");
    if (!numeric_type(t) || XLENGTH(t) == 0)
        Rf_error("t must be a nonempty real numeric vector without missing values.");
    dimensions = Rf_getAttrib(t, R_DimSymbol);
    if (dimensions != R_NilValue &&
        (XLENGTH(dimensions) != 2 ||
         (INTEGER(dimensions)[0] != 1 && INTEGER(dimensions)[1] != 1)))
        Rf_error("t must be a vector or a one-row/one-column matrix.");
    count = XLENGTH(t);
    values = PROTECT(Rf_coerceVector(t, REALSXP));
    for (index = 0; index < count; ++index)
        if (ISNAN(REAL(values)[index]))
            Rf_error("t must not contain missing values or NaN.");

    /* Allocate protected R results before entering generated code. Coder's
     * temporary arrays use R_alloc through predsig_emxalloc.c; its arena is
     * released after every scalar call. OOM unwinds safely as an R error.
     */
    answer = PROTECT(Rf_allocVector(VECSXP, 4));
    names = PROTECT(Rf_allocVector(STRSXP, 4));
    delEPE = PROTECT(Rf_allocVector(REALSXP, count));
    delta = PROTECT(Rf_allocVector(REALSXP, count));
    p_pred = PROTECT(Rf_allocVector(REALSXP, count));
    EPE1 = PROTECT(Rf_allocVector(REALSXP, 1));
    SET_STRING_ELT(names, 0, Rf_mkChar("delEPE"));
    SET_STRING_ELT(names, 1, Rf_mkChar("delta"));
    SET_STRING_ELT(names, 2, Rf_mkChar("p_pred"));
    SET_STRING_ELT(names, 3, Rf_mkChar("EPE1"));
    SET_VECTOR_ELT(answer, 0, delEPE);
    SET_VECTOR_ELT(answer, 1, delta);
    SET_VECTOR_ELT(answer, 2, p_pred);
    SET_VECTOR_ELT(answer, 3, EPE1);
    Rf_setAttrib(answer, R_NamesSymbol, names);

    for (index = 0; index < count; ++index) {
        double observed = REAL(values)[index];
        double contribution, normalized, probability, full_error;
        void *arena;
        R_CheckUserInterrupt();
        arena = vmaxget();
        main_core(observed, variance, N, P, abs_tol, rel_tol,
                            &contribution, &normalized, &probability, &full_error);
        vmaxset(arena);
        if (!R_FINITE(full_error) || full_error <= 0 ||
            (R_FINITE(observed) &&
             (!R_FINITE(contribution) || !R_FINITE(normalized))))
            Rf_error("The supplied scale exceeds floating-point range in the native engine; rescale the outcome or variance.");
        if (!R_FINITE(observed) &&
            (contribution != R_PosInf || normalized != R_PosInf))
            Rf_error("The native engine returned invalid infinite-t endpoint values.");
        if (!R_FINITE(probability) || probability < 0 || probability > 1)
            Rf_error("The native engine could not integrate the predictive tail within probability bounds.");
        REAL(delEPE)[index] = contribution;
        REAL(delta)[index] = normalized;
        REAL(p_pred)[index] = probability;
        REAL(EPE1)[0] = full_error;
    }
    UNPROTECT(7);
    return answer;
}

static void check_model_vector(SEXP input, R_xlen_t count, const char *name)
{
    SEXP dimensions = Rf_getAttrib(input, R_DimSymbol);
    if (!numeric_type(input) || XLENGTH(input) != count ||
        (dimensions != R_NilValue &&
         (XLENGTH(dimensions) != 2 || INTEGER(dimensions)[1] != 1)))
        Rf_error("%s must be a numeric model vector of the expected length.", name);
}

static void check_model_values(SEXP input, const char *name)
{
    const double *data = REAL(input);
    R_xlen_t index;
    for (index = 0; index < XLENGTH(input); ++index) {
        if (!R_FINITE(data[index]))
            Rf_error("%s contains an invalid numeric value.", name);
    }
}

/* Use caller-protected storage for the arrays crossing the generated ABI.
 * Column vectors have one varying dimension; X and results have two. */
static emxArray_real_T borrow_array(SEXP value, int32_t shape[], int dimensions)
{
    emxArray_real_T result;
    result.data = REAL(value);
    result.size = shape;
    result.allocatedSize = (int32_t)XLENGTH(value);
    result.numDimensions = dimensions;
    result.canFreeData = false;
    return result;
}

SEXP predsig_R_supplementary(SEXP y, SEXP X, SEXP b, SEXP se, SEXP sigma2)
{
    SEXP dimensions, y_values, X_values, b_values, se_values;
    SEXP answer, names, results, residuals, leverage, VIF, status;
    int N, P, descriptors_valid;
    int32_t y_shape[1], X_shape[2], b_shape[1], se_shape[1];
    int32_t result_shape[2], residuals_shape[1], leverage_shape[1], vif_shape[1];
    emxArray_real_T y_array, X_array, b_array, se_array;
    emxArray_real_T results_array, residuals_array, leverage_array, vif_array;
    double variance, model_status;
    void *arena;

    /* 1. Validate type/size before coercion or exposing any buffer to Coder. */
    if (!numeric_type(X) || !Rf_isMatrix(X))
        Rf_error("X must be a numeric predictor matrix.");
    dimensions = Rf_getAttrib(X, R_DimSymbol);
    N = INTEGER(dimensions)[0];
    P = INTEGER(dimensions)[1];
    if (N < 1 || P < 1 || P > INT32_MAX / 3 || N <= P + 2 ||
        P + 1 > INT32_MAX / N)
        Rf_error("Require N > P + 2 and model arrays within the generated capacity.");
    check_model_vector(y, N, "y");
    check_model_vector(b, P + 1, "b");
    check_model_vector(se, P + 1, "se");
    variance = finite_scalar(sigma2, "sigma2_hat");
    y_values = PROTECT(Rf_coerceVector(y, REALSXP));
    X_values = PROTECT(Rf_coerceVector(X, REALSXP));
    b_values = PROTECT(Rf_coerceVector(b, REALSXP));
    se_values = PROTECT(Rf_coerceVector(se, REALSXP));
    check_model_values(y_values, "y");
    check_model_values(X_values, "X");
    check_model_values(b_values, "b");
    check_model_values(se_values, "se");

    /* 2. Allocate protected outputs and describe their existing storage. */
    answer = PROTECT(Rf_allocVector(VECSXP, 5));
    names = PROTECT(Rf_allocVector(STRSXP, 5));
    results = PROTECT(Rf_allocMatrix(REALSXP, P, 3));
    residuals = PROTECT(Rf_allocVector(REALSXP, N));
    leverage = PROTECT(Rf_allocVector(REALSXP, N));
    VIF = PROTECT(Rf_allocVector(REALSXP, P));
    status = PROTECT(Rf_allocVector(REALSXP, 1));
    SET_STRING_ELT(names, 0, Rf_mkChar("results"));
    SET_STRING_ELT(names, 1, Rf_mkChar("residuals"));
    SET_STRING_ELT(names, 2, Rf_mkChar("leverage"));
    SET_STRING_ELT(names, 3, Rf_mkChar("VIF"));
    SET_STRING_ELT(names, 4, Rf_mkChar("status"));
    SET_VECTOR_ELT(answer, 0, results);
    SET_VECTOR_ELT(answer, 1, residuals);
    SET_VECTOR_ELT(answer, 2, leverage);
    SET_VECTOR_ELT(answer, 3, VIF);
    SET_VECTOR_ELT(answer, 4, status);
    Rf_setAttrib(answer, R_NamesSymbol, names);

    y_shape[0] = N; X_shape[0] = N; X_shape[1] = P;
    b_shape[0] = P + 1; se_shape[0] = P + 1;
    result_shape[0] = P; result_shape[1] = 3;
    residuals_shape[0] = N; leverage_shape[0] = N; vif_shape[0] = P;
    y_array = borrow_array(y_values, y_shape, 1);
    X_array = borrow_array(X_values, X_shape, 2);
    b_array = borrow_array(b_values, b_shape, 1);
    se_array = borrow_array(se_values, se_shape, 1);
    results_array = borrow_array(results, result_shape, 2);
    residuals_array = borrow_array(residuals, residuals_shape, 1);
    leverage_array = borrow_array(leverage, leverage_shape, 1);
    vif_array = borrow_array(VIF, vif_shape, 1);

    /* 3. Release generated temporary arrays after the call and validate the ABI. */
    R_CheckUserInterrupt();
    arena = vmaxget();
    supplementary_core(&y_array, &X_array, &b_array, &se_array, variance,
                               &results_array, &residuals_array, &leverage_array,
                               &vif_array, REAL(status));
    descriptors_valid = results_array.data == REAL(results) &&
        result_shape[0] == P && result_shape[1] == 3 &&
        residuals_array.data == REAL(residuals) && residuals_shape[0] == N &&
        leverage_array.data == REAL(leverage) && leverage_shape[0] == N &&
        vif_array.data == REAL(VIF) && vif_shape[0] == P;
    vmaxset(arena);
    if (!descriptors_valid)
        Rf_error("The supplementary engine returned invalid output dimensions or ownership.");
    model_status = REAL(status)[0];
    if (model_status != 0 && model_status != 1 && model_status != 2 && model_status != 3)
        Rf_error("The supplementary engine returned an invalid model status.");

    UNPROTECT(11);
    return answer;
}
