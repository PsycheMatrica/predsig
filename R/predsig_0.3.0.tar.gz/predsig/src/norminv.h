/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * norminv.h
 *
 * Code generation for function 'norminv'
 *
 */

#ifndef NORMINV_H
#define NORMINV_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
int32_t norminv(const double p_data[], int32_t p_size, double x_data[]);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (norminv.h) */
