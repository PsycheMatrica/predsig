/* Copyright (C) 2026 Gyeongcheol Cho. CC BY-NC-SA 4.0.
 * Author-owned allocation adapter; generated files retain their own notices.
 */
#ifndef PREDSIG_MEMORY_H
#define PREDSIG_MEMORY_H

#include <stddef.h>

void *predsig_native_alloc(size_t bytes);
void predsig_native_free(void *pointer);

#endif
