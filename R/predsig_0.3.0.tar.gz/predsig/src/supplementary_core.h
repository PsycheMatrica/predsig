/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * supplementary_core.h
 *
 * Code generation for function 'supplementary_core'
 *
 */

#ifndef SUPPLEMENTARY_CORE_H
#define SUPPLEMENTARY_CORE_H

/* Include files */
#include "main_core_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void
supplementary_core(const emxArray_real_T *y, const emxArray_real_T *X,
                   const emxArray_real_T *b, const emxArray_real_T *se,
                   double sigma2, emxArray_real_T *ResultsMat,
                   emxArray_real_T *residuals, emxArray_real_T *leverage,
                   emxArray_real_T *VIF, double *status);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (supplementary_core.h) */
