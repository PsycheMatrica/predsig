/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * unsafeSxfun.c
 *
 * Code generation for function 'unsafeSxfun'
 *
 */

/* Include files */
#include "unsafeSxfun.h"
#include "main_core_emxutil.h"
#include "main_core_types.h"
#include "rt_nonfinite.h"

/* Function Definitions */
void binary_expand_op_1(emxArray_real_T *in1, const emxArray_real_T *in3,
                        const double in4_data[], const int32_t *in4_size,
                        double in5)
{
  emxArray_real_T *b_in3;
  const double *in3_data;
  double *b_in3_data;
  double *in1_data;
  int32_t i;
  int32_t loop_ub;
  int32_t stride_0_0;
  in3_data = in3->data;
  emxInit_real_T(&b_in3, 1);
  loop_ub = *in4_size;
  stride_0_0 = b_in3->size[0];
  b_in3->size[0] = loop_ub;
  emxEnsureCapacity_real_T(b_in3, stride_0_0);
  b_in3_data = b_in3->data;
  stride_0_0 = (in3->size[0] != 1);
  for (i = 0; i < loop_ub; i++) {
    b_in3_data[i] = in3_data[i * stride_0_0] - in4_data[i] * in5;
  }
  stride_0_0 = in1->size[0];
  in1->size[0] = loop_ub;
  emxEnsureCapacity_real_T(in1, stride_0_0);
  in1_data = in1->data;
  for (i = 0; i < loop_ub; i++) {
    double varargin_1;
    varargin_1 = b_in3_data[i];
    in1_data[i] = varargin_1 * varargin_1;
  }
  emxFree_real_T(&b_in3);
}

/* End of code generation (unsafeSxfun.c) */
