/* Copyright (C) 2026 Gyeongcheol Cho. CC BY-NC-SA 4.0 for this adapter only.
 * The included generated file is unmodified and retains its separate notices.
 * Scope allocation hooks to this translation unit, after standard headers;
 * do not rewrite system declarations or the generated source on disk.
 */
#include <stdlib.h>
#include "predsig_memory.h"

#define malloc predsig_native_alloc
#define free predsig_native_free
#include "main_core_emxutil.c"
#undef free
#undef malloc
