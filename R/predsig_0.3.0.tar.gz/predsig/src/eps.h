/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * eps.h
 *
 * Code generation for function 'eps'
 *
 */

#ifndef EPS_H
#define EPS_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
double eps(double x);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (eps.h) */
