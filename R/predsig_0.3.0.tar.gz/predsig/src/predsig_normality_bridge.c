/* Copyright (C) 2026 Gyeongcheol Cho. CC BY-NC-SA 4.0.
 * Handwritten R interface; all diagnostic mathematics is generated MATLAB.
 */
#include <R.h>
#include <Rinternals.h>
#include <R_ext/Memory.h>
#include <R_ext/Utils.h>
#include <limits.h>
#include "normality_core.h"

SEXP predsig_R_normality(SEXP input)
{
    SEXP dimensions, matrix, answer, names, ResultsMat, status;
    int32_t input_size[2], ResultsMat_size[2], status_size[2];
    emxArray_real_T input_array, ResultsMat_array, status_array;
    R_xlen_t count, row, column;
    int N, P, descriptors_valid;
    void *arena;

    if ((TYPEOF(input) != REALSXP && TYPEOF(input) != INTSXP) ||
        !Rf_isMatrix(input))
        Rf_error("Normality input must be a finite numeric predictor matrix.");
    dimensions = Rf_getAttrib(input, R_DimSymbol);
    N = INTEGER(dimensions)[0];
    P = INTEGER(dimensions)[1];
    count = XLENGTH(input);
    if (N < 1 || P < 1 || count > INT_MAX || P > INT_MAX / 12)
        Rf_error("Normality input dimensions exceed the supported native range.");
    matrix = PROTECT(Rf_coerceVector(input, REALSXP));
    for (row = 0; row < count; ++row)
        if (!R_FINITE(REAL(matrix)[row]))
            Rf_error("Normality input must contain only finite values.");

    /* R owns inputs and outputs. Generated temporaries use the same R_alloc
     * adapter as the predictive core; no generated allocator owns these data.
     */
    answer = PROTECT(Rf_allocVector(VECSXP, 2));
    names = PROTECT(Rf_allocVector(STRSXP, 2));
    ResultsMat = PROTECT(Rf_allocMatrix(REALSXP, P, 12));
    status = PROTECT(Rf_allocMatrix(REALSXP, P, 2));
    SET_STRING_ELT(names, 0, Rf_mkChar("ResultsMat"));
    SET_STRING_ELT(names, 1, Rf_mkChar("status"));
    SET_VECTOR_ELT(answer, 0, ResultsMat);
    SET_VECTOR_ELT(answer, 1, status);
    Rf_setAttrib(answer, R_NamesSymbol, names);
    input_size[0] = N; input_size[1] = P;
    ResultsMat_size[0] = P; ResultsMat_size[1] = 12;
    status_size[0] = P; status_size[1] = 2;
    input_array.data = REAL(matrix);
    input_array.size = input_size;
    input_array.allocatedSize = (int32_t) count;
    input_array.numDimensions = 2;
    input_array.canFreeData = false;
    ResultsMat_array.data = REAL(ResultsMat);
    ResultsMat_array.size = ResultsMat_size;
    ResultsMat_array.allocatedSize = P * 12;
    ResultsMat_array.numDimensions = 2;
    ResultsMat_array.canFreeData = false;
    status_array.data = REAL(status);
    status_array.size = status_size;
    status_array.allocatedSize = P * 2;
    status_array.numDimensions = 2;
    status_array.canFreeData = false;

    R_CheckUserInterrupt();
    arena = vmaxget();
    normality_core(&input_array, &ResultsMat_array, &status_array);
    descriptors_valid = ResultsMat_array.data == REAL(ResultsMat) &&
        status_array.data == REAL(status) && ResultsMat_array.numDimensions == 2 &&
        status_array.numDimensions == 2 && ResultsMat_size[0] == P &&
        ResultsMat_size[1] == 12 && status_size[0] == P && status_size[1] == 2;
    vmaxset(arena);
    if (!descriptors_valid)
        Rf_error("The native normality engine returned unexpected output dimensions.");
    for (row = 0; row < P; ++row) {
        double moment_code = REAL(status)[row];
        double shapiro_code = REAL(status)[row + P];
        int shapiro_range = N >= 3 && N <= 5000;
        if ((moment_code != 0 && moment_code != 1 && moment_code != 2) ||
            (N <= 20 && moment_code != 1) || (N > 20 && moment_code == 1) ||
            (shapiro_code != 0 && shapiro_code != 1 && shapiro_code != 2) ||
            (!shapiro_range && shapiro_code != 1) || (shapiro_range && shapiro_code == 1))
            Rf_error("The native normality engine returned an invalid status.");
        for (column = 0; column < 12; ++column) {
            R_xlen_t at = row + (R_xlen_t) P * column;
            double value = REAL(ResultsMat)[at];
            double code = column < 9 ? moment_code : shapiro_code;
            if (code != 0) {
                if (!ISNAN(value))
                    Rf_error("Unavailable native normality values must be missing.");
                REAL(ResultsMat)[at] = NA_REAL;
            } else if (!R_FINITE(value) ||
                ((column == 3 || column == 6 || column == 7 || column == 8 ||
                  column == 9 || column == 10 || column == 11) &&
                 (value < 0 || value > 1)) || (column == 5 && value < 0)) {
                Rf_error("The native normality engine returned invalid diagnostic values.");
            }
        }
    }
    UNPROTECT(5);
    return answer;
}
