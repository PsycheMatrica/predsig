/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * gampdf.c
 *
 * Code generation for function 'gampdf'
 *
 */

/* Include files */
#include "gampdf.h"
#include "gammaln.h"
#include "rt_nonfinite.h"
#include "rt_nonfinite.h"
#include <math.h>

/* Function Definitions */
double f(double z, double a)
{
  static const double sfe[31] = {0.0,
                                 0.1534264097200273,
                                 0.08106146679532726,
                                 0.05481412105191765,
                                 0.04134069595540929,
                                 0.03316287351993629,
                                 0.02767792568499834,
                                 0.0237461636562975,
                                 0.02079067210376509,
                                 0.01848845053267319,
                                 0.01664469118982119,
                                 0.01513497322191738,
                                 0.01387612882307075,
                                 0.01281046524292023,
                                 0.01189670994589177,
                                 0.01110455975820868,
                                 0.0104112652619721,
                                 0.009799416126158802,
                                 0.009255462182712733,
                                 0.008768700134139384,
                                 0.00833056343336287,
                                 0.007934114564314022,
                                 0.007573675487951841,
                                 0.007244554301320383,
                                 0.00694284010720953,
                                 0.006665247032707682,
                                 0.006408994188004207,
                                 0.006171712263039458,
                                 0.005951370112758848,
                                 0.005746216513010116,
                                 0.005554733551962801};
  double y;
  int32_t exponent;
  if (a <= 2.2250738585072014E-308 * z) {
    y = exp(-z);
  } else if (z < 2.2250738585072014E-308 * a) {
    y = a + 1.0;
    gammaln(&y);
    y = exp((a * log(z) - z) - y);
  } else {
    double delta;
    double s;
    double vv;
    double x;
    x = log(a);
    y = a * a;
    if (a <= 15.0) {
      y = 2.0 * a;
      if (y == floor(y)) {
        delta = sfe[(int32_t)(y + 1.0) - 1];
      } else {
        y = a + 1.0;
        gammaln(&y);
        delta = ((y - (a + 0.5) * x) + a) - 0.9189385332046728;
      }
    } else if (a <= 35.0) {
      delta = (0.08333333333333333 -
               (0.002777777777777778 -
                (0.0007936507936507937 -
                 (0.0005952380952380952 - 0.0008417508417508418 / y) / y) /
                    y) /
                   y) /
              a;
    } else if (a <= 80.0) {
      delta = (0.08333333333333333 -
               (0.002777777777777778 -
                (0.0007936507936507937 - 0.0005952380952380952 / y) / y) /
                   y) /
              a;
    } else if (a <= 500.0) {
      delta = (0.08333333333333333 -
               (0.002777777777777778 - 0.0007936507936507937 / y) / y) /
              a;
    } else {
      delta = (0.08333333333333333 - 0.002777777777777778 / y) / a;
    }
    y = a - z;
    vv = a + z;
    if (fabs(y) < 0.1 * vv) {
      double e;
      double j;
      s = y * y / vv;
      y /= vv;
      e = 2.0 * a * y;
      j = 1.0;
      vv = y * y;
      double d;
      do {
        e *= vv;
        j += 2.0;
        d = e / j;
        s += d;
        y = fabs(s);
        if (rtIsInf(y) || rtIsNaN(y)) {
          y = rtNaN;
        } else if (y < 4.450147717014403E-308) {
          y = 5.0E-324;
        } else {
          frexp(y, &exponent);
          y = ldexp(1.0, exponent - 53);
        }
      } while (!(fabs(d) <= y));
    } else {
      s = (a * log(a / z) + z) - a;
    }
    y = exp(((-0.9189385332046727 - 0.5 * x) - delta) - s);
  }
  return y;
}

/* End of code generation (gampdf.c) */
