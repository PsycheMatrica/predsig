/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * xgerc.h
 *
 * Code generation for function 'xgerc'
 *
 */

#ifndef XGERC_H
#define XGERC_H

/* Include files */
#include "main_core_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void xgerc(int32_t m, int32_t n, double alpha1, int32_t ix0,
           const emxArray_real_T *y, emxArray_real_T *A, int32_t ia0,
           int32_t lda);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (xgerc.h) */
