/*
 * Minimal standard-C ABI types for the predsig generated numerical engine.
 * Copyright (C) 2026 Gyeongcheol Cho. CC BY-NC-SA 4.0; see LICENSE.
 *
 * This file is newly authored type glue, not a copy of a MATLAB installation
 * header or a modification of the original generated rtwtypes.h. The raw
 * generated header is retained outside the distribution and inventoried as
 * excluded. No statistical formula or numerical algorithm is implemented here.
 * Keep these four declarations in sync with the actual generated source ABI.
 */
#ifndef PREDSIG_PORTABLE_RTWTYPES_H
#define PREDSIG_PORTABLE_RTWTYPES_H

#include <stdbool.h>
#include <stdint.h>

typedef double real_T;
typedef float real32_T;
typedef uint8_t boolean_T;
typedef struct {
    double re;
    double im;
} creal_T;

#endif
