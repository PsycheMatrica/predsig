/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * var.c
 *
 * Code generation for function 'var'
 *
 */

/* Include files */
#include "var.h"
#include "blockedSummation.h"
#include "main_core_emxutil.h"
#include "main_core_types.h"
#include "rt_nonfinite.h"
#include "rt_nonfinite.h"

/* Function Definitions */
void var(const emxArray_real_T *x, emxArray_real_T *y)
{
  const double *x_data;
  double *xv_data;
  double *y_data;
  int32_t b_loop_ub;
  int32_t k;
  int32_t loop_ub;
  int32_t n;
  int32_t npages;
  int32_t outsize_idx_0;
  int32_t p;
  x_data = x->data;
  loop_ub = y->size[0] * y->size[1];
  y->size[0] = 1;
  y->size[1] = x->size[1];
  emxEnsureCapacity_real_T(y, loop_ub);
  y_data = y->data;
  loop_ub = x->size[1];
  for (k = 0; k < loop_ub; k++) {
    y_data[k] = 0.0;
  }
  npages = x->size[1];
  if (x->size[1] - 1 >= 0) {
    outsize_idx_0 = x->size[0];
    b_loop_ub = x->size[0];
    n = x->size[0];
  }
  emxInit_real_T(&y, 1);
  for (p = 0; p < npages; p++) {
    int32_t workspace_ixfirst;
    workspace_ixfirst = p * x->size[0];
    loop_ub = y->size[0];
    y->size[0] = outsize_idx_0;
    emxEnsureCapacity_real_T(y, loop_ub);
    xv_data = y->data;
    for (k = 0; k < b_loop_ub; k++) {
      xv_data[k] = x_data[workspace_ixfirst + k];
    }
    if (x->size[0] == 0) {
      y_data[p] = rtNaN;
    } else if (x->size[0] == 1) {
      if (!rtIsInf(xv_data[0]) && !rtIsNaN(xv_data[0])) {
        y_data[p] = 0.0;
      } else {
        y_data[p] = rtNaN;
      }
    } else {
      double xbar;
      double yv;
      xbar = blockedSummation(y, x->size[0]) / (double)x->size[0];
      yv = 0.0;
      for (k = 0; k < n; k++) {
        double t;
        t = xv_data[k] - xbar;
        yv += t * t;
      }
      y_data[p] = yv / ((double)x->size[0] - 1.0);
    }
  }
  emxFree_real_T(&y);
}

/* End of code generation (var.c) */
