/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * main_core_emxutil.h
 *
 * Code generation for function 'main_core_emxutil'
 *
 */

#ifndef MAIN_CORE_EMXUTIL_H
#define MAIN_CORE_EMXUTIL_H

/* Include files */
#include "main_core_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void emxEnsureCapacity_boolean_T(emxArray_boolean_T *emxArray,
                                        int32_t oldNumel);

extern void emxEnsureCapacity_int32_T(emxArray_int32_T *emxArray,
                                      int32_t oldNumel);

extern void emxEnsureCapacity_real_T(emxArray_real_T *emxArray,
                                     int32_t oldNumel);

extern void emxFree_boolean_T(emxArray_boolean_T **pEmxArray);

extern void emxFree_int32_T(emxArray_int32_T **pEmxArray);

extern void emxFree_real_T(emxArray_real_T **pEmxArray);

extern void emxInit_boolean_T(emxArray_boolean_T **pEmxArray);

extern void emxInit_int32_T(emxArray_int32_T **pEmxArray,
                            int32_t numDimensions);

extern void emxInit_real_T(emxArray_real_T **pEmxArray, int32_t numDimensions);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (main_core_emxutil.h) */
