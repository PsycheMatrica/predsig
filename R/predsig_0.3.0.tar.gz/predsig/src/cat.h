/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * cat.h
 *
 * Code generation for function 'cat'
 *
 */

#ifndef CAT_H
#define CAT_H

/* Include files */
#include "main_core_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void binary_expand_op_3(emxArray_real_T *in1, const emxArray_real_T *in2,
                        int32_t in3, int32_t in4, const emxArray_real_T *in5,
                        double in6, int32_t in7, const emxArray_real_T *in8,
                        int32_t in9, int32_t in10);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (cat.h) */
