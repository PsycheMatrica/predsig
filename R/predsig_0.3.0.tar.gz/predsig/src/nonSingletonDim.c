/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * nonSingletonDim.c
 *
 * Code generation for function 'nonSingletonDim'
 *
 */

/* Include files */
#include "nonSingletonDim.h"
#include "main_core_types.h"
#include "rt_nonfinite.h"

/* Function Definitions */
int32_t nonSingletonDim(const emxArray_real_T *x)
{
  int32_t dim;
  dim = 2;
  if (x->size[0] != 1) {
    dim = 1;
  }
  return dim;
}

/* End of code generation (nonSingletonDim.c) */
