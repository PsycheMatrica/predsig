/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * main_core_initialize.c
 *
 * Code generation for function 'main_core_initialize'
 *
 */

/* Include files */
#include "main_core_initialize.h"
#include "rt_nonfinite.h"

/* Function Definitions */
void main_core_initialize(void)
{
}

/* End of code generation (main_core_initialize.c) */
