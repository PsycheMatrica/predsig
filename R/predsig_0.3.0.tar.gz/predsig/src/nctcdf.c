/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * nctcdf.c
 *
 * Code generation for function 'nctcdf'
 *
 */

/* Include files */
#include "nctcdf.h"
#include "betainc.h"
#include "eml_erfcore.h"
#include "gammaln.h"
#include "main_core_emxutil.h"
#include "main_core_types.h"
#include "rt_nonfinite.h"
#include "rt_nonfinite.h"
#include <math.h>

/* Function Declarations */
static double local_nctcdf(double x, double nu, double delta);

/* Function Definitions */
static double local_nctcdf(double x, double nu, double delta)
{
  double p;
  if (rtIsInf(x)) {
    p = 0.0;
  } else {
    double B1;
    double E1;
    double E2;
    double E20;
    double P;
    double Q;
    double b_j0;
    double denom;
    double dsq;
    double jj;
    double subtotal;
    boolean_T exitg2;
    p = x * x;
    denom = nu + p;
    P = p / denom;
    Q = nu / denom;
    dsq = delta * delta;
    subtotal = 0.0;
    E20 = dsq / 2.0;
    jj = 2.0 * floor(E20);
    b_j0 = log(0.5 * dsq);
    p = jj / 2.0 + 1.0;
    gammaln(&p);
    E1 = exp((0.5 * jj * b_j0 - E20) - p);
    B1 = (jj + 1.0) / 2.0;
    p = B1 + 1.0;
    gammaln(&p);
    if (rtIsNaN(delta)) {
      denom = rtNaN;
    } else if (delta < 0.0) {
      denom = -1.0;
    } else {
      denom = (delta > 0.0);
    }
    E2 = denom * exp((0.5 * (jj + 1.0) * b_j0 - E20) - p);
    if (P < 0.5) {
      p = nu / 2.0;
      B1 = (b_betainc(P, B1, p)).re;
      p = (b_betainc(P, (jj + 2.0) / 2.0, p)).re;
    } else {
      p = nu / 2.0;
      B1 = (betainc(Q, p, B1)).re;
      p = (betainc(Q, p, (jj + 2.0) / 2.0)).re;
    }
    denom = E1;
    E20 = E2;
    b_j0 = jj;
    int32_t exitg1;
    do {
      exitg1 = 0;
      p = E1 * B1 + E2 * p;
      subtotal += p;
      if (!(fabs(p) >
            (fabs(subtotal) + 2.220446049250313E-16) * 2.220446049250313E-16)) {
        exitg1 = 1;
      } else {
        jj += 2.0;
        E1 = E1 * dsq / jj;
        E2 = E2 * dsq / (jj + 1.0);
        p = nu / 2.0;
        B1 = (b_betainc(P, (jj + 1.0) / 2.0, p)).re;
        p = (b_betainc(P, (jj + 2.0) / 2.0, p)).re;
      }
    } while (exitg1 == 0);
    E1 = denom;
    E2 = E20;
    jj = b_j0;
    exitg2 = false;
    while (!exitg2 && (jj > 0.0)) {
      E1 = E1 * jj / dsq;
      E2 = E2 * (jj + 1.0) / dsq;
      p = nu / 2.0;
      p = E1 * (b_betainc(P, (jj - 1.0) / 2.0, p)).re +
          E2 * (b_betainc(P, jj / 2.0, p)).re;
      subtotal += p;
      if (!(fabs(p) >
            (fabs(subtotal) + 2.220446049250313E-16) * 2.220446049250313E-16)) {
        exitg2 = true;
      } else {
        jj -= 2.0;
      }
    }
    p = fmin(1.0, fmax(0.0, subtotal / 2.0));
  }
  return p;
}

void b_nctcdf(double x, double nu, const emxArray_real_T *delta,
              emxArray_real_T *p)
{
  const double *delta_data;
  double *p_data;
  int32_t i;
  int32_t i1;
  int32_t k;
  delta_data = delta->data;
  i = p->size[0] * p->size[1];
  p->size[0] = 1;
  i1 = delta->size[1];
  p->size[1] = delta->size[1];
  emxEnsureCapacity_real_T(p, i);
  p_data = p->data;
  for (k = 0; k < i1; k++) {
    if ((nu > 0.0) && !rtIsNaN(delta_data[k]) && !rtIsNaN(x)) {
      double xsq;
      xsq = delta_data[k];
      if (xsq == 0.0) {
        if (nu > 1.0E+7) {
          p_data[k] = 0.5 * eml_erfcore(-x / 1.4142135623730951);
        } else if (nu == 1.0) {
          p_data[k] = atan(1.0 / -x) / 3.141592653589793;
        } else {
          xsq = x * x;
          if (nu < xsq) {
            p_data[k] = (betainc(nu / (nu + xsq), nu / 2.0, 0.5)).re / 2.0;
          } else {
            p_data[k] = (b_betainc(xsq / (nu + xsq), 0.5, nu / 2.0)).re / 2.0;
          }
        }
      } else {
        p_data[k] = local_nctcdf(-x, nu, -xsq);
      }
    } else {
      p_data[k] = rtNaN;
    }
  }
}

double nctcdf(double x, double nu, double delta)
{
  double p;
  if ((nu > 0.0) && !rtIsNaN(delta) && !rtIsNaN(x)) {
    if (delta == 0.0) {
      if (nu > 1.0E+7) {
        p = 0.5 * eml_erfcore(-x / 1.4142135623730951);
      } else if (nu == 1.0) {
        p = atan(1.0 / -x) / 3.141592653589793;
      } else {
        p = x * x;
        if (nu < p) {
          p = (betainc(nu / (nu + p), nu / 2.0, 0.5)).re / 2.0;
        } else {
          p = (b_betainc(p / (nu + p), 0.5, nu / 2.0)).re / 2.0;
        }
      }
    } else {
      p = local_nctcdf(-x, nu, -delta);
    }
  } else {
    p = rtNaN;
  }
  return p;
}

/* End of code generation (nctcdf.c) */
