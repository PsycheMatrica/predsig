/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * chi2pdf.h
 *
 * Code generation for function 'chi2pdf'
 *
 */

#ifndef CHI2PDF_H
#define CHI2PDF_H

/* Include files */
#include "main_core_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void chi2pdf(const emxArray_real_T *x, double v, emxArray_real_T *y);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (chi2pdf.h) */
