/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * sum.c
 *
 * Code generation for function 'sum'
 *
 */

/* Include files */
#include "sum.h"
#include "main_core_emxutil.h"
#include "main_core_types.h"
#include "rt_nonfinite.h"

/* Function Definitions */
void sum(const emxArray_real_T *x, emxArray_real_T *y)
{
  const double *x_data;
  double *bsum_data;
  double *y_data;
  int32_t b_xj;
  int32_t ib;
  int32_t xj;
  x_data = x->data;
  if ((x->size[0] == 0) || (x->size[1] == 0)) {
    int32_t firstBlockLength;
    firstBlockLength = y->size[0];
    y->size[0] = x->size[0];
    emxEnsureCapacity_real_T(y, firstBlockLength);
    y_data = y->data;
    firstBlockLength = x->size[0];
    for (xj = 0; xj < firstBlockLength; xj++) {
      y_data[xj] = 0.0;
    }
  } else {
    int32_t bvstride;
    int32_t firstBlockLength;
    int32_t lastBlockLength;
    int32_t nblocks;
    int32_t vstride;
    int32_t xoffset;
    vstride = x->size[0];
    bvstride = x->size[0] << 10;
    firstBlockLength = y->size[0];
    y->size[0] = x->size[0];
    emxEnsureCapacity_real_T(y, firstBlockLength);
    y_data = y->data;
    emxInit_real_T(&y, 1);
    firstBlockLength = y->size[0];
    y->size[0] = x->size[0];
    emxEnsureCapacity_real_T(y, firstBlockLength);
    bsum_data = y->data;
    if (x->size[1] <= 1024) {
      firstBlockLength = x->size[1];
      lastBlockLength = 0;
      nblocks = 1;
    } else {
      firstBlockLength = 1024;
      nblocks = (int32_t)((uint32_t)x->size[1] >> 10);
      lastBlockLength = x->size[1] - (nblocks << 10);
      if (lastBlockLength > 0) {
        nblocks++;
      } else {
        lastBlockLength = 1024;
      }
    }
    for (xj = 0; xj < vstride; xj++) {
      y_data[xj] = x_data[xj];
      bsum_data[xj] = 0.0;
    }
    for (xj = 2; xj <= firstBlockLength; xj++) {
      xoffset = (xj - 1) * vstride;
      for (b_xj = 0; b_xj < vstride; b_xj++) {
        y_data[b_xj] += x_data[xoffset + b_xj];
      }
    }
    for (ib = 2; ib <= nblocks; ib++) {
      int32_t xblockoffset;
      xblockoffset = (ib - 1) * bvstride;
      for (xj = 0; xj < vstride; xj++) {
        bsum_data[xj] = x_data[xblockoffset + xj];
      }
      if (ib == nblocks) {
        firstBlockLength = lastBlockLength;
      } else {
        firstBlockLength = 1024;
      }
      for (xj = 2; xj <= firstBlockLength; xj++) {
        xoffset = xblockoffset + (xj - 1) * vstride;
        for (b_xj = 0; b_xj < vstride; b_xj++) {
          bsum_data[b_xj] += x_data[xoffset + b_xj];
        }
      }
      for (xj = 0; xj < vstride; xj++) {
        y_data[xj] += bsum_data[xj];
      }
    }
    emxFree_real_T(&y);
  }
}

/* End of code generation (sum.c) */
