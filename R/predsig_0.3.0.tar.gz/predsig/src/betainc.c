/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * betainc.c
 *
 * Code generation for function 'betainc'
 *
 */

/* Include files */
#include "betainc.h"
#include "eml_betainc.h"
#include "gammaln.h"
#include "main_core_data.h"
#include "main_core_rtwutil.h"
#include "rt_nonfinite.h"
#include "rt_nonfinite.h"
#include <math.h>

/* Function Definitions */
creal_T b_betainc(double x, double a, double b)
{
  creal_T y;
  double gami;
  double glnb1;
  double logx;
  double tsq;
  int32_t b_i;
  glnb1 = b;
  gammaln(&glnb1);
  gami = a;
  gammaln(&gami);
  tsq = a + b;
  logx = tsq;
  gammaln(&logx);
  gami = (gami + glnb1) - logx;
  if (!(a >= 0.0)) {
    gami = rtNaN;
  } else if ((x > 0.0) && (x < 1.0)) {
    if (a == 0.0) {
      if (b > 0.0) {
        gami = 0.0;
      } else {
        gami = rtNaN;
      }
    } else if (b == 0.0) {
      gami = 1.0;
    } else if (rtIsInf(a)) {
      if (!rtIsInf(b)) {
        gami = 1.0;
      } else {
        gami = rtNaN;
      }
    } else if (rtIsInf(b)) {
      gami = 0.0;
    } else {
      double log1mx;
      boolean_T guard1;
      guard1 = false;
      if (tsq < 1.0E+7) {
        logx = log(x);
        if (1.0 - x != 1.0) {
          log1mx = log(1.0 - x) * (-x / ((1.0 - x) - 1.0));
        } else {
          log1mx = -x;
        }
        if (x < (a + 1.0) / (tsq + 2.0)) {
          gami = 1.0 - exp(((a * logx + b * log1mx) - log(a)) - gami) *
                           betainc_cf(x, a, b);
        } else {
          gami = exp(((a * logx + b * log1mx) - log(b)) - gami) *
                 betainc_cf(1.0 - x, b, a);
        }
        if (!(gami == gami)) {
          guard1 = true;
        }
      } else {
        guard1 = true;
      }
      if (guard1) {
        logx = rt_powd_snf(b * x, 0.3333333333333333);
        gami = rt_powd_snf(a * (1.0 - x), 0.3333333333333333);
        if ((tsq - 1.0) * (1.0 - x) > 0.8) {
          logx = 0.7071067811865475 * (3.0 *
                                       ((1.0 - 1.0 / (9.0 * b)) * logx -
                                        (1.0 - 1.0 / (9.0 * a)) * gami) /
                                       sqrt(logx * logx / b + gami * gami / a));
          gami = 3.97886080735226 / (fabs(logx) + 3.97886080735226);
          gami = 0.5 *
                 ((((((((((((((((((((((0.0012710976495261409 * (gami - 0.5) +
                                       0.00011931402283834095) *
                                          (gami - 0.5) -
                                      0.003963850973605135) *
                                         (gami - 0.5) -
                                     0.0008707796353172959) *
                                        (gami - 0.5) +
                                    0.007736725283135267) *
                                       (gami - 0.5) +
                                   0.003833351262648873) *
                                      (gami - 0.5) -
                                  0.012722381378212275) *
                                     (gami - 0.5) -
                                 0.013382364453346007) *
                                    (gami - 0.5) +
                                0.016131532973325226) *
                                   (gami - 0.5) +
                               0.039097684558848406) *
                                  (gami - 0.5) +
                              0.002493672000535033) *
                                 (gami - 0.5) -
                             0.0838864557023002) *
                                (gami - 0.5) -
                            0.11946395996432542) *
                               (gami - 0.5) +
                           0.016620792496936737) *
                              (gami - 0.5) +
                          0.35752427444953105) *
                             (gami - 0.5) +
                         0.8052764087529106) *
                            (gami - 0.5) +
                        1.1890298290927332) *
                           (gami - 0.5) +
                       1.3704021768233816) *
                          (gami - 0.5) +
                      1.313146538310231) *
                         (gami - 0.5) +
                     1.0792551515585667) *
                        (gami - 0.5) +
                    0.7743681991195386) *
                       (gami - 0.5) +
                   0.49016508058531844) *
                      (gami - 0.5) +
                  0.2753747415973768) *
                 gami * exp(-logx * logx);
          if (logx < 0.0) {
            gami = 1.0 - gami;
          }
        } else {
          double b_x;
          double la;
          b_x = 0.5 * ((tsq - 1.0) * (3.0 - x) - (b - 1.0)) * (1.0 - x);
          la = log(b);
          if (!(b_x > 0.0)) {
            if (b_x == 0.0) {
              gami = 0.0;
            } else {
              gami = rtNaN;
            }
          } else if (rtIsInf(b_x)) {
            gami = 1.0;
          } else {
            double a1;
            double fac;
            double logpax;
            double stirlerr;
            int32_t exitg1;
            if (b <= 15.0) {
              gami = 2.0 * b;
              if (gami == floor(gami)) {
                stirlerr = dv[(int32_t)(gami + 1.0) - 1];
              } else {
                stirlerr = ((glnb1 - (b + 0.5) * la) + b) - 0.9189385332046727;
              }
            } else {
              gami = b * b;
              stirlerr =
                  ((((0.0008417508417508417 / gami - 0.0005952380952380953) /
                         gami +
                     0.0007936507936507937) /
                        gami -
                    0.002777777777777778) /
                       gami +
                   0.08333333333333333) /
                  b;
            }
            fac = b - b_x;
            a1 = b + b_x;
            if (fabs(fac) > 0.1 * a1) {
              if (b < 2.2250738585072014E-308 * b_x) {
                log1mx = b_x;
              } else if ((b_x < 1.0) && (b > 1.7976931348623157E+308 * b_x)) {
                log1mx = (b * la - b * log(b_x)) - b;
              } else {
                log1mx = (b * log(b / b_x) + b_x) - b;
              }
            } else {
              glnb1 = b_x / b;
              gami = (1.0 - glnb1) / (glnb1 + 1.0);
              tsq = gami * gami;
              log1mx = fac * gami;
              glnb1 = log1mx;
              gami = 2.0 * (b * gami);
              logx = 3.0;
              do {
                exitg1 = 0;
                gami *= tsq;
                log1mx += gami / logx;
                if (log1mx == glnb1) {
                  exitg1 = 1;
                } else {
                  glnb1 = log1mx;
                  logx += 2.0;
                }
              } while (exitg1 == 0);
            }
            logpax = (-0.5 * (la + 1.8378770664093453) - stirlerr) - log1mx;
            if (b_x > 1.0E+6) {
              stirlerr = sqrt(b_x);
              glnb1 = fabs(fac - 1.0) / stirlerr;
              tsq = glnb1 * glnb1;
              if (glnb1 < 15.0) {
                gami = 0.7071067811865475 * glnb1;
                logx = 3.97886080735226 / (gami + 3.97886080735226);
                a1 =
                    0.5 *
                    ((((((((((((((((((((((0.0012710976495261409 * (logx - 0.5) +
                                          0.00011931402283834095) *
                                             (logx - 0.5) -
                                         0.003963850973605135) *
                                            (logx - 0.5) -
                                        0.0008707796353172959) *
                                           (logx - 0.5) +
                                       0.007736725283135267) *
                                          (logx - 0.5) +
                                      0.003833351262648873) *
                                         (logx - 0.5) -
                                     0.012722381378212275) *
                                        (logx - 0.5) -
                                    0.013382364453346007) *
                                       (logx - 0.5) +
                                   0.016131532973325226) *
                                      (logx - 0.5) +
                                  0.039097684558848406) *
                                     (logx - 0.5) +
                                 0.002493672000535033) *
                                    (logx - 0.5) -
                                0.0838864557023002) *
                                   (logx - 0.5) -
                               0.11946395996432542) *
                                  (logx - 0.5) +
                              0.016620792496936737) *
                                 (logx - 0.5) +
                             0.35752427444953105) *
                                (logx - 0.5) +
                            0.8052764087529106) *
                               (logx - 0.5) +
                           1.1890298290927332) *
                              (logx - 0.5) +
                          1.3704021768233816) *
                             (logx - 0.5) +
                         1.313146538310231) *
                            (logx - 0.5) +
                        1.0792551515585667) *
                           (logx - 0.5) +
                       0.7743681991195386) *
                          (logx - 0.5) +
                      0.49016508058531844) *
                         (logx - 0.5) +
                     0.2753747415973768) *
                    logx * exp(-gami * gami) * 2.5066282746310002 *
                    exp(0.5 * tsq);
                logx = (a1 * ((tsq - 3.0) * glnb1) - (tsq - 4.0)) / 6.0;
                log1mx = (a1 * ((tsq * tsq - 9.0) * tsq + 6.0) -
                          ((tsq - 1.0) * tsq - 6.0) * glnb1) /
                         72.0;
                gami = 5.0 * tsq;
                gami =
                    (a1 * (((((gami + 45.0) * tsq - 81.0) * tsq - 315.0) * tsq +
                            270.0) *
                           glnb1) -
                     ((((gami + 40.0) * tsq - 111.0) * tsq - 174.0) * tsq +
                      192.0)) /
                    6480.0;
              } else {
                a1 = (((3.0 - 15.0 / tsq) / tsq - 1.0) / tsq + 1.0) / glnb1;
                logx = (((25.0 - 210.0 / tsq) / tsq - 4.0) / tsq + 1.0) / tsq;
                log1mx = (((130.0 - 1750.0 / tsq) / tsq - 11.0) / tsq + 1.0) /
                         (tsq * glnb1);
                gami = (((546.0 - 11368.0 / tsq) / tsq - 26.0) / tsq + 1.0) /
                       (tsq * tsq);
              }
              if (b_x < b - 1.0) {
                gami = b * (((a1 / stirlerr - logx / b_x) +
                             log1mx / (b_x * stirlerr)) -
                            gami / (b_x * b_x));
                if (logpax < 709.782712893384) {
                  gami *= exp(logpax);
                } else {
                  gami = exp(logpax + log(gami));
                }
              } else {
                gami = b * (((a1 / stirlerr + logx / b_x) +
                             log1mx / (b_x * stirlerr)) +
                            gami / (b_x * b_x));
                if (logpax < 709.782712893384) {
                  gami *= exp(logpax);
                } else {
                  gami = exp(logpax + log(gami));
                }
                gami = 1.0 - gami;
              }
            } else if ((b_x < b) || (b_x < 1.0)) {
              double n;
              n = 1.0;
              if (!(b_x < b) && (b < 2.2250738585072014E-308) &&
                  (b_x > 1.7976931348623157E+308 * b)) {
                gami = 1.0;
              } else {
                int32_t i;
                if (b_x > 2.220446049250313E-16 * b) {
                  fac = b_x / b;
                  n = 2.0;
                  do {
                    exitg1 = 0;
                    fac = b_x * fac / (b + (n - 1.0));
                    if (fac < 2.220446049250313E-16) {
                      exitg1 = 1;
                    } else {
                      n++;
                    }
                  } while (exitg1 == 0);
                }
                gami = 0.0;
                i = (int32_t)-((-1.0 - (n - 1.0)) + 1.0);
                for (b_i = 0; b_i < i; b_i++) {
                  gami = b_x * (gami + 1.0) / (b + ((n - 1.0) - (double)b_i));
                }
                gami++;
                if (logpax < 709.782712893384) {
                  gami *= exp(logpax);
                } else {
                  gami = exp(logpax + log(gami));
                }
                if (gami > 1.0) {
                  gami = 1.0;
                }
              }
            } else {
              double n;
              int32_t i;
              fac = 1.0;
              n = 1.0;
              do {
                exitg1 = 0;
                gami = floor(a1);
                if (n <= gami) {
                  fac = (b - n) * fac / b_x;
                  if (fabs(fac) < 2.220446049250313E-16) {
                    exitg1 = 1;
                  } else {
                    n++;
                  }
                } else {
                  exitg1 = 1;
                }
              } while (exitg1 == 0);
              if (n <= gami) {
                gami = 1.0;
              } else {
                la = floor(b);
                logx = b - la;
                if (logx == 0.0) {
                  gami = 1.0;
                  n = la;
                } else if (logx == 0.5) {
                  gami = 0.7071067811865475 * sqrt(2.0 * b_x);
                  logx = 3.97886080735226 / (gami + 3.97886080735226);
                  gami = sqrt(3.141592653589793 * b_x) * exp(b_x) *
                         (2.0 * (0.5 *
                                 ((((((((((((((((((((((0.0012710976495261409 *
                                                           (logx - 0.5) +
                                                       0.00011931402283834095) *
                                                          (logx - 0.5) -
                                                      0.003963850973605135) *
                                                         (logx - 0.5) -
                                                     0.0008707796353172959) *
                                                        (logx - 0.5) +
                                                    0.007736725283135267) *
                                                       (logx - 0.5) +
                                                   0.003833351262648873) *
                                                      (logx - 0.5) -
                                                  0.012722381378212275) *
                                                     (logx - 0.5) -
                                                 0.013382364453346007) *
                                                    (logx - 0.5) +
                                                0.016131532973325226) *
                                                   (logx - 0.5) +
                                               0.039097684558848406) *
                                                  (logx - 0.5) +
                                              0.002493672000535033) *
                                                 (logx - 0.5) -
                                             0.0838864557023002) *
                                                (logx - 0.5) -
                                            0.11946395996432542) *
                                               (logx - 0.5) +
                                           0.016620792496936737) *
                                              (logx - 0.5) +
                                          0.35752427444953105) *
                                             (logx - 0.5) +
                                         0.8052764087529106) *
                                            (logx - 0.5) +
                                        1.1890298290927332) *
                                           (logx - 0.5) +
                                       1.3704021768233816) *
                                          (logx - 0.5) +
                                      1.313146538310231) *
                                         (logx - 0.5) +
                                     1.0792551515585667) *
                                        (logx - 0.5) +
                                    0.7743681991195386) *
                                       (logx - 0.5) +
                                   0.49016508058531844) *
                                      (logx - 0.5) +
                                  0.2753747415973768) *
                                 logx * exp(-gami * gami)));
                  n = la + 1.0;
                } else {
                  log1mx = 1.0;
                  a1 = b_x;
                  tsq = 0.0;
                  stirlerr = 1.0;
                  fac = 1.0 / b_x;
                  n = 1.0;
                  gami = fac;
                  glnb1 = 0.0;
                  while (fabs(gami - glnb1) > 2.220446049250313E-16 * gami) {
                    glnb1 = gami;
                    gami = n - logx;
                    log1mx = (a1 + log1mx * gami) * fac;
                    tsq = (stirlerr + tsq * gami) * fac;
                    gami = n * fac;
                    a1 = b_x * log1mx + gami * a1;
                    stirlerr = b_x * tsq + gami * stirlerr;
                    fac = 1.0 / a1;
                    gami = stirlerr * fac;
                    n++;
                  }
                  gami *= b_x;
                  n = la + 1.0;
                }
              }
              i = (int32_t)-((-1.0 - (n - 1.0)) + 1.0);
              for (b_i = 0; b_i < i; b_i++) {
                gami = (b - ((n - 1.0) - (double)b_i)) * gami / b_x + 1.0;
              }
              gami = gami * b / b_x;
              if (logpax < 709.782712893384) {
                gami *= exp(logpax);
              } else {
                gami = exp(logpax + log(gami));
              }
              if (gami > 1.0) {
                gami = 1.0;
              }
              gami = 1.0 - gami;
            }
          }
        }
      }
    }
  } else if (x == 0.0) {
    gami = 1.0;
  } else if (x == 1.0) {
    gami = 0.0;
  } else {
    gami = rtNaN;
  }
  y.re = gami;
  y.im = 0.0;
  return y;
}

creal_T betainc(double x, double a, double b)
{
  creal_T y;
  double gami;
  double glnb1;
  double logx;
  double tsq;
  int32_t i;
  glnb1 = b;
  gammaln(&glnb1);
  gami = a;
  gammaln(&gami);
  tsq = a + b;
  logx = tsq;
  gammaln(&logx);
  gami = (gami + glnb1) - logx;
  if (!(b >= 0.0)) {
    gami = rtNaN;
  } else if ((x > 0.0) && (x < 1.0)) {
    if (a == 0.0) {
      gami = 1.0;
    } else if (rtIsInf(a)) {
      if (!rtIsInf(b)) {
        gami = 0.0;
      } else {
        gami = rtNaN;
      }
    } else if (rtIsInf(b)) {
      gami = 1.0;
    } else {
      double log1mx;
      boolean_T guard1;
      guard1 = false;
      if (tsq < 1.0E+7) {
        logx = log(x);
        if (1.0 - x != 1.0) {
          log1mx = log(1.0 - x) * (-x / ((1.0 - x) - 1.0));
        } else {
          log1mx = -x;
        }
        if (x < (a + 1.0) / (tsq + 2.0)) {
          gami = exp(((a * logx + b * log1mx) - log(a)) - gami) *
                 betainc_cf(x, a, b);
        } else {
          gami = 1.0 - exp(((a * logx + b * log1mx) - log(b)) - gami) *
                           betainc_cf(1.0 - x, b, a);
        }
        if (!(gami == gami)) {
          guard1 = true;
        }
      } else {
        guard1 = true;
      }
      if (guard1) {
        logx = rt_powd_snf(b * x, 0.3333333333333333);
        gami = rt_powd_snf(a * (1.0 - x), 0.3333333333333333);
        if ((tsq - 1.0) * (1.0 - x) > 0.8) {
          logx =
              0.7071067811865475 * -(3.0 *
                                     ((1.0 - 1.0 / (9.0 * b)) * logx -
                                      (1.0 - 1.0 / (9.0 * a)) * gami) /
                                     sqrt(logx * logx / b + gami * gami / a));
          gami = 3.97886080735226 / (fabs(logx) + 3.97886080735226);
          gami = 0.5 *
                 ((((((((((((((((((((((0.0012710976495261409 * (gami - 0.5) +
                                       0.00011931402283834095) *
                                          (gami - 0.5) -
                                      0.003963850973605135) *
                                         (gami - 0.5) -
                                     0.0008707796353172959) *
                                        (gami - 0.5) +
                                    0.007736725283135267) *
                                       (gami - 0.5) +
                                   0.003833351262648873) *
                                      (gami - 0.5) -
                                  0.012722381378212275) *
                                     (gami - 0.5) -
                                 0.013382364453346007) *
                                    (gami - 0.5) +
                                0.016131532973325226) *
                                   (gami - 0.5) +
                               0.039097684558848406) *
                                  (gami - 0.5) +
                              0.002493672000535033) *
                                 (gami - 0.5) -
                             0.0838864557023002) *
                                (gami - 0.5) -
                            0.11946395996432542) *
                               (gami - 0.5) +
                           0.016620792496936737) *
                              (gami - 0.5) +
                          0.35752427444953105) *
                             (gami - 0.5) +
                         0.8052764087529106) *
                            (gami - 0.5) +
                        1.1890298290927332) *
                           (gami - 0.5) +
                       1.3704021768233816) *
                          (gami - 0.5) +
                      1.313146538310231) *
                         (gami - 0.5) +
                     1.0792551515585667) *
                        (gami - 0.5) +
                    0.7743681991195386) *
                       (gami - 0.5) +
                   0.49016508058531844) *
                      (gami - 0.5) +
                  0.2753747415973768) *
                 gami * exp(-logx * logx);
          if (logx < 0.0) {
            gami = 1.0 - gami;
          }
        } else {
          double b_x;
          double fac;
          b_x = 0.5 * ((tsq - 1.0) * (3.0 - x) - (b - 1.0)) * (1.0 - x);
          fac = log(b);
          if (!(b_x > 0.0)) {
            if (b_x == 0.0) {
              gami = 1.0;
            } else {
              gami = rtNaN;
            }
          } else if (rtIsInf(b_x)) {
            gami = 0.0;
          } else {
            double a1;
            double logpax;
            double n;
            double stirlerr;
            double t;
            int32_t exitg1;
            if (b <= 15.0) {
              gami = 2.0 * b;
              if (gami == floor(gami)) {
                stirlerr = dv[(int32_t)(gami + 1.0) - 1];
              } else {
                stirlerr = ((glnb1 - (b + 0.5) * fac) + b) - 0.9189385332046727;
              }
            } else {
              gami = b * b;
              stirlerr =
                  ((((0.0008417508417508417 / gami - 0.0005952380952380953) /
                         gami +
                     0.0007936507936507937) /
                        gami -
                    0.002777777777777778) /
                       gami +
                   0.08333333333333333) /
                  b;
            }
            n = b - b_x;
            a1 = b + b_x;
            if (fabs(n) > 0.1 * a1) {
              if (b < 2.2250738585072014E-308 * b_x) {
                logx = b_x;
              } else if ((b_x < 1.0) && (b > 1.7976931348623157E+308 * b_x)) {
                logx = (b * fac - b * log(b_x)) - b;
              } else {
                logx = (b * log(b / b_x) + b_x) - b;
              }
            } else {
              t = b_x / b;
              gami = (1.0 - t) / (t + 1.0);
              log1mx = gami * gami;
              logx = n * gami;
              tsq = logx;
              t = 2.0 * (b * gami);
              gami = 3.0;
              do {
                exitg1 = 0;
                t *= log1mx;
                logx += t / gami;
                if (logx == tsq) {
                  exitg1 = 1;
                } else {
                  tsq = logx;
                  gami += 2.0;
                }
              } while (exitg1 == 0);
            }
            logpax = (-0.5 * (fac + 1.8378770664093453) - stirlerr) - logx;
            if (b_x > 1.0E+6) {
              stirlerr = sqrt(b_x);
              t = fabs(n - 1.0) / stirlerr;
              tsq = t * t;
              if (t < 15.0) {
                gami = 0.7071067811865475 * t;
                logx = 3.97886080735226 / (gami + 3.97886080735226);
                a1 =
                    0.5 *
                    ((((((((((((((((((((((0.0012710976495261409 * (logx - 0.5) +
                                          0.00011931402283834095) *
                                             (logx - 0.5) -
                                         0.003963850973605135) *
                                            (logx - 0.5) -
                                        0.0008707796353172959) *
                                           (logx - 0.5) +
                                       0.007736725283135267) *
                                          (logx - 0.5) +
                                      0.003833351262648873) *
                                         (logx - 0.5) -
                                     0.012722381378212275) *
                                        (logx - 0.5) -
                                    0.013382364453346007) *
                                       (logx - 0.5) +
                                   0.016131532973325226) *
                                      (logx - 0.5) +
                                  0.039097684558848406) *
                                     (logx - 0.5) +
                                 0.002493672000535033) *
                                    (logx - 0.5) -
                                0.0838864557023002) *
                                   (logx - 0.5) -
                               0.11946395996432542) *
                                  (logx - 0.5) +
                              0.016620792496936737) *
                                 (logx - 0.5) +
                             0.35752427444953105) *
                                (logx - 0.5) +
                            0.8052764087529106) *
                               (logx - 0.5) +
                           1.1890298290927332) *
                              (logx - 0.5) +
                          1.3704021768233816) *
                             (logx - 0.5) +
                         1.313146538310231) *
                            (logx - 0.5) +
                        1.0792551515585667) *
                           (logx - 0.5) +
                       0.7743681991195386) *
                          (logx - 0.5) +
                      0.49016508058531844) *
                         (logx - 0.5) +
                     0.2753747415973768) *
                    logx * exp(-gami * gami) * 2.5066282746310002 *
                    exp(0.5 * tsq);
                logx = (a1 * ((tsq - 3.0) * t) - (tsq - 4.0)) / 6.0;
                log1mx = (a1 * ((tsq * tsq - 9.0) * tsq + 6.0) -
                          ((tsq - 1.0) * tsq - 6.0) * t) /
                         72.0;
                gami = 5.0 * tsq;
                gami =
                    (a1 * (((((gami + 45.0) * tsq - 81.0) * tsq - 315.0) * tsq +
                            270.0) *
                           t) -
                     ((((gami + 40.0) * tsq - 111.0) * tsq - 174.0) * tsq +
                      192.0)) /
                    6480.0;
              } else {
                a1 = (((3.0 - 15.0 / tsq) / tsq - 1.0) / tsq + 1.0) / t;
                logx = (((25.0 - 210.0 / tsq) / tsq - 4.0) / tsq + 1.0) / tsq;
                log1mx = (((130.0 - 1750.0 / tsq) / tsq - 11.0) / tsq + 1.0) /
                         (tsq * t);
                gami = (((546.0 - 11368.0 / tsq) / tsq - 26.0) / tsq + 1.0) /
                       (tsq * tsq);
              }
              if (b_x < b - 1.0) {
                gami = b * (((a1 / stirlerr - logx / b_x) +
                             log1mx / (b_x * stirlerr)) -
                            gami / (b_x * b_x));
                if (logpax < 709.782712893384) {
                  gami *= exp(logpax);
                } else {
                  gami = exp(logpax + log(gami));
                }
                gami = 1.0 - gami;
              } else {
                gami = b * (((a1 / stirlerr + logx / b_x) +
                             log1mx / (b_x * stirlerr)) +
                            gami / (b_x * b_x));
                if (logpax < 709.782712893384) {
                  gami *= exp(logpax);
                } else {
                  gami = exp(logpax + log(gami));
                }
              }
            } else if ((b_x < 1.0) && (b < 1.0)) {
              fac = b * -b_x;
              log1mx = fac / (b + 1.0);
              n = 2.0;
              do {
                exitg1 = 0;
                fac = -b_x * fac / n;
                t = fac / (b + n);
                log1mx += t;
                if (fabs(t) <= fabs(log1mx) * 2.220446049250313E-16) {
                  exitg1 = 1;
                } else {
                  n++;
                }
              } while (exitg1 == 0);
              gami = b * log(b_x) - glnb1;
              logx = exp(gami);
              if (!(logx == 1.0)) {
                if (logx - 1.0 == -1.0) {
                  gami = -1.0;
                } else {
                  gami = (logx - 1.0) * gami / log(logx);
                }
              }
              gami = -((log1mx + gami) + log1mx * gami);
              if (gami < 0.0) {
                gami = 0.0;
              }
            } else if ((b_x < b) || (b_x < 1.0)) {
              int32_t afrac_tmp;
              n = 1.0;
              if (b_x > 2.220446049250313E-16 * b) {
                fac = b_x / b;
                n = 2.0;
                do {
                  exitg1 = 0;
                  fac = b_x * fac / (b + (n - 1.0));
                  if (fac < 2.220446049250313E-16) {
                    exitg1 = 1;
                  } else {
                    n++;
                  }
                } while (exitg1 == 0);
              }
              gami = 0.0;
              afrac_tmp = (int32_t)-((-1.0 - (n - 1.0)) + 1.0);
              for (i = 0; i < afrac_tmp; i++) {
                gami = b_x * (gami + 1.0) / (b + ((n - 1.0) - (double)i));
              }
              gami++;
              if (logpax < 709.782712893384) {
                gami *= exp(logpax);
              } else {
                gami = exp(logpax + log(gami));
              }
              if (gami > 1.0) {
                gami = 1.0;
              }
              gami = 1.0 - gami;
            } else {
              int32_t afrac_tmp;
              fac = 1.0;
              n = 1.0;
              do {
                exitg1 = 0;
                afrac_tmp = (int32_t)floor(a1);
                if ((int32_t)n <= afrac_tmp) {
                  fac = (b - n) * fac / b_x;
                  if (fabs(fac) < 2.220446049250313E-16) {
                    exitg1 = 1;
                  } else {
                    n++;
                  }
                } else {
                  exitg1 = 1;
                }
              } while (exitg1 == 0);
              if ((int32_t)n <= afrac_tmp) {
                gami = 1.0;
              } else {
                afrac_tmp = (int32_t)floor(b);
                logx = b - (double)afrac_tmp;
                if (logx == 0.0) {
                  gami = 1.0;
                  n = afrac_tmp;
                } else if (logx == 0.5) {
                  gami = 0.7071067811865475 * sqrt(2.0 * b_x);
                  logx = 3.97886080735226 / (gami + 3.97886080735226);
                  gami = sqrt(3.141592653589793 * b_x) * exp(b_x) *
                         (2.0 * (0.5 *
                                 ((((((((((((((((((((((0.0012710976495261409 *
                                                           (logx - 0.5) +
                                                       0.00011931402283834095) *
                                                          (logx - 0.5) -
                                                      0.003963850973605135) *
                                                         (logx - 0.5) -
                                                     0.0008707796353172959) *
                                                        (logx - 0.5) +
                                                    0.007736725283135267) *
                                                       (logx - 0.5) +
                                                   0.003833351262648873) *
                                                      (logx - 0.5) -
                                                  0.012722381378212275) *
                                                     (logx - 0.5) -
                                                 0.013382364453346007) *
                                                    (logx - 0.5) +
                                                0.016131532973325226) *
                                                   (logx - 0.5) +
                                               0.039097684558848406) *
                                                  (logx - 0.5) +
                                              0.002493672000535033) *
                                                 (logx - 0.5) -
                                             0.0838864557023002) *
                                                (logx - 0.5) -
                                            0.11946395996432542) *
                                               (logx - 0.5) +
                                           0.016620792496936737) *
                                              (logx - 0.5) +
                                          0.35752427444953105) *
                                             (logx - 0.5) +
                                         0.8052764087529106) *
                                            (logx - 0.5) +
                                        1.1890298290927332) *
                                           (logx - 0.5) +
                                       1.3704021768233816) *
                                          (logx - 0.5) +
                                      1.313146538310231) *
                                         (logx - 0.5) +
                                     1.0792551515585667) *
                                        (logx - 0.5) +
                                    0.7743681991195386) *
                                       (logx - 0.5) +
                                   0.49016508058531844) *
                                      (logx - 0.5) +
                                  0.2753747415973768) *
                                 logx * exp(-gami * gami)));
                  n = (double)afrac_tmp + 1.0;
                } else {
                  log1mx = 1.0;
                  a1 = b_x;
                  tsq = 0.0;
                  stirlerr = 1.0;
                  fac = 1.0 / b_x;
                  n = 1.0;
                  gami = fac;
                  t = 0.0;
                  while (fabs(gami - t) > 2.220446049250313E-16 * gami) {
                    t = gami;
                    gami = n - logx;
                    log1mx = (a1 + log1mx * gami) * fac;
                    tsq = (stirlerr + tsq * gami) * fac;
                    gami = n * fac;
                    a1 = b_x * log1mx + gami * a1;
                    stirlerr = b_x * tsq + gami * stirlerr;
                    fac = 1.0 / a1;
                    gami = stirlerr * fac;
                    n++;
                  }
                  gami *= b_x;
                  n = (double)afrac_tmp + 1.0;
                }
              }
              afrac_tmp = (int32_t)n;
              for (i = 0; i <= afrac_tmp - 2; i++) {
                gami = (b - ((n - 1.0) - (double)i)) * gami / b_x + 1.0;
              }
              gami = gami * b / b_x;
              if (logpax < 709.782712893384) {
                gami *= exp(logpax);
              } else {
                gami = exp(logpax + log(gami));
              }
              if (gami > 1.0) {
                gami = 1.0;
              }
            }
          }
        }
      }
    }
  } else if (x == 0.0) {
    gami = 0.0;
  } else if (x == 1.0) {
    gami = 1.0;
  } else {
    gami = rtNaN;
  }
  y.re = gami;
  y.im = 0.0;
  return y;
}

/* End of code generation (betainc.c) */
