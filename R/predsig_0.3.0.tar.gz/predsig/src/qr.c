/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * qr.c
 *
 * Code generation for function 'qr'
 *
 */

/* Include files */
#include "qr.h"
#include "main_core_emxutil.h"
#include "main_core_types.h"
#include "rt_nonfinite.h"
#include "xgerc.h"
#include "xzlarf.h"
#include "xzlarfg.h"

/* Function Definitions */
void qr(const emxArray_real_T *A, emxArray_real_T *Q, emxArray_real_T *R)
{
  emxArray_real_T *b_A;
  emxArray_real_T *tau;
  emxArray_real_T *work;
  const double *A_data;
  double c;
  double *R_data;
  double *b_A_data;
  double *tau_data;
  int32_t b_i;
  int32_t c_i;
  int32_t i;
  int32_t ia;
  int32_t j;
  int32_t lastc;
  int32_t loop_ub;
  int32_t m;
  int32_t minmana;
  int32_t minsz;
  int32_t n;
  A_data = A->data;
  emxInit_real_T(&b_A, 2);
  lastc = A->size[0];
  ia = b_A->size[0] * b_A->size[1];
  b_A->size[0] = A->size[0];
  loop_ub = A->size[1];
  b_A->size[1] = A->size[1];
  emxEnsureCapacity_real_T(b_A, ia);
  b_A_data = b_A->data;
  ia = A->size[0] * A->size[1];
  for (i = 0; i < ia; i++) {
    b_A_data[i] = A_data[i];
  }
  ia = A->size[0];
  minmana = A->size[1];
  if (ia <= minmana) {
    minmana = ia;
  }
  emxInit_real_T(&tau, 1);
  ia = tau->size[0];
  tau->size[0] = minmana;
  emxEnsureCapacity_real_T(tau, ia);
  tau_data = tau->data;
  for (i = 0; i < minmana; i++) {
    tau_data[i] = 0.0;
  }
  emxInit_real_T(&work, 1);
  if ((A->size[0] != 0) && (A->size[1] != 0) && (minmana >= 1)) {
    ia = work->size[0];
    work->size[0] = A->size[1];
    emxEnsureCapacity_real_T(work, ia);
    R_data = work->data;
    for (i = 0; i < loop_ub; i++) {
      R_data[i] = 0.0;
    }
    for (i = 0; i < minmana; i++) {
      double d;
      ia = i * lastc + i;
      n = lastc - i;
      if (i + 1 < lastc) {
        c = b_A_data[ia];
        d = xzlarfg(n, &c, b_A, ia + 2);
        b_A_data = b_A->data;
        tau_data[i] = d;
        b_A_data[ia] = c;
      } else {
        d = 0.0;
        tau_data[i] = 0.0;
      }
      if (i + 1 < loop_ub) {
        c = b_A_data[ia];
        b_A_data[ia] = 1.0;
        xzlarf(n, (loop_ub - i) - 1, ia + 1, d, b_A, (ia + lastc) + 1, lastc,
               work);
        b_A_data = b_A->data;
        b_A_data[ia] = c;
      }
    }
  }
  m = b_A->size[0];
  n = b_A->size[1];
  ia = b_A->size[0];
  minsz = b_A->size[1];
  if (ia <= minsz) {
    minsz = ia;
  }
  ia = R->size[0] * R->size[1];
  R->size[0] = minsz;
  R->size[1] = b_A->size[1];
  emxEnsureCapacity_real_T(R, ia);
  R_data = R->data;
  for (j = 0; j < minsz; j++) {
    for (i = 0; i <= j; i++) {
      R_data[i + R->size[0] * j] = b_A_data[i + b_A->size[0] * j];
    }
    for (b_i = j + 2; b_i <= minsz; b_i++) {
      R_data[(b_i + R->size[0] * j) - 1] = 0.0;
    }
  }
  ia = b_A->size[0] + 1;
  for (i = ia; i <= n; i++) {
    for (b_i = 0; b_i < minsz; b_i++) {
      R_data[b_i + R->size[0] * (i - 1)] =
          b_A_data[b_i + b_A->size[0] * (i - 1)];
    }
  }
  if (minsz >= 1) {
    int32_t itau;
    for (i = minsz; i < minsz; i++) {
      ia = i * m;
      for (b_i = 0; b_i < m; b_i++) {
        b_A_data[ia + b_i] = 0.0;
      }
      b_A_data[ia + i] = 1.0;
    }
    itau = minsz - 1;
    ia = work->size[0];
    work->size[0] = b_A->size[1];
    emxEnsureCapacity_real_T(work, ia);
    R_data = work->data;
    for (i = 0; i < n; i++) {
      R_data[i] = 0.0;
    }
    for (c_i = minsz; c_i >= 1; c_i--) {
      int32_t iaii;
      iaii = (c_i + (c_i - 1) * m) - 1;
      if (c_i < minsz) {
        int32_t ic0;
        int32_t lastv;
        b_A_data[iaii] = 1.0;
        loop_ub = iaii + m;
        ic0 = loop_ub + 1;
        if (tau_data[itau] != 0.0) {
          boolean_T exitg2;
          lastv = (m - c_i) + 1;
          ia = loop_ub - c_i;
          while ((lastv > 0) && (b_A_data[ia] == 0.0)) {
            lastv--;
            ia--;
          }
          lastc = minsz - c_i;
          exitg2 = false;
          while (!exitg2 && (lastc > 0)) {
            int32_t exitg1;
            ia = (loop_ub + (lastc - 1) * m) + 1;
            n = ia;
            do {
              exitg1 = 0;
              if (n <= (ia + lastv) - 1) {
                if (b_A_data[n - 1] != 0.0) {
                  exitg1 = 1;
                } else {
                  n++;
                }
              } else {
                lastc--;
                exitg1 = 2;
              }
            } while (exitg1 == 0);
            if (exitg1 == 1) {
              exitg2 = true;
            }
          }
        } else {
          lastv = 0;
          lastc = 0;
        }
        if (lastv > 0) {
          if (lastc != 0) {
            for (i = 0; i < lastc; i++) {
              R_data[i] = 0.0;
            }
            ia = 0;
            n = (loop_ub + m * (lastc - 1)) + 1;
            for (i = ic0; m < 0 ? i >= n : i <= n; i += m) {
              c = 0.0;
              minmana = i + lastv;
              for (b_i = i; b_i < minmana; b_i++) {
                c += b_A_data[b_i - 1] * b_A_data[(iaii + b_i) - i];
              }
              R_data[ia] += c;
              ia++;
            }
          }
          xgerc(lastv, lastc, -tau_data[itau], iaii + 1, work, b_A, loop_ub + 1,
                m);
          b_A_data = b_A->data;
        }
      }
      if (c_i < m) {
        ia = ((iaii + m) - c_i) + 1;
        for (i = iaii + 2; i <= ia; i++) {
          b_A_data[i - 1] *= -tau_data[itau];
        }
      }
      b_A_data[iaii] = 1.0 - tau_data[itau];
      for (i = 0; i <= c_i - 2; i++) {
        b_A_data[(iaii - i) - 1] = 0.0;
      }
      itau--;
    }
  }
  emxFree_real_T(&work);
  emxFree_real_T(&tau);
  ia = Q->size[0] * Q->size[1];
  Q->size[0] = b_A->size[0];
  Q->size[1] = minsz;
  emxEnsureCapacity_real_T(Q, ia);
  R_data = Q->data;
  for (i = 0; i < minsz; i++) {
    for (b_i = 0; b_i < m; b_i++) {
      R_data[b_i + Q->size[0] * i] = b_A_data[b_i + b_A->size[0] * i];
    }
  }
  emxFree_real_T(&b_A);
}

/* End of code generation (qr.c) */
