/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * asinh.h
 *
 * Code generation for function 'asinh'
 *
 */

#ifndef ASINH_H
#define ASINH_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void b_asinh(double *x);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (asinh.h) */
