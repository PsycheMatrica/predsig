/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * norminv.c
 *
 * Code generation for function 'norminv'
 *
 */

/* Include files */
#include "norminv.h"
#include "eml_erfcore.h"
#include "rt_nonfinite.h"
#include "rt_nonfinite.h"
#include <math.h>

/* Function Definitions */
int32_t norminv(const double p_data[], int32_t p_size, double x_data[])
{
  int32_t eint;
  int32_t k;
  int32_t x_size;
  x_size = p_size;
  for (k = 0; k < p_size; k++) {
    double z;
    z = p_data[k];
    if (z <= 1.0) {
      double b_x;
      double x;
      x = 2.0 * z;
      if (x >= 2.0) {
        b_x = rtMinusInf;
      } else if (x > 1.7) {
        z = sqrt(-log((2.0 - x) / 2.0));
        b_x = -(((1.641345311 * z + 3.429567803) * z - 1.624906493) * z -
                1.970840454) /
              ((1.6370678 * z + 3.5438892) * z + 1.0);
        z = (eml_erfcore(-b_x) - (2.0 - x)) /
            (1.1283791670955126 * exp(-b_x * b_x));
        b_x -= z / (b_x * z + 1.0);
        z = (eml_erfcore(-b_x) - (2.0 - x)) /
            (1.1283791670955126 * exp(-b_x * b_x));
        b_x -= z / (b_x * z + 1.0);
      } else if (x < 0.3) {
        z = sqrt(0.6931471805599453 - log(x));
        b_x = (((1.641345311 * z + 3.429567803) * z - 1.624906493) * z -
               1.970840454) /
              ((1.6370678 * z + 3.5438892) * z + 1.0);
        z = -(eml_erfcore(b_x) - x) / (1.1283791670955126 * exp(-b_x * b_x));
        b_x -= z / (b_x * z + 1.0);
        z = -(eml_erfcore(b_x) - x) / (1.1283791670955126 * exp(-b_x * b_x));
        b_x -= z / (b_x * z + 1.0);
      } else {
        double P;
        double R;
        double absx;
        int32_t exponent;
        z = (1.0 - x) * (1.0 - x);
        b_x = (1.0 - x) *
              (((-0.140543331 * z + 0.914624893) * z - 1.645349621) * z +
               0.886226899) /
              ((((0.012229801 * z - 0.329097515) * z + 1.442710462) * z -
                2.118377725) *
                   z +
               1.0);
        /* ========================== COPYRIGHT NOTICE
         * ============================ */
        /*  The algorithms for calculating ERF(X) and ERFC(X) are derived */
        /*  from FDLIBM, which has the following notice: */
        /*                                                                          */
        /*  Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
        /*                                                                          */
        /*  Developed at SunSoft, a Sun Microsystems, Inc. business. */
        /*  Permission to use, copy, modify, and distribute this */
        /*  software is freely granted, provided that this notice */
        /*  is preserved. */
        /* =============================    END ================================
         */
        absx = fabs(b_x);
        if (rtIsNaN(b_x)) {
          z = rtNaN;
        } else if (rtIsInf(b_x)) {
          if (b_x < 0.0) {
            z = -1.0;
          } else {
            z = 1.0;
          }
        } else if (absx < 0.84375) {
          if (absx < 3.725290298461914E-9) {
            if (absx < 2.848094538889218E-306) {
              z = 0.125 * (8.0 * b_x + 1.0270333367641007 * b_x);
            } else {
              z = b_x + 0.1283791670955126 * b_x;
            }
          } else {
            z = b_x * b_x;
            z = b_x + b_x * ((z * (z * (z * (z * -2.3763016656650163E-5 -
                                             0.005770270296489442) -
                                        0.02848174957559851) -
                                   0.3250421072470015) +
                              0.12837916709551256) /
                             (z * (z * (z * (z * (z * -3.960228278775368E-6 +
                                                  0.00013249473800432164) +
                                             0.005081306281875766) +
                                        0.0650222499887673) +
                                   0.39791722395915535) +
                              1.0));
          }
        } else if (absx < 1.25) {
          P = (absx - 1.0) *
                  ((absx - 1.0) *
                       ((absx - 1.0) *
                            ((absx - 1.0) *
                                 ((absx - 1.0) *
                                      ((absx - 1.0) * -0.002166375594868791 +
                                       0.035478304325618236) -
                                  0.11089469428239668) +
                             0.31834661990116175) -
                        0.3722078760357013) +
                   0.41485611868374833) -
              0.0023621185607526594;
          z = (absx - 1.0) *
                  ((absx - 1.0) *
                       ((absx - 1.0) *
                            ((absx - 1.0) *
                                 ((absx - 1.0) *
                                      ((absx - 1.0) * 0.011984499846799107 +
                                       0.01363708391202905) +
                                  0.12617121980876164) +
                             0.07182865441419627) +
                        0.540397917702171) +
                   0.10642088040084423) +
              1.0;
          if (b_x >= 0.0) {
            z = P / z + 0.8450629115104675;
          } else {
            z = -0.8450629115104675 - P / z;
          }
        } else if (absx > 6.0) {
          if (b_x < 0.0) {
            z = -1.0;
          } else {
            z = 1.0;
          }
        } else {
          z = 1.0 / (absx * absx);
          if (absx < 2.8571434020996094) {
            R = z * (z * (z * (z * (z * (z * (z * -9.814329344169145 -
                                              81.2874355063066) -
                                         184.60509290671104) -
                                    162.39666946257347) -
                               62.375332450326006) -
                          10.558626225323291) -
                     0.6938585727071818) -
                0.009864944034847148;
            P = z * (z * (z * (z * (z * (z * (z * (z * -0.0604244152148581 +
                                                   6.570249770319282) +
                                              108.63500554177944) +
                                         429.00814002756783) +
                                    645.3872717332679) +
                               434.56587747522923) +
                          137.65775414351904) +
                     19.651271667439257) +
                1.0;
          } else {
            R = z * (z * (z * (z * (z * (z * -483.5191916086514 -
                                         1025.0951316110772) -
                                    637.5664433683896) -
                               160.63638485582192) -
                          17.757954917754752) -
                     0.799283237680523) -
                0.0098649429247001;
            P = z * (z * (z * (z * (z * (z * (z * -22.44095244658582 +
                                              474.52854120695537) +
                                         2553.0504064331644) +
                                    3199.8582195085955) +
                               1536.729586084437) +
                          325.7925129965739) +
                     30.33806074348246) +
                1.0;
          }
          if (!rtIsNaN(absx)) {
            z = frexp(absx, &eint);
            exponent = eint;
          } else {
            z = rtNaN;
            exponent = 0;
          }
          z = floor(z * 2.097152E+6) / 2.097152E+6 * ldexp(1.0, exponent);
          z = exp(-z * z - 0.5625) * exp((z - absx) * (z + absx) + R / P) /
              absx;
          if (b_x < 0.0) {
            z--;
          } else {
            z = 1.0 - z;
          }
        }
        z = (z - (1.0 - x)) / (1.1283791670955126 * exp(-b_x * b_x));
        b_x -= z / (b_x * z + 1.0);
        /* ========================== COPYRIGHT NOTICE
         * ============================ */
        /*  The algorithms for calculating ERF(X) and ERFC(X) are derived */
        /*  from FDLIBM, which has the following notice: */
        /*                                                                          */
        /*  Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved. */
        /*                                                                          */
        /*  Developed at SunSoft, a Sun Microsystems, Inc. business. */
        /*  Permission to use, copy, modify, and distribute this */
        /*  software is freely granted, provided that this notice */
        /*  is preserved. */
        /* =============================    END ================================
         */
        absx = fabs(b_x);
        if (rtIsNaN(b_x)) {
          z = rtNaN;
        } else if (rtIsInf(b_x)) {
          if (b_x < 0.0) {
            z = -1.0;
          } else {
            z = 1.0;
          }
        } else if (absx < 0.84375) {
          if (absx < 3.725290298461914E-9) {
            if (absx < 2.848094538889218E-306) {
              z = 0.125 * (8.0 * b_x + 1.0270333367641007 * b_x);
            } else {
              z = b_x + 0.1283791670955126 * b_x;
            }
          } else {
            z = b_x * b_x;
            z = b_x + b_x * ((z * (z * (z * (z * -2.3763016656650163E-5 -
                                             0.005770270296489442) -
                                        0.02848174957559851) -
                                   0.3250421072470015) +
                              0.12837916709551256) /
                             (z * (z * (z * (z * (z * -3.960228278775368E-6 +
                                                  0.00013249473800432164) +
                                             0.005081306281875766) +
                                        0.0650222499887673) +
                                   0.39791722395915535) +
                              1.0));
          }
        } else if (absx < 1.25) {
          P = (absx - 1.0) *
                  ((absx - 1.0) *
                       ((absx - 1.0) *
                            ((absx - 1.0) *
                                 ((absx - 1.0) *
                                      ((absx - 1.0) * -0.002166375594868791 +
                                       0.035478304325618236) -
                                  0.11089469428239668) +
                             0.31834661990116175) -
                        0.3722078760357013) +
                   0.41485611868374833) -
              0.0023621185607526594;
          z = (absx - 1.0) *
                  ((absx - 1.0) *
                       ((absx - 1.0) *
                            ((absx - 1.0) *
                                 ((absx - 1.0) *
                                      ((absx - 1.0) * 0.011984499846799107 +
                                       0.01363708391202905) +
                                  0.12617121980876164) +
                             0.07182865441419627) +
                        0.540397917702171) +
                   0.10642088040084423) +
              1.0;
          if (b_x >= 0.0) {
            z = P / z + 0.8450629115104675;
          } else {
            z = -0.8450629115104675 - P / z;
          }
        } else if (absx > 6.0) {
          if (b_x < 0.0) {
            z = -1.0;
          } else {
            z = 1.0;
          }
        } else {
          z = 1.0 / (absx * absx);
          if (absx < 2.8571434020996094) {
            R = z * (z * (z * (z * (z * (z * (z * -9.814329344169145 -
                                              81.2874355063066) -
                                         184.60509290671104) -
                                    162.39666946257347) -
                               62.375332450326006) -
                          10.558626225323291) -
                     0.6938585727071818) -
                0.009864944034847148;
            P = z * (z * (z * (z * (z * (z * (z * (z * -0.0604244152148581 +
                                                   6.570249770319282) +
                                              108.63500554177944) +
                                         429.00814002756783) +
                                    645.3872717332679) +
                               434.56587747522923) +
                          137.65775414351904) +
                     19.651271667439257) +
                1.0;
          } else {
            R = z * (z * (z * (z * (z * (z * -483.5191916086514 -
                                         1025.0951316110772) -
                                    637.5664433683896) -
                               160.63638485582192) -
                          17.757954917754752) -
                     0.799283237680523) -
                0.0098649429247001;
            P = z * (z * (z * (z * (z * (z * (z * -22.44095244658582 +
                                              474.52854120695537) +
                                         2553.0504064331644) +
                                    3199.8582195085955) +
                               1536.729586084437) +
                          325.7925129965739) +
                     30.33806074348246) +
                1.0;
          }
          if (!rtIsNaN(absx)) {
            z = frexp(absx, &eint);
            exponent = eint;
          } else {
            z = rtNaN;
            exponent = 0;
          }
          z = floor(z * 2.097152E+6) / 2.097152E+6 * ldexp(1.0, exponent);
          z = exp(-z * z - 0.5625) * exp((z - absx) * (z + absx) + R / P) /
              absx;
          if (b_x < 0.0) {
            z--;
          } else {
            z = 1.0 - z;
          }
        }
        z = (z - (1.0 - x)) / (1.1283791670955126 * exp(-b_x * b_x));
        b_x -= z / (b_x * z + 1.0);
      }
      x_data[k] = -1.4142135623730951 * b_x;
    } else {
      x_data[k] = rtNaN;
    }
  }
  return x_size;
}

/* End of code generation (norminv.c) */
