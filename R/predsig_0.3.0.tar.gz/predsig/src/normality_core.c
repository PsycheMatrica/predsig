/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * normality_core.c
 *
 * Code generation for function 'normality_core'
 *
 */

/* Include files */
#include "normality_core.h"
#include "abs.h"
#include "all.h"
#include "asinh.h"
#include "blockedSummation.h"
#include "eml_erfcore.h"
#include "flipud.h"
#include "main_core_emxutil.h"
#include "main_core_rtwutil.h"
#include "main_core_types.h"
#include "minOrMax.h"
#include "nonSingletonDim.h"
#include "norminv.h"
#include "rt_nonfinite.h"
#include "sort.h"
#include "unsafeSxfun.h"
#include "useConstantDim.h"
#include "vvarstd.h"
#include "xnrm2.h"
#include "rt_nonfinite.h"
#include <math.h>
#include <string.h>

/* Function Declarations */
static void holm(emxArray_real_T *p, emxArray_real_T *adjusted);

/* Function Definitions */
static void holm(emxArray_real_T *p, emxArray_real_T *adjusted)
{
  emxArray_int32_T *iidx;
  emxArray_int32_T *r;
  emxArray_real_T *x;
  double *p_data;
  double *x_data;
  int32_t end;
  int32_t i;
  int32_t partialTrueCount;
  int32_t trueCount;
  int32_t *iidx_data;
  int32_t *r1;
  p_data = p->data;
  /*  Holm (1979) adjustment; the full reference is above. */
  /*  Keep the planned family size when a diagnostic is unavailable. Replacing
   */
  /*  missing values by one before adjustment, then restoring them, does this.
   */
  end = p->size[0];
  trueCount = 0;
  for (i = 0; i < end; i++) {
    if (rtIsNaN(p_data[i])) {
      trueCount++;
    }
  }
  emxInit_int32_T(&r, 1);
  partialTrueCount = r->size[0];
  r->size[0] = trueCount;
  emxEnsureCapacity_int32_T(r, partialTrueCount);
  r1 = r->data;
  partialTrueCount = 0;
  for (i = 0; i < end; i++) {
    if (rtIsNaN(p_data[i])) {
      r1[partialTrueCount] = i;
      partialTrueCount++;
    }
  }
  end = r->size[0];
  for (i = 0; i < end; i++) {
    p_data[r1[i]] = 1.0;
  }
  emxInit_int32_T(&iidx, 1);
  b_sort(p, iidx);
  iidx_data = iidx->data;
  p_data = p->data;
  emxInit_real_T(&x, 1);
  trueCount = p->size[0];
  partialTrueCount = x->size[0];
  x->size[0] = p->size[0];
  emxEnsureCapacity_real_T(x, partialTrueCount);
  x_data = x->data;
  partialTrueCount = p->size[0] - 1;
  for (i = 0; i <= partialTrueCount; i++) {
    x_data[i] = ((double)p->size[0] - (double)i) * p_data[i];
  }
  useConstantDim(x, nonSingletonDim(x));
  x_data = x->data;
  partialTrueCount = adjusted->size[0];
  adjusted->size[0] = p->size[0];
  emxEnsureCapacity_real_T(adjusted, partialTrueCount);
  p_data = adjusted->data;
  for (i = 0; i < trueCount; i++) {
    p_data[i] = 0.0;
  }
  partialTrueCount = x->size[0];
  for (i = 0; i < partialTrueCount; i++) {
    double varargin_2;
    varargin_2 = x_data[i];
    p_data[iidx_data[i] - 1] = fmin(1.0, varargin_2);
  }
  emxFree_real_T(&x);
  emxFree_int32_T(&iidx);
  for (i = 0; i < end; i++) {
    p_data[r1[i]] = rtNaN;
  }
  emxFree_int32_T(&r);
}

void normality_core(const emxArray_real_T *X, emxArray_real_T *ResultsMat,
                    emxArray_real_T *status)
{
  static const double b_p[6] = {-2.706056, 4.434685, -2.07119,
                                -0.147981, 0.221157, 0.0};
  static const double c_p[6] = {-3.582633, 5.682633, -1.752461,
                                -0.293762, 0.042981, 0.0};
  emxArray_boolean_T *r;
  emxArray_real_T b_scores_data;
  emxArray_real_T *sample;
  emxArray_real_T *x;
  emxArray_real_T *y;
  double scores_data[5002];
  double lower_data[2500];
  double tmp_data[2500];
  const double *X_data;
  double transformed;
  double *ResultsMat_data;
  double *sample_data;
  double *status_data;
  double *x_data;
  double *y_data;
  int32_t b_loop_ub;
  int32_t d_loop_ub;
  int32_t j;
  int32_t k;
  int32_t loop_ub;
  int32_t scores_size;
  boolean_T *r1;
  X_data = X->data;
  /* NORMALITY_CORE Authoritative marginal predictor normality diagnostics. */
  /*    X is an N-by-P double matrix from the original model analysis sample. */
  /*    ResultsMat is P-by-12. Columns 1:9 retain the original moment
   * diagnostics: */
  /*      skewness, excess kurtosis, skewness z/p, kurtosis z, omnibus K2/p, */
  /*      skewness Holm p, and omnibus Holm p. */
  /*    Columns 10:12 are Shapiro-Wilk W, p, and Holm p. */
  /*    STATUS is P-by-2: column 1 describes moments, column 2 Shapiro-Wilk. */
  /*    Each code is 0 available, 1 sample size outside that method's range, */
  /*    or 2 numerical unavailable. Moments require N>20; Shapiro-Wilk N=3:5000.
   */
  /*    Unavailable values are NaN only within the affected diagnostic family.
   */
  /*    Every diagnostic uses the same complete fitted-model sample. No rows */
  /*    are removed and no model is refitted or selected. Internal centering and
   */
  /*    scaling do not replace the fitted model's variables. No RNG is used. */
  /*    This mathematical source stays in the private development repository; */
  /*    both installed frontends use its regenerated C entrypoint. */
  /*    Copyright (C) 2026 Gyeongcheol Cho. CC BY-NC-SA 4.0; see LICENSE. */
  /*  */
  /*    External-package validation (November 17, 2026) */
  /*    The same 21-participant, three-predictor Manini illustration is compared
   */
  /*    with installed R reference implementations: moments 0.14.1 skewness(),
   */
  /*    kurtosis(), agostino.test(), and anscombe.test(); fBasics 4052.98 */
  /*    dagoTest(); and stats 4.5.1 shapiro.test() and p.adjust(method='holm').
   */
  /*    All 12 reported diagnostics agree within an absolute tolerance of 1e-12;
   */
  /*    the observed maximum absolute difference is 2.14e-14 (rounded upward).
   */
  /*    Additional synthetic/range checks and numerical-tail differences are */
  /*    documented separately in the development validation records. No source
   */
  /*    from these external R packages is incorporated into this engine. */
  /*  */
  /*    References */
  /*    Anscombe, F. J., & Glynn, W. J. (1983). Distribution of the kurtosis */
  /*        statistic b2 for normal samples. Biometrika, 70(1), 227–234. */
  /*        https://doi.org/10.1093/biomet/70.1.227 */
  /*  */
  /*    D'Agostino, R. B., Belanger, A., & D'Agostino, R. B., Jr. (1990). */
  /*        A suggestion for using powerful and informative tests of normality.
   */
  /*        The American Statistician, 44(4), 316–321. */
  /*        https://doi.org/10.1080/00031305.1990.10475751 */
  /*  */
  /*    Holm, S. (1979). A simple sequentially rejective multiple test */
  /*        procedure. Scandinavian Journal of Statistics, 6(2), 65–70. */
  /*        https://www.jstor.org/stable/4615733 */
  /*  */
  /*    Royston, P. (1992). Approximating the Shapiro-Wilk W-test for */
  /*        non-normality. Statistics and Computing, 2(3), 117–119. */
  /*        https://doi.org/10.1007/BF01891203 */
  /*  */
  /*    Royston, P. (1995). Remark AS R94: A remark on Algorithm AS 181: */
  /*        The W-test for normality. Applied Statistics, 44(4), 547–551. */
  /*        https://doi.org/10.2307/2986146 */
  /*  1. Allocate outputs and record each method's sample-size eligibility */
  loop_ub = X->size[1];
  b_loop_ub = ResultsMat->size[0] * ResultsMat->size[1];
  ResultsMat->size[0] = X->size[1];
  ResultsMat->size[1] = 12;
  emxEnsureCapacity_real_T(ResultsMat, b_loop_ub);
  ResultsMat_data = ResultsMat->data;
  b_loop_ub = X->size[1] * 12;
  for (k = 0; k < b_loop_ub; k++) {
    ResultsMat_data[k] = rtNaN;
  }
  b_loop_ub = status->size[0] * status->size[1];
  status->size[0] = X->size[1];
  status->size[1] = 2;
  emxEnsureCapacity_real_T(status, b_loop_ub);
  status_data = status->data;
  b_loop_ub = X->size[1] << 1;
  for (k = 0; k < b_loop_ub; k++) {
    status_data[k] = 2.0;
  }
  /*  Eligible methods start as numerical-unavailable. */
  if (X->size[0] <= 20) {
    for (k = 0; k < loop_ub; k++) {
      status_data[k] = 1.0;
    }
  }
  if ((X->size[0] < 3) || (X->size[0] > 5000)) {
    for (k = 0; k < loop_ub; k++) {
      status_data[k + status->size[0]] = 1.0;
    }
  }
  /*  2. Calculate the two diagnostic groups independently for every predictor
   */
  /*  A failed moment calculation need not invalidate Shapiro-Wilk, or vice
   * versa. */
  /*  Store the unchanged moment statistics first, followed by Shapiro-Wilk W/p.
   */
  emxInit_real_T(&x, 1);
  emxInit_real_T(&sample, 1);
  emxInit_real_T(&y, 1);
  emxInit_boolean_T(&r);
  for (j = 0; j < loop_ub; j++) {
    double energy;
    double location;
    double one_minus_W;
    double p;
    double z_skew;
    int32_t c_loop_ub;
    if (status_data[j] != 1.0) {
      c_loop_ub = X->size[0];
      b_loop_ub = x->size[0];
      x->size[0] = X->size[0];
      emxEnsureCapacity_real_T(x, b_loop_ub);
      x_data = x->data;
      for (k = 0; k < c_loop_ub; k++) {
        x_data[k] = X_data[k + X->size[0] * j];
      }
      /*  Moment-test transformations from D'Agostino et al. (1990) and Anscombe
       * and */
      /*  Glynn (1983); full references are above. Normal/chi-square
       * approximations */
      /*  require n>20. */
      if (X->size[0] > 20) {
        b_loop_ub = r->size[0];
        r->size[0] = X->size[0];
        emxEnsureCapacity_boolean_T(r, b_loop_ub);
        r1 = r->data;
        for (k = 0; k < c_loop_ub; k++) {
          energy = X_data[k + X->size[0] * j];
          r1[k] = (!rtIsInf(energy) && !rtIsNaN(energy));
        }
        if (all(r) && (vvarstd(x, X->size[0]) > 0.0)) {
          double g1;
          energy = blockedSummation(x, X->size[0]) / (double)X->size[0];
          b_loop_ub = x->size[0];
          x->size[0] = X->size[0];
          emxEnsureCapacity_real_T(x, b_loop_ub);
          x_data = x->data;
          for (k = 0; k < c_loop_ub; k++) {
            x_data[k] = X_data[k + X->size[0] * j] - energy;
          }
          b_loop_ub = y->size[0];
          y->size[0] = X->size[0];
          emxEnsureCapacity_real_T(y, b_loop_ub);
          y_data = y->data;
          for (k = 0; k < c_loop_ub; k++) {
            energy = x_data[k];
            y_data[k] = energy * energy;
          }
          location = blockedSummation(y, y->size[0]) / (double)y->size[0];
          b_loop_ub = y->size[0];
          y->size[0] = X->size[0];
          emxEnsureCapacity_real_T(y, b_loop_ub);
          y_data = y->data;
          for (k = 0; k < c_loop_ub; k++) {
            energy = x_data[k];
            y_data[k] = rt_powd_snf(energy, 3.0);
          }
          g1 = blockedSummation(y, y->size[0]) / (double)y->size[0] /
               rt_powd_snf(location, 1.5);
          b_loop_ub = y->size[0];
          y->size[0] = X->size[0];
          emxEnsureCapacity_real_T(y, b_loop_ub);
          y_data = y->data;
          for (k = 0; k < c_loop_ub; k++) {
            energy = x_data[k];
            y_data[k] = rt_powd_snf(energy, 4.0);
          }
          p = blockedSummation(y, y->size[0]) / (double)y->size[0] /
              (location * location);
          location = (double)X->size[0] * (double)X->size[0];
          energy = sqrt(2.0 *
                        (3.0 * ((location + 27.0 * (double)X->size[0]) - 70.0) *
                             ((double)X->size[0] + 1.0) *
                             ((double)X->size[0] + 3.0) /
                             (((double)X->size[0] - 2.0) *
                              ((double)X->size[0] + 5.0) *
                              ((double)X->size[0] + 7.0) *
                              ((double)X->size[0] + 9.0)) -
                         1.0)) -
                   1.0;
          transformed =
              g1 *
              sqrt(((double)X->size[0] + 1.0) * ((double)X->size[0] + 3.0) /
                   (6.0 * ((double)X->size[0] - 2.0))) /
              sqrt(2.0 / (energy - 1.0));
          b_asinh(&transformed);
          z_skew = transformed / sqrt(0.5 * log(energy));
          energy = 6.0 * ((location - 5.0 * (double)X->size[0]) + 2.0) /
                   (((double)X->size[0] + 7.0) * ((double)X->size[0] + 9.0)) *
                   sqrt(6.0 * ((double)X->size[0] + 3.0) *
                        ((double)X->size[0] + 5.0) /
                        ((double)X->size[0] * ((double)X->size[0] - 2.0) *
                         ((double)X->size[0] - 3.0)));
          energy = 8.0 / energy *
                       (2.0 / energy + sqrt(4.0 / (energy * energy) + 1.0)) +
                   6.0;
          location =
              (p -
               3.0 * ((double)X->size[0] - 1.0) / ((double)X->size[0] + 1.0)) /
                  sqrt(
                      24.0 * (double)X->size[0] * ((double)X->size[0] - 2.0) *
                      ((double)X->size[0] - 3.0) /
                      (((double)X->size[0] + 1.0) * ((double)X->size[0] + 1.0) *
                       ((double)X->size[0] + 3.0) *
                       ((double)X->size[0] + 5.0))) *
                  sqrt(2.0 / (energy - 4.0)) +
              1.0;
          if (!(location == 0.0) &&
              (!rtIsInf(location) && !rtIsNaN(location))) {
            double computed[7];
            boolean_T bv[7];
            transformed = 2.0 / (9.0 * energy);
            if (rtIsNaN(location)) {
              one_minus_W = rtNaN;
            } else if (location < 0.0) {
              one_minus_W = -1.0;
            } else {
              one_minus_W = (location > 0.0);
            }
            energy = ((1.0 - transformed) -
                      one_minus_W *
                          rt_powd_snf((1.0 - 2.0 / energy) / fabs(location),
                                      0.3333333333333333)) /
                     sqrt(transformed);
            location = z_skew * z_skew + energy * energy;
            transformed = eml_erfcore(fabs(z_skew) / 1.4142135623730951);
            computed[0] = g1;
            computed[1] = p - 3.0;
            computed[2] = z_skew;
            computed[3] = transformed;
            computed[4] = energy;
            computed[5] = location;
            energy = exp(-location / 2.0);
            computed[6] = energy;
            for (k = 0; k < 7; k++) {
              location = computed[k];
              bv[k] = (!rtIsInf(location) && !rtIsNaN(location));
            }
            if (b_all(bv) && (transformed >= 0.0) && (transformed <= 1.0) &&
                (energy >= 0.0)) {
              double statistics[7];
              for (k = 0; k < 7; k++) {
                statistics[k] = computed[k];
              }
              for (k = 0; k < 7; k++) {
                ResultsMat_data[j + ResultsMat->size[0] * k] = statistics[k];
              }
              status_data[j] = 0.0;
            }
          }
        }
      }
    }
    if (status_data[j + status->size[0]] != 1.0) {
      boolean_T available;
      /*  Author-written implementation of Royston's (1992, 1995) published */
      /*  Shapiro-Wilk method; full references are above. */
      /*  This uses symmetric normal scores and vector algebra; no R/GPL source
       * is */
      /*  copied or called. The p-value is exact at N=3 and approximate
       * otherwise, */
      /*  with separate N=4:11 and N>=12 transformations as in
       * stats::shapiro.test. */
      /*  X already comes from the complete fitted sample. Nonfinite/constant
       * input */
      /*  is unavailable; this function never drops rows or changes the sample.
       */
      z_skew = rtNaN;
      p = rtNaN;
      available = false;
      c_loop_ub = X->size[0];
      if ((X->size[0] >= 3) && (X->size[0] <= 5000)) {
        b_loop_ub = r->size[0];
        r->size[0] = X->size[0];
        emxEnsureCapacity_boolean_T(r, b_loop_ub);
        r1 = r->data;
        for (k = 0; k < c_loop_ub; k++) {
          energy = X_data[k + X->size[0] * j];
          r1[k] = (!rtIsInf(energy) && !rtIsNaN(energy));
        }
        if (all(r)) {
          b_loop_ub = sample->size[0];
          sample->size[0] = X->size[0];
          emxEnsureCapacity_real_T(sample, b_loop_ub);
          sample_data = sample->data;
          for (k = 0; k < c_loop_ub; k++) {
            sample_data[k] = X_data[k + X->size[0] * j];
          }
          sort(sample);
          sample_data = sample->data;
          if (!(sample_data[0] == sample_data[sample->size[0] - 1])) {
            /*  Normal order-score approximations determine the interior
             * weights. Correct */
            /*  the outermost pair for N=4,5 and the two outermost pairs for
             * N>=6, then */
            /*  scale the interior to leave the total squared weight equal to
             * one. */
            if (X->size[0] == 3) {
              scores_size = 3;
              scores_data[0] = -0.7071067811865476;
              scores_data[1] = 0.0;
              scores_data[2] = 0.7071067811865476;
            } else {
              double unit_scores_data[5002];
              int32_t interior_data[4998];
              int32_t b;
              int32_t e_loop_ub;
              b_loop_ub = (int32_t)floor((double)X->size[0] / 2.0);
              c_loop_ub = b_loop_ub - 1;
              for (k = 0; k <= c_loop_ub; k++) {
                tmp_data[k] =
                    (((double)k + 1.0) - 0.375) / ((double)X->size[0] + 0.25);
              }
              d_loop_ub = norminv(tmp_data, b_loop_ub, lower_data);
              b_loop_ub = (int32_t)fmod(X->size[0], 2.0);
              memcpy(&tmp_data[0], &lower_data[0],
                     (uint32_t)d_loop_ub * sizeof(double));
              memcpy(&scores_data[0], &lower_data[0],
                     (uint32_t)d_loop_ub * sizeof(double));
              flipud(tmp_data, &d_loop_ub);
              e_loop_ub = (d_loop_ub + b_loop_ub) + d_loop_ub;
              scores_size = e_loop_ub;
              if (b_loop_ub - 1 >= 0) {
                memset(&scores_data[d_loop_ub], 0,
                       (uint32_t)b_loop_ub * sizeof(double));
              }
              for (k = 0; k < d_loop_ub; k++) {
                scores_data[(k + d_loop_ub) + b_loop_ub] = -tmp_data[k];
              }
              b_scores_data.data = &scores_data[0];
              b_scores_data.size = &scores_size;
              b_scores_data.allocatedSize = 5002;
              b_scores_data.numDimensions = 1;
              b_scores_data.canFreeData = false;
              energy = xnrm2(scores_size, &b_scores_data);
              for (k = 0; k < e_loop_ub; k++) {
                unit_scores_data[k] = scores_data[k] / energy;
              }
              location = 1.0 / sqrt(X->size[0]);
              energy = -2.706056;
              for (k = 0; k < 5; k++) {
                energy = location * energy + b_p[k + 1];
              }
              energy += unit_scores_data[e_loop_ub - 1];
              d_loop_ub = 1;
              tmp_data[0] = energy;
              if (X->size[0] >= 6) {
                transformed = -3.582633;
                for (k = 0; k < 5; k++) {
                  transformed = location * transformed + c_p[k + 1];
                }
                d_loop_ub = 2;
                tmp_data[0] = energy;
                tmp_data[1] = unit_scores_data[e_loop_ub - 2] + transformed;
              }
              b = X->size[0] - d_loop_ub;
              if (b < d_loop_ub + 1) {
                c_loop_ub = 0;
              } else {
                c_loop_ub = b - d_loop_ub;
                b_loop_ub = c_loop_ub - 1;
                for (k = 0; k <= b_loop_ub; k++) {
                  interior_data[k] = (d_loop_ub + k) + 1;
                }
              }
              b_loop_ub = y->size[0];
              y->size[0] = c_loop_ub;
              emxEnsureCapacity_real_T(y, b_loop_ub);
              y_data = y->data;
              for (k = 0; k < c_loop_ub; k++) {
                energy = scores_data[interior_data[k] - 1];
                y_data[k] = energy * energy;
              }
              b_loop_ub = x->size[0];
              x->size[0] = d_loop_ub;
              emxEnsureCapacity_real_T(x, b_loop_ub);
              x_data = x->data;
              for (k = 0; k < d_loop_ub; k++) {
                energy = tmp_data[k];
                x_data[k] = energy * energy;
              }
              energy = sqrt(blockedSummation(y, y->size[0]) /
                            (1.0 - 2.0 * blockedSummation(x, x->size[0])));
              for (k = 0; k < e_loop_ub; k++) {
                scores_data[k] /= energy;
              }
              for (k = 0; k < d_loop_ub; k++) {
                scores_data[k] = -tmp_data[k];
              }
              if (b + 1 > X->size[0]) {
                b = 0;
                b_loop_ub = 0;
              } else {
                b_loop_ub = X->size[0];
              }
              flipud(tmp_data, &d_loop_ub);
              b_loop_ub -= b;
              for (k = 0; k < b_loop_ub; k++) {
                scores_data[b + k] = tmp_data[k];
              }
            }
            b_scores_data.data = &scores_data[0];
            b_scores_data.size = &scores_size;
            b_scores_data.allocatedSize = 5002;
            b_scores_data.numDimensions = 1;
            b_scores_data.canFreeData = false;
            energy = xnrm2(scores_size, &b_scores_data);
            c_loop_ub = scores_size;
            for (k = 0; k < c_loop_ub; k++) {
              scores_data[k] /= energy;
            }
            /*  W is the squared correlation with the unit-norm weights.
             * Evaluate 1-W */
            /*  using residual energy to avoid subtracting a near-one statistic
             * from one: */
            /*  1-W = ||z-a(a'z)||^2/||z||^2. Rescaling/centering leaves this
             * ratio unchanged. */
            b_abs(sample, x);
            energy = maximum(x);
            d_loop_ub = sample->size[0];
            for (k = 0; k < d_loop_ub; k++) {
              sample_data[k] /= energy;
            }
            energy = blockedSummation(sample, sample->size[0]) /
                     (double)sample->size[0];
            for (k = 0; k < d_loop_ub; k++) {
              sample_data[k] -= energy;
            }
            b_loop_ub = y->size[0];
            y->size[0] = sample->size[0];
            emxEnsureCapacity_real_T(y, b_loop_ub);
            y_data = y->data;
            for (k = 0; k < d_loop_ub; k++) {
              energy = sample_data[k];
              y_data[k] = energy * energy;
            }
            energy = blockedSummation(y, y->size[0]);
            if (!rtIsInf(energy) && !rtIsNaN(energy) && !(energy <= 0.0)) {
              location = 0.0;
              for (k = 0; k < c_loop_ub; k++) {
                location += scores_data[k] * sample_data[k];
              }
              if (sample->size[0] == scores_size) {
                b_loop_ub = y->size[0];
                y->size[0] = sample->size[0];
                emxEnsureCapacity_real_T(y, b_loop_ub);
                y_data = y->data;
                for (k = 0; k < d_loop_ub; k++) {
                  transformed = sample_data[k] - scores_data[k] * location;
                  y_data[k] = transformed * transformed;
                }
              } else {
                binary_expand_op_1(y, sample, scores_data, &scores_size,
                                   location);
              }
              one_minus_W = blockedSummation(y, y->size[0]) / energy;
              if (!rtIsInf(one_minus_W) && !rtIsNaN(one_minus_W)) {
                boolean_T guard1;
                boolean_T guard2;
                one_minus_W = fmin(1.0, fmax(0.0, one_minus_W));
                /*  Transform log(1-W) and evaluate the upper normal tail
                 * directly with erfc. */
                /*  The published polynomial constants below use descending
                 * power order. */
                guard1 = false;
                guard2 = false;
                if (X->size[0] == 3) {
                  p = fmin(1.0, fmax(0.0, 1.909859317102744 *
                                              (asin(sqrt(1.0 - one_minus_W)) -
                                               1.0471975511965976)));
                  guard1 = true;
                } else if (one_minus_W == 0.0) {
                  p = 1.0;
                  guard1 = true;
                } else {
                  transformed = log(one_minus_W);
                  if (X->size[0] <= 11) {
                    energy = 0.459 * (double)X->size[0] - 2.273;
                    if (transformed >= energy) {
                      /*  Lower-tail guard in the AS R94 approximation. */
                      z_skew = 1.0 - one_minus_W;
                      p = 1.0E-19;
                      available = true;
                    } else {
                      transformed = -log(energy - transformed);
                      location = (double)X->size[0] *
                                     ((double)X->size[0] *
                                          ((double)X->size[0] * -0.0006714 +
                                           0.025054) -
                                      0.39978) +
                                 0.544;
                      energy = exp((double)X->size[0] *
                                       ((double)X->size[0] *
                                            ((double)X->size[0] * -0.0020322 +
                                             0.062767) -
                                        0.77857) +
                                   1.3822);
                      guard2 = true;
                    }
                  } else {
                    energy = log(X->size[0]);
                    location =
                        energy * (energy * (energy * 0.0038915 - 0.083751) -
                                  0.31082) -
                        1.5861;
                    energy =
                        exp(energy * (energy * 0.0030302 - 0.082676) - 0.4803);
                    guard2 = true;
                  }
                }
                if (guard2) {
                  p = fmin(1.0,
                           fmax(0.0, 0.5 * eml_erfcore(
                                               (transformed - location) /
                                               (1.4142135623730951 * energy))));
                  guard1 = true;
                }
                if (guard1) {
                  z_skew = 1.0 - one_minus_W;
                  available = true;
                }
              }
            }
          }
        }
      }
      if (available) {
        ResultsMat_data[j + ResultsMat->size[0] * 9] = z_skew;
        ResultsMat_data[j + ResultsMat->size[0] * 10] = p;
        status_data[j + status->size[0]] = 0.0;
      }
    }
  }
  emxFree_boolean_T(&r);
  emxFree_real_T(&sample);
  /*  3. Adjust three distinct p-value families across the planned P predictors
   */
  /*  Unavailable predictors stay in each planned family. The holm helper uses
   */
  /*  one for their adjustment calculation, then restores the unavailable NaNs.
   */
  b_loop_ub = y->size[0];
  y->size[0] = X->size[1];
  emxEnsureCapacity_real_T(y, b_loop_ub);
  y_data = y->data;
  for (k = 0; k < loop_ub; k++) {
    y_data[k] = ResultsMat_data[k + ResultsMat->size[0] * 3];
  }
  holm(y, x);
  x_data = x->data;
  for (k = 0; k < loop_ub; k++) {
    ResultsMat_data[k + ResultsMat->size[0] * 7] = x_data[k];
  }
  b_loop_ub = y->size[0];
  y->size[0] = X->size[1];
  emxEnsureCapacity_real_T(y, b_loop_ub);
  y_data = y->data;
  for (k = 0; k < loop_ub; k++) {
    y_data[k] = ResultsMat_data[k + ResultsMat->size[0] * 6];
  }
  holm(y, x);
  x_data = x->data;
  for (k = 0; k < loop_ub; k++) {
    ResultsMat_data[k + ResultsMat->size[0] * 8] = x_data[k];
  }
  b_loop_ub = y->size[0];
  y->size[0] = X->size[1];
  emxEnsureCapacity_real_T(y, b_loop_ub);
  y_data = y->data;
  for (k = 0; k < loop_ub; k++) {
    y_data[k] = ResultsMat_data[k + ResultsMat->size[0] * 10];
  }
  holm(y, x);
  x_data = x->data;
  emxFree_real_T(&y);
  for (k = 0; k < loop_ub; k++) {
    ResultsMat_data[k + ResultsMat->size[0] * 11] = x_data[k];
  }
  emxFree_real_T(&x);
}

/* End of code generation (normality_core.c) */
