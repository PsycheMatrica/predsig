/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * mldivide.c
 *
 * Code generation for function 'mldivide'
 *
 */

/* Include files */
#include "mldivide.h"
#include "main_core_emxutil.h"
#include "main_core_types.h"
#include "qrsolve.h"
#include "rt_nonfinite.h"
#include <math.h>

/* Function Definitions */
void mldivide(const emxArray_real_T *A, emxArray_real_T *B)
{
  emxArray_int32_T *ipiv;
  emxArray_real_T *b_B;
  const double *A_data;
  double *B_data;
  double *b_B_data;
  int32_t ijA;
  int32_t j;
  int32_t k;
  int32_t *ipiv_data;
  B_data = B->data;
  A_data = A->data;
  if (A->size[1] == 0) {
    B->size[0] = 0;
  } else {
    emxInit_real_T(&b_B, 2);
    if (A->size[0] == A->size[1]) {
      double temp;
      int32_t LDA;
      int32_t LDB;
      int32_t i;
      int32_t jA;
      int32_t n;
      int32_t nrhs;
      int32_t temp_tmp;
      int32_t yk;
      yk = A->size[0];
      n = A->size[1];
      if (yk <= n) {
        n = yk;
      }
      yk = B->size[0];
      if (yk <= n) {
        n = yk;
      }
      nrhs = B->size[1];
      LDA = A->size[0];
      yk = b_B->size[0] * b_B->size[1];
      b_B->size[0] = A->size[0];
      b_B->size[1] = A->size[1];
      emxEnsureCapacity_real_T(b_B, yk);
      b_B_data = b_B->data;
      yk = A->size[0] * A->size[1];
      for (k = 0; k < yk; k++) {
        b_B_data[k] = A_data[k];
      }
      emxInit_int32_T(&ipiv, 2);
      yk = ipiv->size[0] * ipiv->size[1];
      ipiv->size[0] = 1;
      ipiv->size[1] = n;
      emxEnsureCapacity_int32_T(ipiv, yk);
      ipiv_data = ipiv->data;
      ipiv_data[0] = 1;
      yk = 1;
      for (k = 2; k <= n; k++) {
        yk++;
        ipiv_data[k - 1] = yk;
      }
      LDB = n - 1;
      if (LDB > n) {
        LDB = n;
      }
      for (j = 0; j < LDB; j++) {
        int32_t b;
        int32_t mmj;
        mmj = n - j;
        b = j * (LDA + 1);
        if (mmj - 1 < 0) {
          yk = -1;
        } else {
          yk = 0;
          if (mmj - 1 > 0) {
            temp = fabs(b_B_data[b]);
            for (k = 2; k <= mmj; k++) {
              double s;
              s = fabs(b_B_data[(b + k) - 1]);
              if (s > temp) {
                yk = k - 1;
                temp = s;
              }
            }
          }
        }
        if (b_B_data[b + yk] != 0.0) {
          if (yk != 0) {
            jA = j + yk;
            ipiv_data[j] = jA + 1;
            for (k = 0; k < n; k++) {
              yk = k * LDA;
              temp_tmp = j + yk;
              temp = b_B_data[temp_tmp];
              yk += jA;
              b_B_data[temp_tmp] = b_B_data[yk];
              b_B_data[yk] = temp;
            }
          }
          yk = b + mmj;
          for (k = b + 2; k <= yk; k++) {
            b_B_data[k - 1] /= b_B_data[b];
          }
        }
        yk = b + LDA;
        jA = yk;
        for (k = 0; k <= mmj - 2; k++) {
          temp = b_B_data[yk + k * LDA];
          if (temp != 0.0) {
            i = mmj + jA;
            for (ijA = jA + 2; ijA <= i; ijA++) {
              b_B_data[ijA - 1] += b_B_data[((b + ijA) - jA) - 1] * -temp;
            }
          }
          jA += LDA;
        }
      }
      LDB = B->size[0];
      for (k = 0; k <= n - 2; k++) {
        yk = ipiv_data[k];
        if (yk != k + 1) {
          for (ijA = 0; ijA < nrhs; ijA++) {
            temp = B_data[k + B->size[0] * ijA];
            B_data[k + B->size[0] * ijA] = B_data[(yk + B->size[0] * ijA) - 1];
            B_data[(yk + B->size[0] * ijA) - 1] = temp;
          }
        }
      }
      emxFree_int32_T(&ipiv);
      for (k = 0; k < nrhs; k++) {
        yk = LDB * k;
        for (ijA = 0; ijA < n; ijA++) {
          jA = LDA * ijA;
          temp_tmp = ijA + yk;
          if (B_data[temp_tmp] != 0.0) {
            for (j = ijA + 2; j <= n; j++) {
              i = (j + yk) - 1;
              B_data[i] -= B_data[temp_tmp] * b_B_data[(j + jA) - 1];
            }
          }
        }
      }
      for (k = 0; k < nrhs; k++) {
        yk = LDB * k - 1;
        for (ijA = n; ijA >= 1; ijA--) {
          jA = LDA * (ijA - 1) - 1;
          temp_tmp = ijA + yk;
          temp = B_data[temp_tmp];
          if (temp != 0.0) {
            B_data[temp_tmp] = temp / b_B_data[ijA + jA];
            for (j = 0; j <= ijA - 2; j++) {
              i = (j + yk) + 1;
              B_data[i] -= B_data[temp_tmp] * b_B_data[(j + jA) + 1];
            }
          }
        }
      }
    } else {
      int32_t yk;
      yk = b_B->size[0] * b_B->size[1];
      b_B->size[0] = B->size[0];
      b_B->size[1] = B->size[1];
      emxEnsureCapacity_real_T(b_B, yk);
      b_B_data = b_B->data;
      yk = B->size[0] * B->size[1] - 1;
      for (k = 0; k <= yk; k++) {
        b_B_data[k] = B_data[k];
      }
      qrsolve(A, b_B, B);
    }
    emxFree_real_T(&b_B);
  }
}

/* End of code generation (mldivide.c) */
