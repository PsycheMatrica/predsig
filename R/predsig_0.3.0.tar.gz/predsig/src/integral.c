/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * integral.c
 *
 * Code generation for function 'integral'
 *
 */

/* Include files */
#include "integral.h"
#include "gampdf.h"
#include "integralCalc.h"
#include "main_core_emxutil.h"
#include "main_core_types.h"
#include "nctcdf.h"
#include "rt_nonfinite.h"
#include "rt_nonfinite.h"
#include <math.h>

/* Function Definitions */
double integral(double fun_workspace_observed, double fun_workspace_df,
                double a, double b, double nv_AbsTol, double nv_RelTol)
{
  static const double t0_HighWeights[15] = {
      0.02293532201052922, 0.06309209262997854, 0.1047900103222502,
      0.1406532597155259,  0.1690047266392679,  0.1903505780647854,
      0.2044329400752989,  0.2094821410847278,  0.2044329400752989,
      0.1903505780647854,  0.1690047266392679,  0.1406532597155259,
      0.1047900103222502,  0.06309209262997854, 0.02293532201052922};
  static const double t0_LowWeights[15] = {
      0.0, 0.1294849661688697, 0.0, 0.2797053914892767, 0.0, 0.3818300505051189,
      0.0, 0.4179591836734694, 0.0, 0.3818300505051189, 0.0, 0.2797053914892767,
      0.0, 0.1294849661688697, 0.0};
  static const double t0_Nodes[15] = {-0.9914553711208126, -0.9491079123427585,
                                      -0.8648644233597691, -0.7415311855993943,
                                      -0.5860872354676911, -0.4058451513773972,
                                      -0.2077849550078985, 0.0,
                                      0.2077849550078985,  0.4058451513773972,
                                      0.5860872354676911,  0.7415311855993943,
                                      0.8648644233597691,  0.9491079123427585,
                                      0.9914553711208126};
  emxArray_real_T *interval;
  double A;
  double B;
  double Q;
  double b_a;
  double *interval_data;
  int32_t MaxIntervalCount;
  int32_t j;
  int32_t nx;
  int8_t problemType;
  boolean_T guard1;
  boolean_T isinfA;
  boolean_T isinfB;
  boolean_T reversedir;
  MaxIntervalCount = 65536;
  emxInit_real_T(&interval, 2);
  nx = interval->size[0] * interval->size[1];
  interval->size[0] = 1;
  interval->size[1] = 2;
  emxEnsureCapacity_real_T(interval, nx);
  interval_data = interval->data;
  if (b < a) {
    A = b;
    B = a;
    reversedir = true;
  } else {
    A = a;
    B = b;
    reversedir = false;
  }
  interval_data[0] = A;
  interval_data[1] = B;
  isinfA = rtIsInf(A);
  isinfB = rtIsInf(B);
  if (A == B) {
    problemType = 0;
  } else if (isinfA || isinfB) {
    if (!isinfA && isinfB) {
      interval_data[0] = 0.0;
      interval_data[1] = 1.0;
      problemType = 2;
    } else if (isinfA && !isinfB) {
      interval_data[0] = -1.0;
      interval_data[1] = 0.0;
      problemType = 3;
    } else if (isinfA && isinfB) {
      interval_data[0] = -1.0;
      interval_data[1] = 1.0;
      problemType = 4;
    } else {
      problemType = 0;
    }
  } else {
    interval_data[0] = -1.0;
    interval_data[1] = 1.0;
    problemType = 1;
  }
  nx = interval->size[0] * interval->size[1];
  interval->size[0] = 1;
  interval->size[1] = 2;
  emxEnsureCapacity_real_T(interval, nx);
  interval_data = interval->data;
  guard1 = false;
  if (problemType == 0) {
    guard1 = true;
  } else {
    double pathlen;
    int32_t lidx;
    int32_t nt;
    nx = 2;
    pathlen = interval_data[1] - interval_data[0];
    if (pathlen > 0.0) {
      int32_t n_data;
      int32_t y;
      n_data = (int32_t)(ceil(pathlen * (10.0 / pathlen)) - 1.0);
      if (n_data <= 0) {
        y = 0;
      } else {
        y = n_data;
      }
      nt = y + 2;
      if (y >= 0) {
        lidx = y;
      } else {
        lidx = 0;
      }
      nx = interval->size[0] * interval->size[1];
      interval->size[1] = lidx + 2;
      emxEnsureCapacity_real_T(interval, nx);
      interval_data = interval->data;
      for (j = 0; j < lidx; j++) {
        interval_data[j + 2] = 0.0;
      }
      if (y + 2 > 2) {
        interval_data[y + 1] = interval_data[1];
        Q = (interval_data[1] - interval_data[0]) / (double)(n_data + 1);
        for (j = n_data; j >= 1; j--) {
          interval_data[(y + j) - n_data] = interval_data[0] + (double)j * Q;
        }
      }
      nx = y + 2;
    } else {
      nt = 2;
    }
    lidx = 0;
    for (j = 2; j <= nx; j++) {
      Q = interval_data[j - 1];
      if (fabs(Q - interval_data[lidx]) > 0.0) {
        lidx++;
        interval_data[lidx] = Q;
      } else {
        nt--;
      }
    }
    if (nt < 2) {
      Q = interval_data[0];
      b_a = interval_data[0];
      nx = interval->size[0] * interval->size[1];
      interval->size[0] = 1;
      interval->size[1] = 2;
      emxEnsureCapacity_real_T(interval, nx);
      interval_data = interval->data;
      interval_data[0] = Q;
      interval_data[1] = b_a;
      nt = 2;
    } else {
      nx = interval->size[0] * interval->size[1];
      interval->size[1] = nt;
      emxEnsureCapacity_real_T(interval, nx);
    }
    nx = (nt - 1) << 1;
    if (nx > 65536) {
      MaxIntervalCount = nx;
    }
    if (!(pathlen > 0.0)) {
      guard1 = true;
    } else {
      Q = scalarValuedIntegral(fun_workspace_observed, fun_workspace_df, A, B,
                               interval, nt, pathlen, problemType,
                               MaxIntervalCount, nv_AbsTol, nv_RelTol, t0_Nodes,
                               t0_LowWeights, t0_HighWeights, &Q, &isinfA);
    }
  }
  if (guard1) {
    Q = (a + b) / 2.0;
    if (!rtIsInf(a) && !rtIsNaN(a) && (!rtIsInf(b) && !rtIsNaN(b)) &&
        (rtIsInf(Q) || rtIsNaN(Q))) {
      Q = a / 2.0 + b / 2.0;
    }
    A = sqrt(Q / (fun_workspace_df - 1.0));
    b_a = (fun_workspace_df + 1.0) / 2.0;
    if ((b_a >= 0.0) && !rtIsNaN(Q)) {
      Q /= 2.0;
      if (Q == 0.0) {
        if (b_a < 1.0) {
          Q = rtInf;
        } else if (b_a > 1.0) {
          Q = 0.0;
        } else {
          Q = 0.5;
        }
      } else if ((Q < 0.0) || rtIsInf(Q) || rtIsInf(b_a)) {
        Q = 0.0;
      } else if (b_a < 1.0) {
        Q = f(Q, b_a) * exp(log(b_a) - log(Q)) / 2.0;
      } else {
        Q = f(Q, b_a - 1.0) / 2.0;
      }
    } else {
      Q = rtNaN;
    }
    Q = (b - a) * ((nctcdf(-fun_workspace_observed, fun_workspace_df, A) +
                    nctcdf(-fun_workspace_observed, fun_workspace_df, -A)) *
                   Q);
  }
  emxFree_real_T(&interval);
  if (reversedir) {
    Q = -Q;
  }
  return Q;
}

/* End of code generation (integral.c) */
