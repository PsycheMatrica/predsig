/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * normality_core.h
 *
 * Code generation for function 'normality_core'
 *
 */

#ifndef NORMALITY_CORE_H
#define NORMALITY_CORE_H

/* Include files */
#include "main_core_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void normality_core(const emxArray_real_T *X,
                           emxArray_real_T *ResultsMat,
                           emxArray_real_T *status);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (normality_core.h) */
