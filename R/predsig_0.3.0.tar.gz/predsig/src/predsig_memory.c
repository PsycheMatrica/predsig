/* Copyright (C) 2026 Gyeongcheol Cho. CC BY-NC-SA 4.0.
 * R-owned transient storage gives the generated engine an R error on OOM.
 * The bridge releases the arena after each completed scalar calculation.
 */
#include <R.h>
#include "predsig_memory.h"

void *predsig_native_alloc(size_t bytes)
{
    return (void *) R_alloc(bytes, 1);
}

void predsig_native_free(void *pointer)
{
    /* R_alloc storage is released together with its scalar-call arena, or
     * automatically when an R error unwinds the .Call invocation.
     */
    (void) pointer;
}
