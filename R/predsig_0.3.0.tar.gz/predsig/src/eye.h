/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * eye.h
 *
 * Code generation for function 'eye'
 *
 */

#ifndef EYE_H
#define EYE_H

/* Include files */
#include "main_core_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void eye(double varargin_1, emxArray_real_T *b_I);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (eye.h) */
