# Copyright (c) 2026 Gyeongcheol Cho. CC BY-NC-SA 4.0.
# Obtain the authors' official files and prepare the initial reaction-time model.
# Participant-level data are downloaded locally; none are bundled in predsig.

#' Download and prepare the Manini reaction-time illustration
#' @export
prepare_manini <- function(
  output_dir = "analysis_data",
  cache_dir = file.path(output_dir, "manini_sources"),
  overwrite = FALSE,
  quiet = FALSE
) {
  # 1. Validate the options and create the local output and cache directories.
  valid_path <- function(x) is.character(x) && length(x) == 1L && !is.na(x) && nzchar(x)
  if (!valid_path(output_dir) || !valid_path(cache_dir))
    stop("output_dir and cache_dir must be nonempty directory paths.", call. = FALSE)
  if (
    !is.logical(overwrite) || length(overwrite) != 1L || is.na(overwrite) ||
      !is.logical(quiet) || length(quiet) != 1L || is.na(quiet)
  )
    stop("overwrite and quiet must each be TRUE or FALSE.", call. = FALSE)
  for (directory in c(output_dir, cache_dir)) {
    dir.create(directory, recursive = TRUE, showWarnings = FALSE)
    if (!dir.exists(directory)) stop("Cannot create directory: ", directory, call. = FALSE)
  }
  # 2. Obtain and verify the three workbooks listed in the source manifest.
  manifest_path <- system.file(
    "reproduction", "manini_official_sources.csv",
    package = "predsig"
  )
  if (!nzchar(manifest_path)) stop("The installed source manifest is missing.", call. = FALSE)
  sources <- utils::read.csv(manifest_path, stringsAsFactors = FALSE, check.names = FALSE)
  for (i in seq_len(nrow(sources)))
    .manini_fetch(sources[i, ], cache_dir, quiet)

  # 3. Read the released columns used in the reaction-time analysis.
  left <- c("L_HG", "L_PT", "L_pSTC")
  right <- c("R_PT", "R_pSTC")
  contrasts <- as.vector(outer(c(left, right), c("_switch_HEF", "_stay_LEF"), paste0))
  roi <- .manini_sheet(
    cache_dir, "Temporal_ROIs_data.xlsx", "Switching",
    c("ID", "Group", contrasts)
  )
  behavior <- .manini_sheet(
    cache_dir, "BehaviouralData_4EFTasks.xlsx", "BehaviouralData_4EFTasks",
    c("ID", "RT_SwCost", "RT_Sw_HEF_Corr", "RT_Sw_LEF_Corr")
  )
  language <- .manini_sheet(
    cache_dir, "WASI-Corsi-Language.xlsx", "Sheet1",
    c("ID", "Language_score")
  )

  # 4. Match each deaf switching participant across the three workbooks.
  roi <- roi[!is.na(roi$Group) & tolower(trimws(roi$Group)) == "deaf", , drop = FALSE]
  if (nrow(roi) != 23L) stop("Expected 23 deaf participants in the Switching ROI sheet.", call. = FALSE)
  bi <- match(roi$ID, behavior$ID)
  li <- match(roi$ID, language$ID)
  if (anyNA(bi) || anyNA(li))
    stop("Every switching participant must match exactly one behavior and language ID.", call. = FALSE)
  behavior <- behavior[bi, , drop = FALSE]
  language <- language[li, , drop = FALSE]
  # 5. Verify the released outcome, compute the hemisphere averages, and
  # retain the 21 cases with a released language score.
  for (name in contrasts) roi[[name]] <- .manini_numeric(roi[[name]], name)
  for (name in c("RT_SwCost", "RT_Sw_HEF_Corr", "RT_Sw_LEF_Corr"))
    behavior[[name]] <- .manini_numeric(behavior[[name]], name)
  language$Language_score <- .manini_numeric(
    language$Language_score, "Language_score",
    allow_missing = TRUE
  )
  if (any(abs(
    behavior$RT_SwCost - (behavior$RT_Sw_HEF_Corr - behavior$RT_Sw_LEF_Corr)
  ) >= 1e-7))
    stop("The released RT_SwCost does not match correct-trial switch minus stay RT.", call. = FALSE)
  neural_mean <- function(regions) rowMeans(
    vapply(
      regions,
      function(region)
        roi[[paste0(region, "_switch_HEF")]] - roi[[paste0(region, "_stay_LEF")]],
      numeric(nrow(roi))
    )
  )
  prepared <- data.frame(
    RT_switch_cost = behavior$RT_SwCost,
    Language = language$Language_score,
    LH_neural_switch_cost = neural_mean(left),
    RH_neural_switch_cost = neural_mean(right)
  )
  included <- !is.na(prepared$Language)
  if (sum(included) != 21L || sum(!included) != 2L)
    stop("Expected exactly two missing released language scores and 21 complete cases.", call. = FALSE)
  manini <- prepared[included, , drop = FALSE]
  rownames(manini) <- NULL

  # 6. Save the analysis data and document how the sample was assembled.
  provenance <- list(
    study = "Manini et al. (2022)",
    article = "https://doi.org/10.1093/brain/awac205",
    osf = "https://osf.io/uh2ap/",
    source_files = sources,
    deaf_switching_cases = 23L,
    complete_case_N = 21L,
    missing_language_cases = 2L,
    additional_exclusions = 0L,
    imputation = FALSE,
    included_IDs = roi$ID[included],
    excluded_missing_language_IDs = roi$ID[!included],
    outcome = "Released RT_SwCost: correct-trial first-switch minus stay mean RT, in seconds",
    language = "Released Language_score, not recomputed",
    left_ROIs = left,
    right_ROIs = right,
    neural_contrast = "switch_HEF minus stay_LEF",
    preparation = "predsig::prepare_manini",
    package_version = "0.3.0",
    redistribution = "Downloaded sources and prepared participant data remain local"
  )
  data_file <- file.path(output_dir, "manini_initial_RT.RData")
  provenance_file <- file.path(output_dir, "manini_provenance.rds")
  # Check both destinations before changing either existing file.
  write_data <- .manini_output_needed(data_file, manini, overwrite, rdata = TRUE)
  write_provenance <- .manini_output_needed(provenance_file, provenance, overwrite)
  if (write_data) save(manini, file = data_file, version = 2)
  if (write_provenance) saveRDS(provenance, file = provenance_file, version = 2)
  if (!quiet)
    message(
      "Prepared 21 participants and 4 variables: ",
      normalizePath(data_file, winslash = "/", mustWork = TRUE)
    )
  manini
}

.manini_fetch <- function(source, cache_dir, quiet) {
  path <- file.path(cache_dir, source$filename)
  verify <- function(candidate) {
    identical(tolower(digest::digest(candidate, algo = "sha256", file = TRUE)), source$sha256) &&
      isTRUE(file.info(candidate)$size == source$bytes)
  }
  if (file.exists(path)) {
    if (!verify(path))
      stop("Cached source failed SHA-256/size verification: ", path,
           ". Preserve or remove it before retrying; it will not be overwritten.", call. = FALSE)
  } else {
    temporary <- tempfile("manini-download-", tmpdir = cache_dir, fileext = ".xlsx")
    on.exit(unlink(temporary), add = TRUE)
    old_timeout <- getOption("timeout")
    options(timeout = max(120, old_timeout))
    on.exit(options(timeout = old_timeout), add = TRUE)
    status <- tryCatch(
      utils::download.file(
        source$url, temporary,
        method = "libcurl", mode = "wb", quiet = quiet
      ),
      error = function(e) e
    )
    if (inherits(status, "error") || !identical(status, 0L))
      stop("Official download unavailable: ", source$url, ". Save the official ",
           source$filename, " to ", path, " and rerun; its hash will still be verified.",
           call. = FALSE)
    if (!verify(temporary))
      stop("Official source hash or size changed for ", source$filename,
           "; the unverified download was not cached.", call. = FALSE)
    if (!file.rename(temporary, path)) stop("Cannot save verified source: ", path, call. = FALSE)
  }
  if (!quiet) message("Verified official source: ", source$filename)
  invisible(path)
}

.manini_sheet <- function(folder, filename, sheet, columns) {
  data <- as.data.frame(
    readxl::read_excel(
      file.path(folder, filename),
      sheet = sheet, .name_repair = "minimal"
    ),
    check.names = FALSE
  )
  if (any(vapply(columns, function(name) sum(names(data) == name), integer(1)) != 1L))
    stop("Missing or duplicate required column in ", filename, " / ", sheet, ".", call. = FALSE)
  data <- data[, columns, drop = FALSE]
  missing_id <- is.na(data$ID)
  if (is.character(data$ID)) missing_id <- missing_id | !nzchar(trimws(data$ID))
  if (any(missing_id & rowSums(!is.na(data[setdiff(columns, "ID")])) > 0L))
    stop("A populated source row is missing its participant ID in ", filename, ".", call. = FALSE)
  data <- data[!missing_id, , drop = FALSE]
  data$ID <- .manini_numeric(data$ID, paste0(filename, ": ID"))
  if (any(data$ID != floor(data$ID)) || anyDuplicated(data$ID))
    stop("Participant IDs must be unique integers in ", filename, ".", call. = FALSE)
  data
}

.manini_numeric <- function(x, label, allow_missing = FALSE) {
  if (is.character(x)) {
    x[!nzchar(trimws(x))] <- NA_character_
    converted <- suppressWarnings(as.numeric(x))
    if (any(!is.na(x) & is.na(converted))) stop("Nonnumeric source value: ", label, call. = FALSE)
    x <- converted
  }
  if (!is.numeric(x) || any(!is.na(x) & !is.finite(x)) || (!allow_missing && anyNA(x)))
    stop("Unexpected missing or nonfinite source value: ", label, call. = FALSE)
  as.double(x)
}

.manini_output_needed <- function(path, expected, overwrite, rdata = FALSE) {
  if (!file.exists(path)) return(TRUE)
  existing <- tryCatch({
    if (!rdata) readRDS(path) else {
      container <- new.env(parent = emptyenv())
      names <- load(path, envir = container)
      if (!identical(names, "manini")) stop("Unexpected RData contents")
      container$manini
    }
  }, error = function(e) e)
  if (!inherits(existing, "error") && identical(existing, expected)) return(FALSE)
  if (!overwrite)
    stop("Existing output differs or cannot be read: ", path,
         ". Choose another output_dir or explicitly use overwrite = TRUE.", call. = FALSE)
  TRUE
}
