# Copyright (c) 2026 Gyeongcheol Cho
# SPDX-License-Identifier: CC-BY-NC-SA-4.0
# Public shell. Model preparation and numerical calculation live separately.

#' Predictive significance testing for an ordinary linear model
#' @export
run <- function(object = NULL, ...) {
  UseMethod("run")
}

#' @export
run.default <- function(
  object = NULL, y = NULL, X = NULL,
  t = NULL, sigma2_hat = NULL, N = NULL, P = NULL,
  alpha = .05, abs_tol = 2e-10, rel_tol = 2e-8, engine = "auto",
  check_normality = TRUE, ...
) {
  # 1. Identify the input supplied and validate shared options.
  if (length(list(...))) stop("Unused arguments supplied to predsig::run().", call. = FALSE)
  .predsig_validate_check_normality(check_normality)
  summary_supplied <- !is.null(t) || !is.null(sigma2_hat) || !is.null(N) || !is.null(P)
  raw_supplied <- !is.null(y) || !is.null(X)
  if (!is.null(object)) {
    if (!is.numeric(object) || !is.null(dim(object)))
      stop(
        "No predsig::run() method for class '", paste(class(object), collapse = "/"),
        "'. Supply an ordinary lm, a formula, raw y and X, or t/sigma2_hat/N/P.",
        call. = FALSE
      )
    if (!is.null(y)) stop("Supply the outcome as object or y, not both.", call. = FALSE)
    y <- object
    raw_supplied <- TRUE
  }
  if (summary_supplied && raw_supplied)
    stop("Use raw y/X or t/sigma2_hat/N/P summaries in one call, not both.", call. = FALSE)
  .predsig_validate_alpha(alpha)

  # 2. Pass the inputs to the matching model preparation function.
  if (summary_supplied)
    return(
      .predsig_from_summary(
        t, sigma2_hat, N, P,
        alpha, abs_tol, rel_tol, engine, check_normality
      )
    )
  if (raw_supplied)
    return(.predsig_from_raw(y, X, alpha, abs_tol, rel_tol, engine, check_normality))
  stop("Supply an ordinary lm, a formula, raw y and X, or t/sigma2_hat/N/P.", call. = FALSE)
}

#' @export
run.lm <- function(
  object,
  alpha = .05, abs_tol = 2e-10, rel_tol = 2e-8, engine = "auto",
  check_normality = TRUE, ...
) {
  .predsig_validate_check_normality(check_normality)
  if (!identical(class(object), "lm"))
    stop(
      "Only class 'lm' is implemented; glm, aov, mlm, and other lm subclasses are unsupported.",
      call. = FALSE
    )
  if (is.null(object$model) || !is.data.frame(object$model))
    stop("The fitted lm must retain its model frame; refit with model = TRUE.", call. = FALSE)
  if (length(list(...)))
    stop(
      "For an existing lm object, supply the fit alone (plus alpha, tolerances, engine, or check_normality).",
      call. = FALSE
    )
  .predsig_from_lm(
    object, alpha, abs_tol, rel_tol, engine,
    input_type = "lm",
    check_normality = check_normality
  )
}

#' @export
run.formula <- function(
  object, data = NULL, alpha = .05, na.action = stats::na.fail,
  abs_tol = 2e-10, rel_tol = 2e-8, engine = "auto",
  check_normality = TRUE, ...
) {
  .predsig_validate_check_normality(check_normality)
  fit <- stats::lm(formula = object, data = data, na.action = na.action, ...)
  .predsig_from_lm(
    fit, alpha, abs_tol, rel_tol, engine,
    input_type = "formula",
    check_normality = check_normality
  )
}

# Earlier entry-point names delegate to the same shell.
#' @export
predsig <- function(object = NULL, ...) run(object, ...)

#' @export
predictive_test <- function(object = NULL, ...) run(object, ...)

#' @export
predictive_pvalue <- function(
  object, data = NULL, alpha = .05, na.action = stats::na.fail, ...
) {
  if (inherits(object, "formula"))
    return(run(object, data = data, alpha = alpha, na.action = na.action, ...))
  if (!is.null(data))
    stop("Do not supply data with an existing fitted object.", call. = FALSE)
  if (!missing(na.action))
    stop(
      "An existing fit retains its own analysis sample; na.action is for formulas only.",
      call. = FALSE
    )
  run(object, alpha = alpha, ...)
}

#' @export
print.predsig_result <- function(x, digits = 6, ...) {
  cat("Predictive and coefficient significance for an ordinary linear model\n")
  cat(sprintf(
    "N = %d; P = %d; error df = %d; alpha = %.3f\n",
    x$N, x$P, x$df_error, x$alpha
  ))
  cat(sprintf("Input: %s; calculation: %s\n", x$input_type, x$backend$backend))
  if (identical(x$input_type, "summary"))
    cat("Coefficient estimates, SEs, standardized coefficients, and VIFs are unavailable from these summaries (NA).\n")
  print(.predsig_public_results(x), digits = digits, row.names = FALSE, ...)
  invisible(x)
}

#' @export
as.data.frame.predsig_result <- function(x, row.names = NULL, optional = FALSE, ...) {
  as.data.frame(.predsig_public_results(x), row.names = row.names, optional = optional, ...)
}
