# Copyright (c) 2026 Gyeongcheol Cho
# SPDX-License-Identifier: CC-BY-NC-SA-4.0
# Prepare ordinary linear models and format results; no predictive core here.
# Assumes a prespecified OLS model with an intercept, iid jointly normal
# continuous predictors, and independent Gaussian errors of constant variance.
# Requires residual degrees of freedom greater than 1.
#
# delEPE estimates predictive contribution; delta expresses it relative
# to the full model's expected prediction error.
# p_pred tests nonpositive predictive contribution;
# p_coef tests a zero regression coefficient.
# The public fields b_raw, sigma2, DeltaEPE_p, delta_p, EPE1 contain estimates.
# sigma2 estimates sigma_epsilon^2; df_error is manuscript df; alpha is alpha_0.
# In this wrapper, design includes the intercept; X contains predictors only.
# nu below is the fitted residual df, not the Wishart degrees of freedom.

.predsig_validate_alpha <- function(alpha) {
  if (
    !is.numeric(alpha) || is.complex(alpha) || length(alpha) != 1L ||
      !is.finite(alpha) || alpha <= 0 || alpha >= 1
  )
    stop("alpha must be one finite number strictly between 0 and 1.", call. = FALSE)
  invisible(NULL)
}

.predsig_from_lm <- function(
  fit, alpha, abs_tol, rel_tol, engine, input_type, check_normality = TRUE
) {
  # 1. Check the fitted model and retain its original analysis rows.
  .predsig_validate_alpha(alpha)
  .predsig_validate_check_normality(check_normality)
  if (!identical(class(fit), "lm"))
    stop("Only class 'lm' is implemented.", call. = FALSE)
  if (is.null(fit$model) || !is.data.frame(fit$model))
    stop("The fitted lm must retain its model frame; refit with model = TRUE.", call. = FALSE)
  if (!is.null(fit$weights))
    stop("Weighted fits are outside this method's scope.")
  if (!is.null(fit$offset))
    stop("Models with offsets are outside this method's scope.")
  term_info <- stats::terms(fit)
  if (attr(term_info, "intercept") != 1L)
    stop("The full model must include an intercept.")
  if (any(attr(term_info, "order") > 1L))
    stop("Interactions are outside this all-continuous additive-model method.")

  frame <- stats::model.frame(fit)
  y <- stats::model.response(frame)
  if (!is.numeric(y) || is.complex(y) || !is.null(dim(y)) || any(!is.finite(y)))
    stop("The model must have one finite numeric outcome vector.")
  predictor_frame <- frame[-attr(term_info, "response")]
  if (!length(predictor_frame))
    stop("At least one continuous predictor is required.")
  valid_numeric <- vapply(
    predictor_frame,
    function(z)
      is.numeric(z) && !is.complex(z) && is.null(dim(z)) && all(is.finite(z)),
    logical(1)
  )
  if (!all(valid_numeric))
    stop(
      "Use finite numeric-vector predictors; factors, logicals, and matrix terms are unsupported."
    )

  design <- stats::model.matrix(fit)
  N <- nrow(design)
  P <- ncol(design) - 1L
  if (P != length(predictor_frame))
    stop("Each predictor must correspond to one continuous design column.")
  X <- design[, -1L, drop = FALSE]
  if (any(apply(X, 2L, function(z) length(unique(z))) < 3L))
    stop("Each predictor needs at least three distinct values; binary predictors are unsupported.")
  if (fit$rank != ncol(design) || anyNA(stats::coef(fit)))
    stop("The full design must have full column rank; no coefficients may be aliased.")
  nu <- stats::df.residual(fit)
  if (N <= P + 2L || nu != N - P - 1L)
    stop("Require N > P + 2 for the finite-sample boundary and point estimator.")

  # 2. Read the supplied OLS estimates on the retained analysis rows.
  conventional <- stats::summary.lm(fit)
  full_coefficients <- stats::coef(conventional)
  coefficients <- full_coefficients[-1L, , drop = FALSE]
  sigma2 <- conventional$sigma^2
  estimate <- coefficients[, "Estimate"]
  se <- coefficients[, "Std. Error"]
  statistic <- coefficients[, "t value"]
  p_coef <- coefficients[, "Pr(>|t|)"]

  # 3. Check the design and compute the supplementary results. Run the same
  # predictive calculation as summary mode once the fitted-model checks pass.
  supplementary <- .predsig_supplementary_engine(
    y, X, full_coefficients[, "Estimate"], full_coefficients[, "Std. Error"],
    sigma2, engine
  )
  predictive <- .predsig_engine(
    statistic, sigma2, N, P, abs_tol, rel_tol, supplementary$backend
  )

  # 4. Attach labels, stored fit information, and optional normality diagnostics.
  results <- .predsig_result_table(
    predictor = rownames(coefficients), coefficient = estimate,
    standardized = supplementary$standardized_coefficient,
    se = se, statistic = statistic, p_coef = p_coef,
    calculated = predictive, alpha = alpha, VIF = supplementary$VIF
  )
  answer <- .predsig_result_object(
    results, N, P, sigma2, predictive, alpha, input_type, abs_tol, rel_tol,
    check_normality
  )
  answer$fit <- fit
  answer$intercept <- unname(full_coefficients[1L, "Estimate"])
  answer$predictor_residual_variance <- supplementary$predictor_residual_variance
  answer$variance_factor <- supplementary$variance_factor
  answer$residuals <- supplementary$residuals
  answer$fitted <- unname(fit$fitted.values)
  answer$leverage <- supplementary$leverage
  answer$VIF <- supplementary$VIF
  answer$analysis_row_names <- rownames(frame)
  answer$omitted_rows <- fit$na.action
  diagnostics <- .predsig_normality(
    X, alpha, predictive$backend$backend, enabled = check_normality
  )
  answer$normality <- diagnostics$table
  answer$normality_info <- diagnostics$info
  answer
}

.predsig_from_raw <- function(
  y, X, alpha, abs_tol, rel_tol, engine, check_normality = TRUE
) {
  if (is.null(y) || is.null(X))
    stop("Raw-data mode requires both y and X.", call. = FALSE)
  if (
    !is.numeric(y) || is.complex(y) || !is.null(dim(y)) ||
      !length(y) || any(!is.finite(y))
  )
    stop("y must be one finite numeric outcome vector.", call. = FALSE)
  if (is.data.frame(X)) {
    valid <- vapply(
      X,
      function(z)
        is.numeric(z) && !is.complex(z) && is.null(dim(z)) && all(is.finite(z)),
      logical(1)
    )
    if (!all(valid))
      stop("X must contain finite numeric-vector predictors.", call. = FALSE)
    X <- as.matrix(X)
  }
  if (is.numeric(X) && is.null(dim(X))) X <- matrix(X, ncol = 1L)
  if (
    !is.matrix(X) || !is.numeric(X) || is.complex(X) || !ncol(X) ||
      nrow(X) != length(y) || any(!is.finite(X))
  )
    stop("X must be a finite numeric predictor matrix with length(y) rows.", call. = FALSE)
  if (is.null(colnames(X))) colnames(X) <- paste0("x", seq_len(ncol(X)))
  model_data <- data.frame(.predsig_outcome = y, X, check.names = TRUE)
  fit <- stats::lm(.predsig_outcome ~ ., data = model_data, na.action = stats::na.fail)
  .predsig_from_lm(
    fit, alpha, abs_tol, rel_tol, engine, input_type = "raw",
    check_normality = check_normality
  )
}

.predsig_from_summary <- function(
  t, sigma2_hat, N, P, alpha, abs_tol, rel_tol, engine, check_normality = TRUE
) {
  .predsig_validate_check_normality(check_normality)
  if (is.null(t) || is.null(sigma2_hat) || is.null(N) || is.null(P))
    stop("Summary mode requires t, sigma2_hat, N, and P.", call. = FALSE)
  if (!is.numeric(t) || is.complex(t) || !is.null(dim(t)) || !length(t) || anyNA(t))
    stop("t must be a nonmissing real numeric vector.", call. = FALSE)
  if (
    !is.numeric(P) || is.complex(P) || length(P) != 1L || !is.finite(P) ||
      P < 1 || P != floor(P) || length(t) > P
  )
    stop("P must be a positive integer at least as large as length(t).", call. = FALSE)
  calculated <- .predsig_engine(t, sigma2_hat, N, P, abs_tol, rel_tol, engine)
  predictor <- names(t)
  if (is.null(predictor)) predictor <- paste0("t", seq_along(t))
  missing_labels <- is.na(predictor) | !nzchar(predictor)
  predictor[missing_labels] <- paste0("t", which(missing_labels))
  unavailable <- rep(NA_real_, length(t))
  results <- .predsig_result_table(
    predictor, unavailable, unavailable, unavailable,
    t, 2 * stats::pt(-abs(t), df = N - P - 1), calculated, alpha
  )
  .predsig_result_object(
    results, N, P, sigma2_hat, calculated, alpha, "summary", abs_tol, rel_tol,
    check_normality
  )
}

.predsig_result_table <- function(
  predictor, coefficient, standardized, se, statistic, p_coef, calculated,
  alpha, VIF = rep(NA_real_, length(statistic))
) {
  data.frame(
    Predictor = predictor,
    b_raw = unname(coefficient),
    SE_raw = unname(se),
    b_std = unname(standardized),
    t = unname(statistic),
    p_coef = unname(p_coef),
    sig_coef = unname(p_coef <= alpha),
    DeltaEPE_p = unname(calculated$delEPE),
    delta_p = unname(calculated$delta),
    p_pred = unname(calculated$p_pred),
    sig_pred = unname(calculated$p_pred <= alpha),
    VIF = unname(VIF),
    row.names = NULL, check.names = FALSE
  )
}

.predsig_public_results <- function(object) {
  results <- object$results
  if ("Predictor" %in% names(results)) return(results)

  # Earlier saved results used descriptive names. Map their stored values
  # to the current public schema when displaying or extracting the table.
  legacy <- c(
    "predictor", "coefficient", "standard_error", "standardized_coefficient",
    "t", "p_coef", "coefficient_significant", "delEPE", "delta", "p_pred",
    "predictively_significant"
  )
  results <- results[legacy]
  names(results) <- c(
    "Predictor", "b_raw", "SE_raw", "b_std", "t", "p_coef", "sig_coef",
    "DeltaEPE_p", "delta_p", "p_pred", "sig_pred"
  )
  results$VIF <- if (is.null(object$VIF)) rep(NA_real_, nrow(results)) else unname(object$VIF)
  results
}

.predsig_result_object <- function(
  results, N, P, sigma2, calculated, alpha, input_type, abs_tol, rel_tol,
  check_normality = TRUE
) {
  diagnostics <- .predsig_normality(
    NULL, alpha, calculated$backend$backend, familyP = P,
    enabled = check_normality
  )
  numerical <- data.frame(
    predictor = results$Predictor,
    absolute_integration_error = calculated$numerical$absolute_error,
    omitted_chisquare_probability_bound = calculated$numerical$tail_probability
  )
  answer <- list(
    fit = NULL, results = results, N = N, P = P, df_error = N - P - 1,
    alpha = alpha, sigma2 = sigma2, EPE1 = calculated$EPE1,
    intercept = NA_real_,
    analysis_row_names = NULL, omitted_rows = NULL,
    normality = diagnostics$table, normality_info = diagnostics$info,
    numerical_accuracy = numerical, backend = calculated$backend, input_type = input_type,
    integration = list(abs_tol = abs_tol, rel_tol = rel_tol),
    metadata = list(
      package = "predsig", package_version = "0.3.0",
      license = "CC BY-NC-SA 4.0",
      license_scope = "Author-controlled material only; generated native components retain separate terms in COPYRIGHTS.",
      author = "Gyeongcheol Cho",
      title = paste(
        "Predictive Significance Testing: A Complement to Coefficient",
        "Significance in Confirmatory Linear Regression"
      ),
      repository = "https://github.com/PsycheMatrica/predsig",
      preprint = NULL, preprint_status = "Not yet available",
      version_date = "2026-10-27",
      normalization = "delEPE / expected original full-model EPE1; training/test averaged under Gaussian random design",
      normalization_baseline = "EPE1",
      runtime = list(
        R_version = R.version.string,
        R_citation = format(utils::citation(), style = "text"),
        R_bibtex = as.character(utils::toBibtex(utils::citation()))
      ),
      exact_reference = "iid multivariate-normal continuous random design and independent homoskedastic Gaussian errors"
    )
  )
  class(answer) <- c("predsig_result", "predictive_pvalue")
  answer
}
