# Copyright (C) 2026 Gyeongcheol Cho. CC BY-NC-SA 4.0.
# Dispatch the supplementary model and predictive calculations.
# Model fitting remains in model-lm.R. Numerical formulas stay in the engines.

.predsig_supplementary_engine <- function(
  y, X, b, se, sigma2_hat,
  engine = c("auto", "C", "dll")
) {
  # 1. Validate the native engine selection and prepare the matrix for C.
  match.arg(engine)
  storage.mode(X) <- "double"
  namespace <- environment(.predsig_supplementary_engine)
  native <- get0("C_predsig_supplementary", envir = namespace, inherits = FALSE)
  if (!inherits(native, "NativeSymbolInfo"))
    stop(
      "The native C engine is unavailable. Reinstall predsig with its compiled native library.",
      call. = FALSE
    )

  # 2. Compute the supplementary quantities and handle model validation statuses.
  value <- .Call(
    C_predsig_supplementary,
    as.double(y), X,
    as.double(b), as.double(se), as.double(sigma2_hat)
  )
  if (value$status == 1L)
    stop("The full design must have full column rank.", call. = FALSE)
  if (value$status == 2L)
    stop("Outcome and residual variances must be finite and positive.", call. = FALSE)
  if (value$status == 3L)
    stop(
      "Model covariance or residual variance does not match ordinary unweighted OLS.",
      call. = FALSE
    )
  if (value$status != 0L)
    stop("The supplementary engine returned an unsupported status.", call. = FALSE)

  # 3. Name the output columns for the result formatter.
  list(
    standardized_coefficient = value$results[, 1L],
    predictor_residual_variance = value$results[, 2L],
    variance_factor = value$results[, 3L],
    residuals = value$residuals,
    leverage = value$leverage,
    VIF = value$VIF,
    backend = "C"
  )
}

.predsig_engine <- function(
  t, sigma2_hat, N, P,
  abs_tol = 2e-10, rel_tol = 2e-8,
  engine = c("auto", "C", "dll")
) {
  # 1. Validate the arguments before calling the native implementation.
  match.arg(engine)
  .predsig_check_core_inputs(t, sigma2_hat, N, P, abs_tol, rel_tol)
  native <- get0(
    "C_predsig_core",
    envir = environment(.predsig_engine),
    inherits = FALSE
  )
  if (!inherits(native, "NativeSymbolInfo"))
    stop(
      "The native C engine is unavailable. Reinstall predsig with its compiled native library.",
      call. = FALSE
    )

  # 2. Calculate predictive significance and restore the input shape.
  value <- .Call(
    C_predsig_core,
    as.double(t), as.double(sigma2_hat),
    as.double(N), as.double(P),
    as.double(abs_tol), as.double(rel_tol)
  )
  for (field in c("delEPE", "delta", "p_pred"))
    attributes(value[[field]]) <- attributes(t)

  # 3. Report the truncation probability and the unavailable quadrature error.
  value$numerical <- list(
    absolute_error = rep(NA_real_, length(t)),
    tail_probability = rep(2e-12, length(t))
  )
  value$backend <- list(
    backend = "C",
    reason = "MATLAB Coder-generated native C implementation."
  )
  value
}

.predsig_check_core_inputs <- function(t, sigma2_hat, N, P, abs_tol, rel_tol) {
  scalar <- function(x) is.numeric(x) && !is.complex(x) &&
    length(x) == 1L && is.finite(x)
  vector_shape <- is.null(dim(t)) ||
    (length(dim(t)) == 2L && any(dim(t) == 1L))
  if (!is.numeric(t) || is.complex(t) || !length(t) || anyNA(t) || !vector_shape)
    stop("t must be a nonempty real numeric vector without missing values.", call. = FALSE)
  if (!scalar(sigma2_hat) || sigma2_hat <= 0)
    stop("sigma2_hat must be a finite positive scalar.", call. = FALSE)
  if (
    !scalar(N) || N <= 0 || N != floor(N) ||
      !scalar(P) || P <= 0 || P != floor(P)
  )
    stop("N and P must be positive integers.", call. = FALSE)
  if (N <= P + 2)
    stop("Require N > P + 2.", call. = FALSE)
  if (
    !scalar(abs_tol) || abs_tol < 0 ||
      !scalar(rel_tol) || rel_tol < 0 ||
      (abs_tol == 0 && rel_tol == 0)
  )
    stop(
      "Integration tolerances must be nonnegative scalars, with at least one positive.",
      call. = FALSE
    )
  invisible(NULL)
}
