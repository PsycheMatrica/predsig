# Copyright (C) 2026 Gyeongcheol Cho. CC BY-NC-SA 4.0.
# Predictor diagnostics use the retained design; they never change inference.

.predsig_normality_fields <- c(
  "Skewness_g1", "Excess_kurtosis_g2",
  "Skewness_z", "Skewness_p", "Kurtosis_z", "Omnibus_K2", "Omnibus_p",
  "Skewness_p_Holm", "Omnibus_p_Holm",
  "Shapiro_W", "Shapiro_p", "Shapiro_p_Holm"
)

.predsig_validate_check_normality <- function(check_normality) {
  if (
    !is.logical(check_normality) ||
      length(check_normality) != 1L ||
      is.na(check_normality)
  )
    stop("check_normality must be TRUE or FALSE.", call. = FALSE)
  invisible(NULL)
}

.predsig_normality <- function(X, alpha, backend, familyP = NULL, enabled = TRUE) {
  # 1. Determine which predictors are available and label the test family.
  # familyP counts the planned predictors even if diagnostics are disabled.
  .predsig_validate_check_normality(enabled)
  planned_P <- if (is.null(X)) 0L else ncol(X)
  if (is.null(familyP)) familyP <- planned_P
  # Opt-out returns the same empty table schema as summary-only inputs.
  # Empty results require no call to the native engine.
  P <- if (!enabled || is.null(X)) 0L else planned_P
  N <- if (!enabled || is.null(X)) integer() else rep.int(nrow(X), P)
  labels <- if (!enabled || is.null(X)) character() else colnames(X)
  if (is.null(labels)) labels <- paste0("x", seq_len(P))

  # 2. Run the C diagnostics for the retained design, or prepare an empty table.
  if (!enabled || is.null(X)) {
    ResultsMat <- matrix(numeric(), nrow = 0L, ncol = 12L)
    codes <- matrix(numeric(), nrow = 0L, ncol = 2L)
    overall <- if (enabled) "unavailable_nodata" else "disabled"
  } else {
    native <- get0(
      "C_predsig_normality",
      envir = environment(.predsig_normality),
      inherits = FALSE
    )
    if (!inherits(native, "NativeSymbolInfo"))
      stop(
        "The native normality engine is unavailable. Reinstall predsig with its compiled library.",
        call. = FALSE
      )
    calculated <- .Call(C_predsig_normality, X)
    ResultsMat <- calculated$ResultsMat
    codes <- calculated$status
    overall <- if (all(codes == 0)) "available" else
      if (any(codes == 0)) "partially_available" else
        if (all(codes == 1)) "range_unavailable" else "numerical_unavailable"
  }

  # 3. Label the results and translate the status code for each test family.
  # The C engine returns 0 for available, 1 for out of range, and 2 for a
  # diagnostic that could not be computed numerically.
  colnames(ResultsMat) <- .predsig_normality_fields
  table <- data.frame(
    Predictor = labels,
    N = N,
    ResultsMat,
    Status = c("available", "N_le20", "numerical_unavailable")[codes[, 1L] + 1L],
    Available = codes[, 1L] == 0,
    Shapiro_Status = c("available", "N_outside_3_5000", "numerical_unavailable")[codes[, 2L] + 1L],
    Shapiro_Available = codes[, 2L] == 0,
    row.names = NULL,
    check.names = FALSE
  )

  # 4. Record availability, test assumptions, and the scope of adjustment.
  note <- paste(
    "Approximate marginal predictor tests. Nonrejection does not establish",
    "joint predictor normality or independent Gaussian errors.",
    "Diagnostics do not change the model, analysis sample, or inference."
  )
  if (!enabled) note <- "Normality diagnostics are disabled (check_normality = FALSE)." else
    if (is.null(X)) note <- paste("Predictor data are unavailable from summary inputs.", note)
  note <- paste(
    "Moment tests require N > 20; Shapiro-Wilk requires 3 <= N <= 5000.",
    "Availability is reported separately for each diagnostic family.",
    note
  )
  list(
    table = table,
    info = list(
      status = overall,
      method = "D'Agostino skewness, unadjusted D'Agostino-Pearson K-squared, and Shapiro-Wilk (Royston)",
      scope = "predictor_marginals",
      alpha = alpha,
      familyP = familyP,
      adjustment = "Holm, separately across predictors for skewness, omnibus, and Shapiro-Wilk p-values",
      minN = 21L, shapiro_minN = 3L, shapiro_maxN = 5000L,
      backend = list(
        backend = if (!enabled) "disabled" else if (is.null(X)) "unavailable" else backend,
        reason = if (!enabled) "Normality diagnostics disabled by the caller." else
          if (is.null(X)) "Predictor data unavailable." else
            "MATLAB Coder-generated normality implementation."
      ),
      note = note
    )
  )
}
