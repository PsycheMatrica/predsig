# Copyright (c) 2026 Gyeongcheol Cho
# SPDX-License-Identifier: CC-BY-NC-SA-4.0
# Display methods only: all predictive quantities come from run(), unchanged.

#' Summarize coefficient and predictive significance
#' @export
summary.predsig_result <- function(
  object, digits = 3L, correlation = FALSE, symbolic.cor = FALSE, ...
) {
  # 1. Build the coefficient summary from the available model information.
  .predsig_summary_digits(digits)
  results <- .predsig_public_results(object)
  if (!is.null(object$fit)) {
    # Retain the original lm summary, including its intercept and fit statistics.
    answer <- stats::summary.lm(
      object$fit, correlation = correlation, symbolic.cor = symbolic.cor, ...
    )
  } else {
    # Summary inputs identify the tests and the residual standard error.
    # Estimates, coefficient SEs, R-squared, and the model F test are unavailable.
    answer <- list(
      call = NULL, residuals = NULL,
      coefficients = cbind(
        Estimate = results$b_raw,
        "Std. Error" = results$SE_raw,
        "t value" = results$t,
        "Pr(>|t|)" = results$p_coef
      ),
      sigma = sqrt(object$sigma2),
      df = c(object$P + 1, object$df_error, object$P + 1)
    )
    rownames(answer$coefficients) <- results$Predictor
  }
  # 2. Add the predictor-level output and retain the diagnostic information.
  answer$predictive <- cbind(
    Estimate = results$b_raw,
    DeltaEPE_p = results$DeltaEPE_p,
    delta_p = results$delta_p,
    p_pred = results$p_pred
  )
  rownames(answer$predictive) <- results$Predictor
  answer$N <- object$N
  answer$P <- object$P
  answer$alpha <- object$alpha
  answer$EPE1 <- object$EPE1
  answer$input_type <- object$input_type
  answer$backend <- object$backend
  answer$normality <- object$normality
  answer$normality_info <- object$normality_info
  answer$digits <- digits
  class(answer) <- "summary.predsig_result"
  answer
}

#' @export
print.summary.predsig_result <- function(
  x,
  digits = x$digits,
  symbolic.cor = x$symbolic.cor,
  signif.stars = getOption("show.signif.stars"),
  signif.legend = signif.stars,
  P.values = getOption("show.coef.Pvalues"), ...
) {
  # 1. Validate display options and print the original call and residuals.
  .predsig_summary_digits(digits)
  for (option_name in c("signif.stars", "signif.legend", "P.values")) {
    option_value <- get(option_name)
    if (!is.logical(option_value) || length(option_value) != 1L || is.na(option_value))
      stop(option_name, " must be TRUE or FALSE.", call. = FALSE)
  }
  if (!is.null(x$call)) {
    cat("\nCall:\n", paste(deparse(x$call), collapse = "\n"), "\n\n", sep = "")
    cat("Residuals:\n")
    if (x$df[2L] > 5L) {
      quantiles <- .predsig_summary_fixed(stats::quantile(x$residuals), digits)
      names(quantiles) <- c("Min", "1Q", "Median", "3Q", "Max")
      print(quantiles, quote = FALSE)
    } else {
      print(.predsig_summary_fixed(x$residuals, digits), quote = FALSE)
    }
  }
  # 2. Print the two significance tables. Rounding applies only to the display.
  cat("\nCoefficients:\n")
  coefficient_stars <- .predsig_summary_table(
    x$coefficients, digits, signif.stars = signif.stars, P.values = P.values, ...
  )

  cat("\nPredictive Significance:\n")
  predictive_stars <- .predsig_summary_table(
    x$predictive, digits, signif.stars = signif.stars, P.values = P.values, ...
  )
  if (signif.legend && (coefficient_stars || predictive_stars))
    cat("---\nSignif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1\n")

  # 3. Print residual error, model fit statistics, and coefficient correlations.
  cat(
    "\nResidual standard error:", .predsig_summary_fixed(x$sigma, digits),
    "on", x$df[2L], "degrees of freedom\n"
  )
  omissions <- stats::naprint(x$na.action)
  if (nzchar(omissions)) cat("  (", omissions, ")\n", sep = "")
  if (!is.null(x$fstatistic)) {
    cat(
      "Multiple R-squared: ", .predsig_summary_fixed(x$r.squared, digits),
      ",\tAdjusted R-squared: ", .predsig_summary_fixed(x$adj.r.squared, digits),
      "\n", sep = ""
    )
    cat(
      "F-statistic:", .predsig_summary_fixed(x$fstatistic[1L], digits), "on",
      x$fstatistic[2L], "and", x$fstatistic[3L], "DF,  p-value:",
      .predsig_summary_p(
        stats::pf(
          x$fstatistic[1L], x$fstatistic[2L], x$fstatistic[3L], lower.tail = FALSE
        ),
        digits
      ),
      "\n"
    )
  } else if (identical(x$input_type, "summary")) {
    cat("Coefficient estimates, SEs, R-squared, and F-statistic are unavailable from summary inputs.\n")
  }
  if (!is.null(x$correlation) && NCOL(x$correlation) > 1L) {
    cat("\nCorrelation of Coefficients:\n")
    if (isTRUE(symbolic.cor)) {
      print(stats::symnum(x$correlation, abbr.colnames = NULL))
    } else {
      correl <- matrix(
        .predsig_summary_fixed(x$correlation, digits),
        nrow = NROW(x$correlation), dimnames = dimnames(x$correlation)
      )
      correl[!lower.tri(correl)] <- ""
      print(correl[-1L, -NCOL(correl), drop = FALSE], quote = FALSE)
    }
  }
  # 4. Print the optional normality diagnostics and explain the scale of delta_p.
  .predsig_summary_normality(x$normality, x$normality_info, digits, P.values, ...)
  cat("\ndelta_p = \u0394EPE_p / EPE1.\n")
  invisible(x)
}

.predsig_summary_normality <- function(table, info, digits, P.values, ...) {
  if (is.null(info)) return(invisible(NULL))
  cat("\nPredictor normality diagnostics:\n")
  if (identical(info$status, "disabled")) {
    cat("Disabled (check_normality = FALSE).\n")
    return(invisible(NULL))
  }
  if (!nrow(table)) {
    cat("Unavailable: predictor data are not supplied by summary inputs.\n")
  } else {
    shown <- data.frame(
      Predictor = table$Predictor, N = table$N,
      Status = table$Status, Shapiro_Status = table$Shapiro_Status,
      check.names = FALSE
    )
    if (P.values) {
      shown$Skewness_p <- .predsig_summary_p(table$Skewness_p, digits)
      shown$Skewness_p_Holm <- .predsig_summary_p(table$Skewness_p_Holm, digits)
      shown$Omnibus_p <- .predsig_summary_p(table$Omnibus_p, digits)
      shown$Omnibus_p_Holm <- .predsig_summary_p(table$Omnibus_p_Holm, digits)
      shown$Shapiro_p <- .predsig_summary_p(table$Shapiro_p, digits)
      shown$Shapiro_p_Holm <- .predsig_summary_p(table$Shapiro_p_Holm, digits)
      shown <- shown[c(
        "Predictor", "N", "Skewness_p", "Skewness_p_Holm",
        "Omnibus_p", "Omnibus_p_Holm", "Shapiro_p", "Shapiro_p_Holm",
        "Status", "Shapiro_Status"
      )]
    }
    print.default(as.matrix(shown), quote = FALSE, right = TRUE, ...)
    cat(
      "Holm adjustment is separate for skewness, omnibus, and Shapiro-Wilk tests across",
      info$familyP, "predictors.\n"
    )
    cat("Moments require N > 20; Shapiro-Wilk requires 3 <= N <= 5000; NA marks an unavailable diagnostic.\n")
  }
  cat("Marginal nonrejection does not establish joint normality or independent Gaussian errors.\n")
  invisible(NULL)
}

.predsig_summary_digits <- function(digits) {
  if (
    !is.numeric(digits) || is.complex(digits) || length(digits) != 1L ||
      !is.finite(digits) || digits != floor(digits) || digits < 1L || digits > 15L
  )
    stop("digits must be an integer from 1 to 15 (decimal places).", call. = FALSE)
  invisible(NULL)
}

.predsig_summary_fixed <- function(values, digits) {
  # Rounding is for display only. Keep the sign of small negative estimates,
  # including values that appear as -0.000 at the requested precision.
  answer <- formatC(values, format = "f", digits = digits)
  answer[is.na(values)] <- "NA"
  answer
}

.predsig_summary_p <- function(values, digits) {
  answer <- .predsig_summary_fixed(values, digits)
  below <- !is.na(values) & values < 10^(-digits)
  answer[below] <- paste0("<", .predsig_summary_fixed(10^(-digits), digits))
  answer
}

.predsig_summary_table <- function(values, digits, signif.stars, P.values, ...) {
  printed <- matrix(
    .predsig_summary_fixed(values, digits),
    nrow = NROW(values), dimnames = dimnames(values)
  )
  # Use the Greek symbol only for display; the numeric matrix keeps the
  # ASCII field name DeltaEPE_p for programmatic access.
  colnames(printed)[colnames(printed) == "DeltaEPE_p"] <- "\u0394EPE_p"
  p_values <- values[, NCOL(values)]
  show_stars <- P.values && signif.stars && any(p_values < .1, na.rm = TRUE)
  if (P.values) {
    printed[, NCOL(printed)] <- .predsig_summary_p(p_values, digits)
    if (show_stars) {
      # Use the same cutpoints and endpoint handling as stats::printCoefmat.
      stars <- stats::symnum(
        p_values, corr = FALSE, na = FALSE,
        cutpoints = c(0, .001, .01, .05, .1, 1),
        symbols = c("***", "**", "*", ".", " ")
      )
      printed <- cbind(printed, format(stars))
      colnames(printed)[NCOL(printed)] <- ""
    }
  } else {
    printed <- printed[, -NCOL(printed), drop = FALSE]
  }
  print.default(printed, quote = FALSE, right = TRUE, ...)
  invisible(show_stars)
}
