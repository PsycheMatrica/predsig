\name{summary.predsig_result}
\alias{summary.predsig_result}
\alias{print.summary.predsig_result}
\title{Summarize Coefficient and Predictive Significance}
\description{
Displays the ordinary linear-model coefficient table, a predictive-significance
table, and the usual residual standard error, R-squared, and F statistic.
Also displays marginal predictor normality diagnostics when available.
The calculations from \code{run()} are retained without recomputing inference.
}
\usage{
\method{summary}{predsig_result}(object, digits = 3L, correlation = FALSE,
  symbolic.cor = FALSE, ...)

\method{print}{summary.predsig_result}(x,
  digits = x$digits,
  symbolic.cor = x$symbolic.cor,
  signif.stars = getOption("show.signif.stars"),
  signif.legend = signif.stars,
  P.values = getOption("show.coef.Pvalues"), ...)
}
\arguments{
\item{object}{A result returned by \code{\link{run}}.}
\item{x}{A result returned by \code{summary()} for a \code{predsig_result}.}
\item{correlation}{Whether to include the coefficient correlation matrix,
as in \code{\link[stats]{summary.lm}}. Applies when the fitted model is available.}
\item{symbolic.cor}{Whether to display coefficient correlations symbolically.}
\item{digits}{Number of decimal places used for printing, from 1 to 15.
Defaults to three in \code{summary()}; \code{print()} uses the saved setting
unless overridden. Underlying numeric results retain their full precision.
P-values smaller than the display resolution are shown as, for example,
\code{<0.001} with three decimal places. Small negative estimates retain
their sign even when rounding produces \code{-0.000}.}
\item{signif.stars}{Whether to print the usual R significance codes for both
tables. Defaults to \code{getOption("show.signif.stars")}.}
\item{signif.legend}{Whether to show the shared significance-code legend.}
\item{P.values}{Whether to show the p-value column and any significance codes
in each table. Defaults to \code{getOption("show.coef.Pvalues")}.}
\item{...}{For \code{summary}, further arguments to
\code{\link[stats]{summary.lm}} when a fitted model is available. For
\code{print}, further arguments to \code{\link{print.default}} for the tables.}
}
\details{
The \code{Coefficients:} table retains the intercept and ordinary coefficient
inference from \code{summary(lm)}. The \code{Predictive Significance:} table
contains slopes only. Its columns are \code{Estimate} (the same unstandardized
coefficient), \eqn{\Delta\mathrm{EPE}_p}{Delta EPE_p}
(the estimated change in expected prediction error,
\code{DeltaEPE_p}), \code{delta_p} (\code{DeltaEPE_p / EPE1}), and \code{p_pred}
(the predictive p-value for the null of nonpositive predictive contribution).
The predictive p-value is a test p-value, not a posterior probability that
the contribution is nonpositive.
The numeric \code{predictive} matrix names the change-in-EPE column
\code{DeltaEPE_p}; its printed header uses uppercase Greek delta and retains the
underscore for the subscript.

Both tables use the same significance-code cutoffs as \code{printCoefmat}
and honor \code{show.coef.Pvalues}. Codes are calculated from the full-precision
p-values, independent of display rounding and the \code{alpha} specified in
\code{run()}.

For summary-statistic inputs, coefficient estimates and standard errors remain
\code{NA}; the intercept, R-squared, and F statistic are unavailable. The
available slope t statistics, coefficient p-values, predictive results, and
residual standard error and degrees of freedom are still displayed.

The predictor normality section displays skewness, omnibus, and Shapiro-Wilk
p-values with separate Holm adjustments across the full predictor set. Moment
tests require \code{N > 20}; Shapiro-Wilk supports \code{3 <= N <= 5000}.
Their unavailable statuses are recorded independently for sample-size limits,
numerical failure, or absent predictor data. These are marginal tests, with
approximate p-values except for the Shapiro-Wilk \code{N=3} case;
nonrejection does not establish
joint normality or independent Gaussian errors, and diagnostics do not
change inference. \code{P.values = FALSE} hides diagnostic p-values as well.
If \code{run(..., check_normality = FALSE)} skips the checks, the summary
reports that they are disabled; it does not compute them during display.
}
\value{
\code{summary()} returns an object of class \code{summary.predsig_result}.
It contains the ordinary \code{summary.lm} fields when a fitted model is
available, a \code{predictive} matrix with the four displayed predictive
columns, and \code{N}, \code{P}, \code{alpha}, \code{EPE1}, \code{input_type},
\code{backend}, \code{normality}, \code{normality_info}, and \code{digits}.
\code{print()} returns its argument invisibly.
}
\seealso{\code{\link{run}}, \code{\link[stats]{summary.lm}},
\code{\link[stats]{printCoefmat}}}
\examples{
fit <- lm(Volume ~ Girth + Height, data = trees)
out <- predsig::run(fit)
summary(out)
summary(out, digits = 5)
print(summary(out), digits = 5, signif.stars = FALSE)

# The displayed matrices are available without parsing printed text.
summary(out)$coefficients
summary(out)$predictive
}
\keyword{regression}
