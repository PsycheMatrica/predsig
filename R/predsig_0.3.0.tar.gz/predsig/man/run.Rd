\name{run}
\alias{run}
\alias{run.default}
\alias{run.lm}
\alias{run.formula}
\alias{predsig}
\alias{predictive_test}
\alias{predictive_pvalue}
\title{Coefficient and Predictive Significance for an Ordinary Linear Model}
\description{
Reports coefficient p-values, predictive p-values, predictive contribution
estimates, and an interpretation index. Accepts an ordinary fitted linear
model, raw outcome and predictor data, or coefficient summary statistics.
By default, also reports marginal normality diagnostics when predictor data
are available. These optional checks do not change inference.
}
\usage{
run(object = NULL, ...)

\method{run}{lm}(object, alpha = 0.05, abs_tol = 2e-10,
  rel_tol = 2e-8, engine = "auto", check_normality = TRUE, ...)

\method{run}{formula}(object, data = NULL, alpha = 0.05,
  na.action = stats::na.fail, abs_tol = 2e-10,
  rel_tol = 2e-8, engine = "auto", check_normality = TRUE, ...)

\method{run}{default}(object = NULL, y = NULL, X = NULL, t = NULL,
  sigma2_hat = NULL, N = NULL, P = NULL, alpha = 0.05,
  abs_tol = 2e-10, rel_tol = 2e-8, engine = "auto",
  check_normality = TRUE, ...)

predsig(object = NULL, ...)

predictive_test(object = NULL, ...)

predictive_pvalue(object, data = NULL, alpha = 0.05,
  na.action = stats::na.fail, ...)
}
\arguments{
\item{object}{An ordinary univariate fitted object of class exactly
\code{"lm"}, retaining its model frame; a regression formula; or an outcome
vector used together with \code{X}. Omit this argument for named raw-data
or summary inputs.}
\item{y}{Raw numeric outcome vector, supplied with \code{X}.}
\item{X}{Raw numeric predictor matrix or numeric data frame, without an
intercept column. A vector is accepted for one predictor. All rows must be complete.}
\item{t}{Named or unnamed vector of ordinary coefficient t statistics.
Summary mode requires \code{sigma2_hat}, \code{N}, and \code{P} as well.
A subset of slopes is allowed, with \code{P} still giving the full model size.}
\item{sigma2_hat}{Positive residual variance estimate from the full model.}
\item{N}{Number of observations in the full model's analysis sample.}
\item{P}{Total number of slopes in the full model, excluding the intercept.
Must be at least \code{length(t)} in summary mode.}
\item{data}{Optional data for a formula; do not supply it with an existing fit.}
\item{alpha}{Coefficientwise significance level strictly between zero and one;
defaults to \code{0.05}.}
\item{na.action}{Missing-data rule for formulas, defaulting to \code{stats::na.fail}.
An existing fit retains its established sample and recorded omissions.}
\item{abs_tol, rel_tol}{Nonnegative finite absolute and relative integration
tolerances. Defaults are \code{2e-10} and \code{2e-8}, matching the MATLAB core.
They cannot both be zero. The fixed omitted chi-square probability bound is
\code{2e-12}, separate from these tolerances.}
\item{engine}{The default \code{"auto"} and the aliases \code{"C"} and
\code{"dll"} all use the compiled C library.}
\item{check_normality}{A single nonmissing logical value, defaulting to
\code{TRUE}, for all input methods. Set to \code{FALSE} to skip predictor
normality calculations. The diagnostic data frame retains the same columns
with zero rows, and \code{normality_info$status} is \code{"disabled"}.
Coefficient and predictive inference are unchanged.}
\item{...}{For formulas, further arguments to \code{stats::lm}. For the generic
and compatibility names, arguments for the selected method. No additional
arguments are accepted in fitted-model, raw-data, or summary mode.}
}
\details{
Assumes a prespecified OLS model with an intercept, iid jointly normal
continuous predictors, and independent Gaussian errors of constant variance.
Requires residual degrees of freedom greater than 1.

The primary estimate \code{DeltaEPE_p} is the change in expected squared prediction
error when the focal predictor's unique linear contribution is removed at
prediction time. Other fitted coefficients are retained; a reduced model is
not refitted. The index \code{delta_p} expresses that change relative to the
full model's expected prediction error, \code{EPE1}.
Positive \code{DeltaEPE_p} means that removal increases prediction error.
For example, \code{delta_p = 0.15} estimates a 15 percent increase in expected
prediction error relative to the original full model after removal.

The reported \code{p_pred} tests nonpositive predictive contribution;
\code{p_coef} tests a zero regression coefficient.

The fitted-model method preserves the supplied equation and analysis sample.
Raw-data and formula methods fit ordinary \code{lm} models with an intercept.
All input modes use the same predictive calculation. Methods with a fitted
model first check the design and compute supplementary quantities such as
standardized coefficients and variance inflation factors. Summary mode
reports the tests and contributions and returns \code{NA} for coefficients,
standard errors, standardized coefficients, and variance inflation factors.

When \code{check_normality = TRUE}, the fitted-model, formula, and raw-data
methods diagnose the predictor columns
actually used in the retained model matrix, excluding the intercept. The
diagnostics are the D'Agostino skewness test, unadjusted D'Agostino-Pearson
K-squared omnibus test, and Shapiro-Wilk test. The moment tests use normal and
chi-square approximations. Shapiro-Wilk uses Royston's published calculation,
exact at \code{N=3} and approximate for larger samples. Holm
adjustment is applied separately across all \code{P} predictors for the
skewness, omnibus, and Shapiro-Wilk p-value families. Unavailable columns remain
part of the planned family size. The nine moment statistics/p-values are
\code{NA} when \code{N <= 20}; the three Shapiro-Wilk outputs are \code{NA}
outside \code{3 <= N <= 5000}. A numerical failure makes the affected group's
values unavailable. The two groups have separate availability statuses.
With normality checks enabled, summary inputs supply no predictor observations,
so their diagnostic table is empty with status \code{unavailable_nodata}.
Disabling checks skips the diagnostic engine for every input method and
records status \code{disabled}, including for summary inputs.
These diagnostics never alter the model, retained sample, or inference.
Marginal nonrejection does not establish joint predictor normality or
independent Gaussian errors.

The native engine is generated from the authoritative MATLAB numerical core
and compiled by R during source-package installation. End users do not need
MATLAB or MATLAB Coder; installing a binary package does not require a compiler.
Installing the source package requires a supported R C toolchain. The
\code{backend} output records \code{"C"}.
Earlier names \code{predsig()}, \code{predictive_test()}, and
\code{predictive_pvalue()} remain compatibility wrappers.
}
\value{
An object inheriting from \code{predsig_result} and \code{predictive_pvalue}, containing:
\item{results}{A slope-level data frame with columns \code{Predictor},
\code{b_raw}, \code{SE_raw}, \code{b_std}, \code{t}, \code{p_coef},
\code{sig_coef}, \code{DeltaEPE_p}, \code{delta_p}, \code{p_pred},
\code{sig_pred}, and \code{VIF}, in that order. The raw coefficient, standardized
coefficient, and standard error of the unstandardized coefficient are
\code{b_raw}, \code{b_std}, and \code{SE_raw}.
Standardization uses predictor and outcome SDs in the fitted sample.
The logical columns \code{sig_coef} and \code{sig_pred} compare \code{p_coef}
and \code{p_pred}, respectively, to \code{alpha} using the unrounded values.
In summary mode \code{b_raw}, \code{b_std}, \code{SE_raw}, and \code{VIF} are \code{NA}.}
\item{fit}{The full fitted \code{lm} object, or \code{NULL} in summary mode.}
\item{N, P, df_error, alpha}{Analysis sample size, full number of slopes,
residual degrees of freedom, and decision level.}
\item{sigma2, EPE1, intercept}{Residual variance estimate, estimated full-model
expected squared prediction error, and the intercept. The intercept is \code{NA}
in summary mode.}
\item{predictor_residual_variance, variance_factor, VIF}{Per-predictor auxiliary
residual variance estimates, diagonal entries of the inverse full-model design
cross-product for the slopes, and variance inflation factors. These are
available for fitted models, in slope order.}
\item{residuals, fitted, leverage}{Residuals, fitted values, and leverages in the
retained analysis-row order, available for fitted models.}
\item{analysis_row_names, omitted_rows}{Stored model-frame row names and
recorded omissions when a fitted model is available.}
\item{backend}{List with \code{backend = "C"} and a description in
\code{reason}.}
\item{input_type}{\code{"lm"}, \code{"formula"}, \code{"raw"}, or \code{"summary"}.}
\item{integration}{Requested absolute and relative tolerances.}
\item{numerical_accuracy}{Predictor-level integration error estimates and the
omitted chi-square probability bound. An unavailable numerical error estimate
is \code{NA}; it is not reported as zero.}
\item{normality}{Predictor-level data frame containing \code{Predictor},
\code{N}, \code{Skewness_g1}, \code{Excess_kurtosis_g2}, \code{Skewness_z},
\code{Skewness_p}, \code{Kurtosis_z}, \code{Omnibus_K2}, \code{Omnibus_p},
\code{Skewness_p_Holm}, \code{Omnibus_p_Holm}, \code{Shapiro_W},
\code{Shapiro_p}, \code{Shapiro_p_Holm}, \code{Status}, \code{Available},
\code{Shapiro_Status}, and \code{Shapiro_Available}. The original moment status
is \code{available}, \code{N_le20}, or \code{numerical_unavailable}; Shapiro status
is \code{available}, \code{N_outside_3_5000}, or \code{numerical_unavailable}.
The groups may be available independently. The table retains its columns with
zero rows for summary inputs or when \code{check_normality = FALSE}.}
\item{normality_info}{Diagnostic availability status, method, marginal scope,
moment \code{minN = 21}, \code{shapiro_minN = 3}, \code{shapiro_maxN = 5000},
planned \code{familyP}, \code{alpha}, adjustment,
backend metadata, and interpretation note. When checks are disabled,
\code{status} and \code{backend} are \code{"disabled"}; the planned
predictor family size is retained.}
\item{metadata}{Author, paper, package version, repository, and runtime information.}
No intercept predictive test is returned.
}
\author{Gyeongcheol Cho \email{g.cho@psychematrica.org}}
\seealso{\code{\link[stats]{lm}}, \code{\link{predsig-package}},
\code{\link{prepare_manini}}, \code{\link{print.predsig_result}},
\code{\link{summary.predsig_result}}}
\examples{
fit <- lm(Volume ~ Girth + Height, data = trees)
result <- predsig::run(fit)
summary(result)
result$results
result$backend
result$normality

# Skip optional diagnostics without changing the model or inference.
predsig::run(fit, check_normality = FALSE)

# The same model, supplied as raw outcome and predictor data.
predsig::run(y = trees$Volume, X = trees[c("Girth", "Height")])

# Or use summaries from the full model.
predsig::run(t = coef(summary(fit))[-1, "t value"],
  sigma2_hat = summary(fit)$sigma^2, N = nobs(fit), P = 2)

# The formula interface is retained.
predsig::run(Volume ~ Girth + Height, data = trees)

# The illustration requires an Internet connection on its first call.
\dontrun{
manini <- predsig::prepare_manini()
results <- lm(RT_switch_cost ~ Language + LH_neural_switch_cost +
              RH_neural_switch_cost, data = manini)
out <- predsig::run(results, alpha = .05)
out$results
out$backend
}
}
\keyword{regression}
