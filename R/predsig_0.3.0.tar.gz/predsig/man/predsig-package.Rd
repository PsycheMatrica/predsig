\name{predsig-package}
\alias{predsig-package}
\docType{package}
\title{Predictive Significance Tests for Linear Regression}
\description{
Complements coefficient significance tests with predictive significance tests
for ordinary unweighted linear regression with continuous additive predictors.
The primary target is the change in expected squared prediction error,
\eqn{\Delta\mathrm{EPE}_p}; \eqn{\delta_p} is a separate normalized
interpretation index relative to the original full fitted model's expected
prediction error, averaged over training and independent test observations.
}
\details{
Version 0.3.0 accepts ordinary \code{lm} models, raw outcome and predictor data,
or full-model coefficient summaries. The primary \code{predsig::run()} S3 generic
prepares inputs for the registered C engine. The default
\code{engine = "auto"} and the aliases \code{"C"} and \code{"dll"} all use
the compiled package library.

The C sources are generated from the authoritative MATLAB core and compiled
by R's normal package build. Installing from source requires a C99 toolchain
and GNU make, but no MATLAB, MATLAB Coder, or installed MathWorks library/API
headers. MATLAB Coder is required only for developer regeneration.
The mathematical MATLAB generation sources are maintained separately and are
not bundled in the R package; R installation uses the included generated C.

The original author-controlled code and documentation are licensed under
\href{https://creativecommons.org/licenses/by-nc-sa/4.0/}{CC BY-NC-SA 4.0};
commercial uses require separate authorization from the rights holder.
Shared adaptations must comply with the ShareAlike clause of that license.
Generated MathWorks-affected source and support are separately governed and
retain their Academic License and other original notices, including the Sun
Microsystems/FDLIBM notices in generated \file{eml_erfcore.c} and
\file{norminv.c}. See the package's
\file{LICENSE}, installed \file{COPYRIGHTS}, and
\file{native/generated_manifest.json} for scope and provenance.
This native-backend distribution has unresolved Academic-offering,
public-source redistribution, and written Application License questions.
It is not declared legally cleared or ready for CRAN submission. The factual
notices are not an operative supplemental Application License.

Use \code{help("run", package = "predsig")} (also \code{help("predsig")})
for the function reference: inputs, options, returned values, and examples.
Use \code{help("prepare_manini", package = "predsig")} for the illustration's
download and preprocessing function. These installed help pages are the manual.

\code{prepare_manini()} downloads the authors' original OSF workbooks directly,
returns the 21-case analysis data frame, and saves a local RData copy. No
participant-level data are included in the package.
}
\author{Gyeongcheol Cho \email{g.cho@psychematrica.org}}
\references{
Cho, G. (in preparation). \emph{Predictive Significance Testing: A Complement
to Coefficient Significance in Confirmatory Linear Regression}.
}
\seealso{\code{\link{run}}, \code{\link{prepare_manini}}, \code{\link[stats]{lm}}}
\keyword{package}
