\name{prepare_manini}
\alias{prepare_manini}
\title{Download and Prepare the Manini Reaction-Time Illustration}
\description{
Downloads three official OSF workbooks, verifies their pinned SHA-256 hashes,
and prepares the original initial reaction-time model's analysis sample.
No participant-level data are bundled in the package.
}
\usage{
prepare_manini(output_dir = "analysis_data",
  cache_dir = file.path(output_dir, "manini_sources"),
  overwrite = FALSE, quiet = FALSE)
}
\arguments{
\item{output_dir}{Local directory for the prepared data and provenance record.}
\item{cache_dir}{Local directory for downloaded official workbooks. Existing
files are reused only after hash verification. Corrupt or changed sources
cause an error and are never silently replaced.}
\item{overwrite}{Allow replacing prepared outputs that differ from the verified
result. Defaults to \code{FALSE}. Identical existing outputs are reused. This
does not authorize replacing a corrupt source workbook.}
\item{quiet}{Suppress download progress and preparation messages.}
}
\details{
Sources are the authors' OSF project \url{https://osf.io/uh2ap/}:
\file{Temporal_ROIs_data.xlsx}, \file{BehaviouralData_4EFTasks.xlsx}, and
\file{WASI-Corsi-Language.xlsx}. The package's CSV source manifest records the
official download URLs and expected hashes. Excel reading and SHA-256
verification use \pkg{readxl} and \pkg{digest}; Python is not required.

The Switching ROI sheet contains 23 deaf participants. The function matches
their unique IDs to the behavior and language sheets, uses the released
\code{Language_score}, and excludes only the two missing language scores.
The outcome is released \code{RT_SwCost}, in seconds, checked against
\code{RT_Sw_HEF_Corr - RT_Sw_LEF_Corr}. The left neural predictor averages
switch-minus-stay contrasts for HG, PT, and pSTC; the right averages PT and pSTC.

The returned data frame has 21 rows and four columns. It is also saved as the
object \code{manini} in \file{manini_initial_RT.RData} under \code{output_dir}.
The function does not assign any object into the global environment. A separate
\file{manini_provenance.rds} records sources, processing, and included/excluded IDs.
These downloaded and derived participant files remain local.

If an official download is unavailable, the error reports its URL and cache
destination. An official workbook placed there manually must still pass the
same pinned hash check. A changed upstream file is not automatically accepted.
}
\value{
A data frame with columns \code{RT_switch_cost}, \code{Language},
\code{LH_neural_switch_cost}, and \code{RH_neural_switch_cost}, ready for
\code{lm()} and \code{predsig::run()}.
}
\references{
Manini et al. (2022). \doi{10.1093/brain/awac205}.
Official data project: \url{https://osf.io/uh2ap/}.
}
\seealso{\code{\link{run}}, \code{\link[stats]{lm}}}
\examples{
\dontrun{
manini <- predsig::prepare_manini()
results <- lm(RT_switch_cost ~ Language + LH_neural_switch_cost +
              RH_neural_switch_cost, data = manini)
predsig::run(results, alpha = .05)
}
}
