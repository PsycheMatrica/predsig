\name{print.predsig_result}
\alias{print.predsig_result}
\alias{as.data.frame.predsig_result}
\title{Print or Extract a Predictive Significance Result}
\description{Prints a compact console view or extracts the full-precision
slope-level results data frame. Console headings retain the result column
names, including underscores marking subscripts or qualifiers.}
\usage{
\method{print}{predsig_result}(x, digits = 6, ...)

\method{as.data.frame}{predsig_result}(x, row.names = NULL,
  optional = FALSE, ...)
}
\arguments{
\item{x}{A result returned by \code{predsig::run()} or
\code{predictive_pvalue()}.}
\item{digits}{Number of significant digits for console display.}
\item{row.names}{Optional row names passed to \code{as.data.frame()}.}
\item{optional}{Passed to \code{as.data.frame()}.}
\item{...}{Additional arguments passed to the corresponding data-frame method.}
}
\value{\code{print()} returns \code{x} invisibly. \code{as.data.frame()}
returns the numeric slope-level table without rounding stored estimates.}
\seealso{\code{\link{run}}}
