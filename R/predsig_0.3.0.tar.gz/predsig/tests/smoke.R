# Copyright (C) 2026 Gyeongcheol Cho. CC BY-NC-SA 4.0.
# Public, fixture-free interface smoke check using a built-in R dataset.
# This checks installation and engine routing, not normal-model calibration.
library(predsig)

fit <- lm(dist ~ speed, data = cars)
native <- predsig::run(fit, engine = "C")
automatic <- predsig::run(fit)
stopifnot(identical(native$backend$backend, "C"),
          identical(automatic$backend$backend, "C"),
          identical(native$fit, fit), native$EPE1 > 0,
          all(is.finite(native$results$p_pred)),
          all(native$results$p_pred >= 0 & native$results$p_pred <= 1),
          identical(native$results, automatic$results),
          isTRUE(all.equal(native$results$delta_p,
                           native$results$DeltaEPE_p / native$EPE1)),
          identical(native$results$sig_pred,
                     native$results$p_pred <= native$alpha),
          identical(native$results$VIF, native$VIF),
          identical(names(native$results), c("Predictor", "b_raw", "SE_raw", "b_std", "t",
            "p_coef", "sig_coef", "DeltaEPE_p", "delta_p", "p_pred", "sig_pred", "VIF")))
registered <- getDLLRegisteredRoutines("predsig")[[".Call"]][["predsig_core"]]
supplementary_registered <- getDLLRegisteredRoutines("predsig")[[".Call"]][["predsig_supplementary"]]
normality_registered <- getDLLRegisteredRoutines("predsig")[[".Call"]][["predsig_normality"]]
stopifnot(!is.null(registered), registered$numParameters == 6L,
          !is.null(supplementary_registered), supplementary_registered$numParameters == 5L,
          !is.null(normality_registered), normality_registered$numParameters == 1L,
          nrow(native$normality) == length(coef(fit)) - 1L,
          all(native$normality$N == nobs(fit)),
          all(native$normality$Status == "available"),
          all(native$normality$Available),
          all(is.finite(native$normality$Skewness_p_Holm)),
          all(is.finite(native$normality$Omnibus_p_Holm)),
          identical(native$normality, automatic$normality),
          inherits(summary(native), "summary.predsig_result"))
cat("PASS: public R package native routing, registration, normality, and result contract.\n")
